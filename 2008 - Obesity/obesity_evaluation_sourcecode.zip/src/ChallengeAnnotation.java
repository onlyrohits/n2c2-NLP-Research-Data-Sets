import java.util.*;

/**
 * This class is designed to represent an annotation for a record for a disease.
 * */
public class ChallengeAnnotation {
	//
	//constants
	//
	public static String JUDGMENT_YES = "Y";
	public static String JUDGMENT_NO = "N";
	public static String JUDGMENT_QUESTIONABLE = "Q";
	public static String JUDGMENT_UNMENTIONED = "U";
	
	public static byte DISEASE = 0;
	public static byte PATIENT = 1;
	public static byte JUDGMENT_TYPE = 2;
	public static byte NONE = -1;
	
	public static HashSet<String> diseases = new HashSet<String>();
	public static HashSet<Integer> removeIDs = new HashSet<Integer>();
	
	//initialize the set of diseases
	static {
		diseases.add("Asthma");
		diseases.add("CAD");
		diseases.add("CHF");
		diseases.add("Depression");
		diseases.add("Diabetes");
		diseases.add("Gallstones");
		diseases.add("GERD");
		diseases.add("Gout");
		diseases.add("Hypercholesterolemia");
		diseases.add("Hypertension");
		diseases.add("Hypertriglyceridemia");
		diseases.add("OA");
		diseases.add("Obesity");
		diseases.add("OSA");
		diseases.add("PVD");
		diseases.add("Venous Insufficiency");
		
		removeIDs.add(245);
		removeIDs.add(679);
		removeIDs.add(102);
		removeIDs.add(103);
		removeIDs.add(795);
		removeIDs.add(1059);
	}
	
	//
	//fields
	//
	protected int id;					//the record id
	protected String disease;			//the disease
	protected String type;				//the type of the judgment
	protected String judgment;			//the judgment
	
	//
	//constructors
	//
	/**
	 * Default constructor.
	 * */
	public ChallengeAnnotation() {}
	
	//
	//methods
	//
	/**
	 * Return a String representation of the annotation.
	 * */
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("record:" + id);
		sb.append("\tdisease:" + disease);
		sb.append("\ttype:" + type);
		sb.append("\tjudgment:" + judgment);
		return sb.toString();
	}
	
	/**
	 * Return a XML String representation of the annotation.
	 * @param format the Format object managing what fields to be output
	 * */
	public String toXMLString(Format format) {
		StringBuffer sb = new StringBuffer();
		sb.append("<doc");
		if(format.getID()) {
			sb.append(" id=\"" + id + "\"");
		}
		if(format.getDisease()) {
			sb.append(" disease=\"" + disease + "\"");
		}
		if(format.getType()) {
			sb.append(" type=\"" + type + "\"");
		}
		if(format.getJudgment()) {
			sb.append(" judgment=\"" + judgment + "\"");
		}
		sb.append("/>");
		return sb.toString();
	}
	
	/**
	 * An inner class designed to control the output format of the annotation.
	 * */
	public static class Format {
		//
		//constants
		//
		
		//
		//fields
		//
		private boolean output_id;
		private boolean output_disease;
		private boolean output_type;
		private boolean output_judgment;
		
		//
		//constructor
		//
		/**
		 * Default constructor.
		 * Set all the flags to be false.
		 * */
		public Format() {}
		
		//
		//methods
		//
		/**
		 * Return the flag indicating whether output id field.
		 * */
		public boolean getID() {
			return output_id;
		}
		
		/**
		 * Set the flag.
		 * */
		public void setID(boolean output) {
			this.output_id = output;
		}
		
		/**
		 * Return the flag indicating whether output disease field.
		 * */
		public boolean getDisease() {
			return output_disease;
		}
		
		/**
		 * Set the flag.
		 * */
		public void setDisease(boolean output) {
			this.output_disease = output;
		}
		
		/**
		 * Return the flag indicating whether output type field.
		 * */
		public boolean getType() {
			return output_type;
		}
		
		/**
		 * Set the flag.
		 * */
		public void setType(boolean output) {
			this.output_type = output;
		}
		
		/**
		 * Return the flag indicating whether output judgment field.
		 * */
		public boolean getJudgment() {
			return output_judgment;
		}
		
		/**
		 * Set the flag.
		 * */
		public void setJudgment(boolean output) {
			this.output_judgment = output;
		}
	}
	
	/**
	 * The main test method.
	 * */
	public static void main(String args[]) {
		Format format = new Format();
		System.out.println(format.getDisease());
	}
}
