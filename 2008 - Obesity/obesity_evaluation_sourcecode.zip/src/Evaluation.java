/**
 * Evaluation class.
 * @author chen
 * */

import java.text.*;

public class Evaluation {
	//
	//constants
	//
	public static String usage = "Usage:\t\tEvaluation.main <ground truth file> <output file>\n";
	
	/**
	 * The main method.
	 * */
	public static void main(String args[]) {
		if(args.length < 2) {
			System.out.print(usage);
			return;
		}
		

		String groundFile = args[0];
		String outputFile = args[1];
		

		//System.err.println("Illegal argument, terminate");
		
		ChallengeAnnotations casGround = ChallengeAnnotations.parse(groundFile, null, null);
		ChallengeAnnotations casOutput = ChallengeAnnotations.parse(outputFile, null, null);
		
		ChallengeAnnotations tmpCasGround, tmpCasOutput;
		
		//define some overall scores
		Score overallScoreIntuitive = new Score();
		Score overallScoreTextual = new Score();
		Score overallScore = new Score();
		
		double overall_score = 0.0;
		
		//initialize the number formatter
		NumberFormat formatter = NumberFormat.getInstance();
		formatter.setMaximumFractionDigits(4);
		formatter.setMinimumFractionDigits(4);
		
		//see if the intuitive set is empty
		tmpCasGround = casGround.getListBySource("intuitive");
		if(tmpCasGround.size() != 0) {
			System.out.println("Intuitive judgment");
			System.out.println(formatString("Disease", 21) + formatString("P-Micro", 10) + formatString("P-Macro", 10) + formatString("R-Micro", 10) + formatString("R-Macro", 10) + formatString("F-Micro", 10) + formatString("F-Macro", 10));
			
			//intuitive judgment
			for(String disease : ChallengeAnnotation.diseases) {
				tmpCasGround = casGround.getListBySource("intuitive").getListByDisease(disease);
				
				//see if the disease set is empty
				if(tmpCasGround.size() == 0) {
					continue;
				}
				
				tmpCasOutput = casOutput.getListBySource("intuitive").getListByDisease(disease);
				
				
				//System.out.println(tmpCasGround.size() + " " + tmpCasOutput.size());
				Score score = tmpCasGround.evaluateF(tmpCasOutput);
				overallScoreIntuitive.combine(score);
				overallScore.combine(score);
				score.compute(true);
				//overall_score += microScore;
				System.out.println(formatString(disease, 21) + formatString(formatter.format(score.precisionMicro), 10) + formatString(formatter.format(score.precisionMacro), 10)
												+ formatString(formatter.format(score.recallMicro), 10) + formatString(formatter.format(score.recallMacro), 10)
												+ formatString(formatter.format(score.FMicro), 10) + formatString(formatter.format(score.FMacro), 10));
			}
			
			//system level
			overallScoreIntuitive.compute(true);
			System.out.println();
			System.out.println(formatString("System", 21) + formatString("P-Micro", 10) + formatString("P-Macro", 10) + formatString("R-Micro", 10) + formatString("R-Macro", 10) + formatString("F-Micro", 10) + formatString("F-Macro", 10));
			System.out.println(formatString("Intuitive", 21) + formatString(formatter.format(overallScoreIntuitive.precisionMicro), 10) + formatString(formatter.format(overallScoreIntuitive.precisionMacro), 10)
					+ formatString(formatter.format(overallScoreIntuitive.recallMicro), 10) + formatString(formatter.format(overallScoreIntuitive.recallMacro), 10)
					+ formatString(formatter.format(overallScoreIntuitive.FMicro), 10) + formatString(formatter.format(overallScoreIntuitive.FMacro), 10));
		}
		
		
		//textual judgment
		//see if the textual set is empty
		tmpCasGround = casGround.getListBySource("textual");
		if(tmpCasGround.size() != 0) {
			System.out.println("\nTextual judgment");
			System.out.println(formatString("Disease", 21) + formatString("P-Micro", 10) + formatString("P-Macro", 10) + formatString("R-Micro", 10) + formatString("R-Macro", 10) + formatString("F-Micro", 10) + formatString("F-Macro", 10));
			for(String disease : ChallengeAnnotation.diseases) {			
				tmpCasGround = casGround.getListBySource("textual").getListByDisease(disease);
				
				//see if the disease set is empty
				if(tmpCasGround.size() == 0) {
					continue;
				}
				
				tmpCasOutput = casOutput.getListBySource("textual").getListByDisease(disease);
				//System.out.println(tmpCasGround.size() + " " + tmpCasOutput.size());
				Score score = tmpCasGround.evaluateF(tmpCasOutput);
				overallScoreTextual.combine(score);
				overallScore.combine(score);
				//overall_score += microScore;
				score.compute(false);
				System.out.println(formatString(disease, 21) + formatString(formatter.format(score.precisionMicro), 10) + formatString(formatter.format(score.precisionMacro), 10)
						+ formatString(formatter.format(score.recallMicro), 10) + formatString(formatter.format(score.recallMacro), 10)
						+ formatString(formatter.format(score.FMicro), 10) + formatString(formatter.format(score.FMacro), 10));
			}
			
			//system level
			overallScoreTextual.compute(false);
			System.out.println();
			System.out.println(formatString("System", 21) + formatString("P-Micro", 10) + formatString("P-Macro", 10) + formatString("R-Micro", 10) + formatString("R-Macro", 10) + formatString("F-Micro", 10) + formatString("F-Macro", 10));
			System.out.println(formatString("Textual", 21) + formatString(formatter.format(overallScoreTextual.precisionMicro), 10) + formatString(formatter.format(overallScoreTextual.precisionMacro), 10)
					+ formatString(formatter.format(overallScoreTextual.recallMicro), 10) + formatString(formatter.format(overallScoreTextual.recallMacro), 10)
					+ formatString(formatter.format(overallScoreTextual.FMicro), 10) + formatString(formatter.format(overallScoreTextual.FMacro), 10));
		}
	}
	
	/**
	 * Return a formatted String.
	 * */
	public static String formatString(String s, int length) {
		StringBuffer sb = new StringBuffer();
		int i;
		sb.append(s);
		for(i = sb.length(); i < length; i++) {
			sb.append(' ');
		}
		return sb.toString();
	}
	
	/**
	 * The inner class Score stores the evaluation results as well as the corresponding confusion matrix.
	 * */
	public static class Score {
		//
		//fields
		//
		int confusion[][];
		double precisionMicro, recallMicro, FMicro;
		double precisionMacro, recallMacro, FMacro;
		
		//
		//constructors
		//
		public Score() {
			confusion = new int[5][5];
			for(int i = 0; i < 5; i++) {
				for(int j = 0; j < 5; j++) {
					confusion[i][j] = 0;
				}
			}
		}
		
		//
		//methods
		//
		/**
		 * Combine two Scores by adding their confusion matrix.
		 * */
		public void combine(Score score) {
			for(int i = 0; i < 5; i++) {
				for(int j = 0; j < 5; j++) {
					confusion[i][j] += score.confusion[i][j];
				}
			}
		}
		
		/**
		 * Compute the micro averaged value for precision, recall and F.
		 * */
		private void computeMicro() {
			int tp = 0, fn = 0, fp = 0;
			for(int i = 0; i < 4; i++) {
				//compute the number of true positives
				tp += confusion[i][i];
				
				//compute the number of false negatives
				for(int j = 0; j < 5; j++) {
					if(i != j) {
						fn += confusion[i][j];
					}
				}
				
				//compute the number of false positives
				for(int j = 0; j < 4; j++) {
					if(i != j) {
						fp += confusion[j][i];
					}
				}
			}
			
			//compute the overall precision, recall and f measure
			if(tp + fp == 0) {
				precisionMicro = 1;
			} else {
				precisionMicro = tp * 1.0 / (tp + fp);
			}
			
			if(tp + fn == 0) {
				recallMicro = 1;
			} else {
				recallMicro = tp * 1.0 / (tp + fn);
			}
			
			if(precisionMicro == 0 || recallMicro == 0) {
				//System.out.println(precision + " " + recall);
				FMicro = 0;
			} else {
				FMicro = 2 * precisionMicro * recallMicro / (precisionMicro + recallMicro);
			}
			
			return;
		}
		
		/**
		 * Compute the macro averaged value for precision, recall, and F.
		 * */
		private void computeMacro(boolean intuitive) {
			double recalls[] = new double[4];
			double precisions[] = new double[4];
			double fs[] = new double[4];
			boolean includes[] = {true, true, true, true};
			
			for(int i = 0; i < 4; i++) {
				int truePositive = 0, falseNegative = 0, falsePositive = 0;
				//compute the number of true positives
				truePositive = confusion[i][i];
				
				//compute the number of false negatives
				for(int j = 0; j < 5; j++) {
					if(i != j) {
						falseNegative += confusion[i][j];
					}
				}
				
				//compute the number of false positives
				for(int j = 0; j < 4; j++) {
					if(i != j) {
						falsePositive += confusion[j][i];
					}
				}
				
				//compute the precision, recall and f measure
				if(truePositive + falsePositive == 0) {
					precisions[i] = 1;
				} else {
					precisions[i] = truePositive * 1.0 / (truePositive + falsePositive);
				}
				
				if(truePositive + falseNegative == 0) {
					//if there are not judgments of such type, don't include them in the macro computation
					recalls[i] = 1;
					includes[i] = false;
				} else {
					recalls[i] = truePositive * 1.0 / (truePositive + falseNegative);
				}
				
				if(precisions[i] == 0 || recalls[i] == 0) {
					fs[i] = 0;
				} else {
					fs[i] = 2 * precisions[i] * recalls[i] / (precisions[i] + recalls[i]);
				}
			}
			
			if(intuitive) {
				includes[3] = false;
			}
			
			FMacro = 0;
			precisionMacro = 0;
			recallMacro = 0;
			
			int n = 0;
			for(int i = 0; i < 4; i++) {
				if(includes[i]) {
					FMacro += fs[i];
					precisionMacro += precisions[i];
					recallMacro += recalls[i];
					n++;
				}
			}
			
			FMacro = FMacro / n;
			precisionMacro = precisionMacro / n;
			recallMacro = recallMacro / n;
		}
		
		/**
		 * Compute the evaluation metrics,
		 * Including micro and macro Precision, Recall, and F.
		 * */
		public void compute(boolean intuitive) {
			computeMicro();
			computeMacro(intuitive);
		}
		
		/**
		 * Print out the confusion matrix.
		 * */
		public void printMatrix() {
			for(int i = 0; i < 5; i++) {
				for(int j = 0; j < 5; j++) {
					System.out.print(confusion[i][j] + "\t");
				}
				System.out.println();
			}
		}
	}
}
