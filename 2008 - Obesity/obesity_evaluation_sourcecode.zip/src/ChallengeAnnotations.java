import java.util.*;
import java.io.*;

/**
 * Organize the annotations in a list.
 * */
public class ChallengeAnnotations {
	//
	//constants
	//
	
	//
	//fields
	//
	private ArrayList<ChallengeAnnotation> list;
	
	//
	//constructor
	//
	/**
	 * Default Constructor.
	 * */
	public ChallengeAnnotations() {
		list = new ArrayList<ChallengeAnnotation>();
	}
	
	//
	//methods
	//
	/**
	 * Add a new annotation to the annotation list.
	 * */
	public void addAnnotation(ChallengeAnnotation a) {
		list.add(a);
	}
	
	/**
	 * Retrieve the list of annotations by id.
	 * Return the list of annotations for the given id.
	 * */
	public ChallengeAnnotations getListByID(int id) {
		ChallengeAnnotations alist = new ChallengeAnnotations();
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).id == id) {
				alist.addAnnotation(list.get(i));
			}
		}
		return alist;
	}
	
	/**
	 * Retrieve the list of annotations by source.
	 * */
	public ChallengeAnnotations getListBySource(String source) {
		ChallengeAnnotations cas = new ChallengeAnnotations();
		for(ChallengeAnnotation ca : list) {
			if(ca.type.equals(source)) {
				cas.addAnnotation(ca);
			}
		}
		return cas;
	}
	
	/**
	 * Retrieve the list of annotations by judgment.
	 * */
	public ChallengeAnnotations getListByJudgment(String judgment) {
		ChallengeAnnotations cas = new ChallengeAnnotations();
		for(ChallengeAnnotation ca : list) {
			if(ca.judgment.equals(judgment)) {
				cas.addAnnotation(ca);
			}
		}
		return cas;
	}
	
	/**
	 * Retrieve the list of annotations by disease.
	 * */
	public ChallengeAnnotations getListByDisease(String disease) {
		ChallengeAnnotations cas = new ChallengeAnnotations();
		for(ChallengeAnnotation ca : list) {
			if(ca.disease.equals(disease)) {
				cas.addAnnotation(ca);
			}
		}
		return cas;
	}
	
	/**
	 * Retrieve the first annotation by id.
	 * */
	public ChallengeAnnotation getByID(int id) {
		for(ChallengeAnnotation ca : list) {
			if(ca.id == id) {
				return ca;
			}
		}
		
		return null;
	}
	
	/**
	 * Get the ids of records.
	 * */
	public HashSet<Integer> getIDs() {
		HashSet<Integer> set = new HashSet<Integer>();
		for(ChallengeAnnotation ca : list) {
			set.add(ca.id);
		}
		return set;
	}
	
	/**
	 * Return the size of the the annotation list.
	 * */
	public int size() {
		return list.size();
	}
	
	/**
	 * Parse the file, read the annotations into the list.
	 * Currently, the parser can manipulate csv and xml files.
	 * In addition, all the annotations are organized by diseases.
	 * If the input file is a csv file, other two parameters must be specified
	 * @param filename the String of the name of the file
	 * @param disease the String of the disease
	 * @param type the String of the judgment type
	 * @return null if the file type can not be identified explicitly.
	 * */
	public static ChallengeAnnotations parse(String filename, String disease, String type) {
		ChallengeAnnotations list = new ChallengeAnnotations();
		//look at the file name and get the file type
		int i = 0;
		i = filename.lastIndexOf('.');
		if(i < 0) {
			System.err.println("Unknown file type, terminate parsing.");
			return null;
		}
		String filetype = filename.substring(i + 1);
		if(filetype.equals("csv")) {
			//if the annotations in the file are related to one disease
			try {
				System.out.println("parsing...");
				//initialize the file reader
				BufferedReader reader = new BufferedReader(new FileReader(filename));
				String line = null;
				boolean readHeader = false;
				while(true) {
					line = reader.readLine();
					if(line == null) {
						//if reaching to the end of the file
						break;
					}
					
					//analyze the string
					//parse the header string if applicable
					int i1 = line.indexOf(',');
					if(i1 < 0) {
						//not a useful string, discard it
						continue;
					}
					String s1 = line.substring(0, i1).trim();
					String s2 = line.substring(i1 + 1).trim();
					
					if(!readHeader) {
						//if not read header yet
						try {
							Integer.parseInt(s1);
						} catch(NumberFormatException nfe) {
							//if exception is thrown, we are confronted with header line
							readHeader = true;
							continue;
						}
					}
					
					//insert the annotation
					int id = Integer.parseInt(s1);
					ChallengeAnnotation ca = new ChallengeAnnotation();
					ca.id = id;
					ca.disease = disease;
					ca.type = type;
					ca.judgment = s2;
					if(ChallengeAnnotation.removeIDs.contains(id)) {
						System.out.println("---" + id);
						continue;
					}
					list.addAnnotation(ca);
					//System.out.println("Add annotation");
				}
				
				//close the reader
				reader.close();
			} catch(IOException ioe) {
				ioe.printStackTrace();
			}
		} else if(filetype.equals("xml")) {
	        //define a Reader
	        try {
	        	BufferedReader reader = new BufferedReader(new FileReader(filename));
	        	String line = null;
	        	while(true) {
	        		line = reader.readLine();
	        		if(line == null) {
	        			break;
	        		}
	        		
	        		//locate the set of diseases
	        		if(line.startsWith("<diseases source=")) {
	        			//get the source
	        			int si, ei;
	        			si = line.indexOf('\"');
	        			ei = line.indexOf('\"', si + 1);
	        			String source = line.substring(si + 1, ei);
	        			
	        			//get the diseases
	        			while(true) {
	        				line = reader.readLine();
	        				if(line.startsWith("<disease name=")) {
	        					si = line.indexOf('\"');
	        					ei = line.indexOf('\"', si + 1);
	    	        			String diseaseStr = line.substring(si + 1, ei);
	    	        			
	    	        			//get the annotations
	    	        			while(true) {
	    	        				line = reader.readLine();
	    	        				if(line.startsWith("<doc ")) {
	    	        					si = line.indexOf('\"');
	    	        					ei = line.indexOf('\"', si + 1);
	    	    	        			String idStr = line.substring(si + 1, ei);
	    	    	        			
	    	    	        			si = line.indexOf('\"', ei + 1);
	    	        					ei = line.indexOf('\"', si + 1);
	    	        					//System.out.println(line);
	    	    	        			String judgmentStr = line.substring(si + 1, ei);
	    	    	        			
	    	    	        			ChallengeAnnotation ca = new ChallengeAnnotation();
	    	    	        			ca.type = source;
	    	    	        			ca.disease = diseaseStr;
	    	    	        			ca.id = Integer.parseInt(idStr);
	    	    	        			ca.judgment = judgmentStr;
	    	    	        			list.addAnnotation(ca);
	    	        				} else if(line.startsWith("</disease>")) {
	    	        					break;
	    	        				}
	    	        			}
	        				} else if(line.startsWith("</diseases>")) {
	        					break;
	        				}
	        			}
	        		} else if(line.startsWith("</diseaseset>")) {
	        			break;
	        		}
	        	}
	        } catch(IOException ioe) {
	        	ioe.printStackTrace();
	        }
		} else {
			System.err.println("Unknown file type, terminate parsing.");
			return null;
		}
		return list;
	}
	
	/**
	 * Add a new list of annotations to the original list. 
	 * */
	public void addAnnotations(ChallengeAnnotations cas) {
		for(int i = 0; i < cas.list.size(); i++) {
			this.addAnnotation(cas.list.get(i));
		}
	}
	
	/**
	 * Sort the list by disease, then by id.
	 * Use a sorting method similar to radix sort.
	 * */
	public void sort() {
		//sort by judgment type
		ArrayList<ChallengeAnnotation> newList = new ArrayList<ChallengeAnnotation>();
		//add the annotations with judgment type intuitive
		for(ChallengeAnnotation ca : list) {
			if(ca.type.equals("intuitive")) {
				//System.out.println("f");
				newList.add(ca);
			}
		}
		
		//add the annotations with judgment type textual
		for(ChallengeAnnotation ca : list) {
			if(ca.type.equals("textual")) {
				newList.add(ca);
			}
		}
		
		//sort by id, use simple insertion sort
		ArrayList<ChallengeAnnotation> newList1 = new ArrayList<ChallengeAnnotation>();
		for(int i = 0; i < newList.size(); i++) {
			ChallengeAnnotation ca = newList.get(i);
			int j = 0;
			for(; j < i; j++) {
				if(ca.id < newList1.get(j).id) {
					break;
				}
			}
			
			newList1.add(j, ca);
		}
		

		//sort by disease
		newList = new ArrayList<ChallengeAnnotation>();
		//add disease Asthma
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Asthma")) {
				newList.add(ca);
			}
		}
		
		//add disease CAD
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("CAD")) {
				newList.add(ca);
			}
		}
		
		//add disease CHF
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("CHF")) {
				newList.add(ca);
			}
		}
		
		//add disease Depression
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Depression")) {
				newList.add(ca);
			}
		}
		
		//add disease Diabetes
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Diabetes")) {
				newList.add(ca);
			}
		}

		//add disease Gallstones
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Gallstones")) {
				newList.add(ca);
			}
		}
		
		//add disease GERD
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("GERD")) {
				newList.add(ca);
			}
		}
		
		//add disease Gout
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Gout")) {
				newList.add(ca);
			}
		}
		
		//add disease Hypercholesterolemia
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Hypercholesterolemia")) {
				newList.add(ca);
			}
		}
		
		//add disease Hypertension
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Hypertension")) {
				newList.add(ca);
			}
		}
		
		//add disease Hypertriglyceridemia
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Hypertriglyceridemia")) {
				newList.add(ca);
			}
		}
		
		//add disease OA
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("OA")) {
				newList.add(ca);
			}
		}
		
		//add disease Obesity
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Obesity")) {
				newList.add(ca);
			}
		}
		
		//add disease OSA
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("OSA")) {
				newList.add(ca);
			}
		}
		
		//add disease PVD
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("PVD")) {
				newList.add(ca);
			}
		}
		
		//add disease Venous Insufficiency
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Venous Insufficiency")) {
				newList.add(ca);
			}
		}

		list = newList;
	}
	
	/**
	 * Sort the list by source, then by disease.
	 * Use a sorting method similar to radix sort.
	 * */
	public void sortBySource() {
		//sort by id, use simple insertion sort
		ArrayList<ChallengeAnnotation> newList1 = new ArrayList<ChallengeAnnotation>();
		for(int i = 0; i < list.size(); i++) {
			ChallengeAnnotation ca = list.get(i);
			int j = 0;
			for(; j < i; j++) {
				if(ca.id < newList1.get(j).id) {
					break;
				}
			}
			
			newList1.add(j, ca);
		}

		ArrayList<ChallengeAnnotation> newList = new ArrayList<ChallengeAnnotation>();
		//add disease Asthma
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Asthma")) {
				newList.add(ca);
			}
		}
		
		//add disease CAD
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("CAD")) {
				newList.add(ca);
			}
		}
		
		//add disease CHF
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("CHF")) {
				newList.add(ca);
			}
		}
		
		//add disease Depression
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Depression")) {
				newList.add(ca);
			}
		}
		
		//add disease Diabetes
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Diabetes")) {
				newList.add(ca);
			}
		}

		//add disease Gallstones
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Gallstones")) {
				newList.add(ca);
			}
		}
		
		//add disease GERD
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("GERD")) {
				newList.add(ca);
			}
		}
		
		//add disease Gout
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Gout")) {
				newList.add(ca);
			}
		}
		
		//add disease Hypercholesterolemia
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Hypercholesterolemia")) {
				newList.add(ca);
			}
		}
		
		//add disease Hypertension
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Hypertension")) {
				newList.add(ca);
			}
		}
		
		//add disease Hypertriglyceridemia
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Hypertriglyceridemia")) {
				newList.add(ca);
			}
		}
		
		//add disease OA
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("OA")) {
				newList.add(ca);
			}
		}
		
		//add disease Obesity
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Obesity")) {
				newList.add(ca);
			}
		}
		
		//add disease OSA
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("OSA")) {
				newList.add(ca);
			}
		}
		
		//add disease PVD
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("PVD")) {
				newList.add(ca);
			}
		}
		
		//add disease Venous Insufficiency
		for(ChallengeAnnotation ca : newList1) {
			if(ca.disease.equals("Venous Insufficiency")) {
				newList.add(ca);
			}
		}
		
		newList1 = new ArrayList<ChallengeAnnotation>();
		//add the annotations with judgment type intuitive
		for(ChallengeAnnotation ca : newList) {
			if(ca.type.equals("intuitive")) {
				//System.out.println("f");
				newList1.add(ca);
			}
		}
		
		//add the annotations with judgment type textual
		for(ChallengeAnnotation ca : newList) {
			if(ca.type.equals("textual")) {
				newList1.add(ca);
			}
		}

		list = newList1;
	}
	
	/**
	 * Translator.
	 * */
	private static String translateSource(int i) {
		switch(i) {
		case 0 : return "Y";
		case 1 : return "N";
		case 2 : return "Q";
		case 3 : return "U";
		default : return "";
		}
	}
	
	/**
	 * Select the annotations from the list, and return them.
	 * Remove them from the original list.
	 * */
	public ChallengeAnnotations deleteAnnotaions(HashSet<Integer> ids) {
		ChallengeAnnotations cas = new ChallengeAnnotations();
		
		//add the records to the new list
		for(Object o : ids) {
			int id = (Integer)o;
			cas.addAnnotations(this.getListByID(id));
		}
		
		//remove the records from the original list
		for(ChallengeAnnotation ca : cas.list) {
			this.list.remove(ca);
		}
		
		return cas;
	}
	
	/**
	 * To String.
	 * */
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for(ChallengeAnnotation ca : list) {
			sb.append(ca.toString() + "\n");
		}
		return sb.toString();
	}
	
	/**
	 * To String in XML format, organized in disease.
	 * Before output to XML String, the list must have been sorted by disease.
	 * */
	public String toStringXMLByDisease() {
		StringBuffer sb = new StringBuffer();
		//set the format
		ChallengeAnnotation.Format format = new ChallengeAnnotation.Format();
		format.setType(true);
		format.setJudgment(true);
		
		//output the annotations
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		sb.append("<diseases>\n");
		String disease = null;
		int id = -1;
		for(ChallengeAnnotation ca : list) {
			if(!ca.disease.equals(disease)) {
				//come up with a new disease
				if(disease != null) {
					sb.append("\t</disease>\n");
				}
				disease = ca.disease;
				sb.append("\t<disease name=\"" + disease + "\">\n");
				id = ca.id;
				sb.append("\t\t<doc id=\"" + id + "\">\n");
			}

			if(ca.id != id) {
				//come up with a new record
				sb.append("\t\t</doc>\n");
				id = ca.id;
				sb.append("\t\t<doc id=\"" + id + "\">\n");
			}
			
			//output the record
			sb.append("\t\t\t" + ca.toXMLString(format) + "\n");
		}
		sb.append("\t\t</doc>\n");
		sb.append("\t</disease>\n");
		sb.append("</diseases>\n");
		return sb.toString();
	}
	
	/**
	 * To String in XML format. Before output, the list must be sorted by
	 * source.
	 * */
	public String toStringXMLBySource() {
		StringBuffer sb = new StringBuffer();
		//set the format
		ChallengeAnnotation.Format format = new ChallengeAnnotation.Format();
		format.setID(true);
		format.setJudgment(true);
		
		//output the annotations
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		sb.append("<diseaseset>\n");
		String source = null;			//source is the judgment type
		String disease = null;
		for(ChallengeAnnotation ca : list) {
			if(!ca.type.equals(source)) {
				//come up with a new source
				if(disease != null) {
					sb.append("</disease>\n");
					sb.append("</diseases>\n");
				}
				source = ca.type;
				sb.append("<diseases source=\"" + source + "\">\n");
				disease = ca.disease;
				sb.append("<disease name=\"" + disease + "\">\n");
			}
			
			if(!ca.disease.equals(disease)) {
				//come up with a disease
				sb.append("</disease>\n");
				disease = ca.disease;
				sb.append("<disease name=\"" + disease + "\">\n");
			}
			
			//output the record
			sb.append(ca.toXMLString(format) + "\n");
		}
		sb.append("</disease>\n");
		sb.append("</diseases>\n");
		sb.append("</diseaseset>\n");
		return sb.toString();
	}
	
	/**
	 * Evaluate another list of annotations.
	 * Print the result to the standard output stream.
	 * */
	public double evaluate(ChallengeAnnotations cas) {
		int total;
		double missY, missN, missQ, missU, score;
		
		total = list.size();
		
		//compute miss yes probability
		HashSet<Integer> set1 = getListByJudgment("Y").getIDs();			//ground truth set
		HashSet<Integer> set2 = cas.getListByJudgment("Y").getIDs();		//output set
		set1.removeAll(set2);
		missY = 1.0 * set1.size() / total;
		
		//compute miss no probability
		set1 = getListByJudgment("N").getIDs();			//ground truth set
		set2 = cas.getListByJudgment("N").getIDs();		//output set
		set1.removeAll(set2);
		missN = 1.0 * set1.size() / total;
		
		//compute miss questionable probability
		set1 = getListByJudgment("Q").getIDs();			//ground truth set
		set2 = cas.getListByJudgment("Q").getIDs();		//output set
		set1.removeAll(set2);
		missQ = 1.0 * set1.size() / total;
		
		//compute miss unmentioned probability
		set1 = getListByJudgment("U").getIDs();			//ground truth set
		set2 = cas.getListByJudgment("U").getIDs();		//output set
		set1.removeAll(set2);
		missU = 1.0 * set1.size() / total;
		
		score = 1.0 * missY + 1.0 * missN + 1.0 * missQ + 1.0 * missU;
		return score;
	}
	
	/**
	 * Evaluate another list of annotations using F measure.
	 * This is an old version, should not be used any more.
	 * Print the result to the standard output stream.
	 * */
	public double evaluateF1(ChallengeAnnotations cas, boolean micro, boolean intuitive) {
		double score;
		double fY, fN, fQ, fU;
		int truePositive = 0, falsePositive = 0, falseNegative = 0;
		double recall, precision;
		HashSet<Integer> setGround, setResult, set;
		HashSet<Integer> setGroundWhole;
		
		setGroundWhole = this.getIDs();
		
		//analyze YES
		setGround = new HashSet<Integer>();
		setResult = new HashSet<Integer>();
		set = new HashSet<Integer>();
		for(ChallengeAnnotation ca : list) {
			if(ca.judgment.equals("Y")) {
				setGround.add(ca.id);
			}
		}
		for(ChallengeAnnotation ca : cas.list) {
			if(ca.judgment.equals("Y")) {
				setResult.add(ca.id);
			}
		}
		setResult.retainAll(setGroundWhole);
		set.addAll(setGround);
		set.retainAll(setResult);
		recall = set.size() * 1.0 / setGround.size();
		precision = set.size() * 1.0 / setResult.size();
		
		if(setGround.size() != 0) {
			if(set.size() == 0) {
				fY = 0.0;
			} else {
				fY = 2 * recall * precision / (recall + precision);
			}
		} else {
			fY = 1.0;
		}
		
		truePositive += set.size();
		falsePositive += setResult.size() - set.size();
		falseNegative += setGround.size() - set.size();
		
		//analyze NO
		setGround = new HashSet<Integer>();
		setResult = new HashSet<Integer>();
		set = new HashSet<Integer>();
		for(ChallengeAnnotation ca : list) {
			if(ca.judgment.equals("N")) {
				setGround.add(ca.id);
			}
		}
		for(ChallengeAnnotation ca : cas.list) {
			if(ca.judgment.equals("N")) {
				setResult.add(ca.id);
			}
		}
		setResult.retainAll(setGroundWhole);
		set.addAll(setGround);
		set.retainAll(setResult);
		recall = set.size() * 1.0 / setGround.size();
		precision = set.size() * 1.0 / setResult.size();
		
		if(setGround.size() != 0) {
			if(set.size() == 0) {
				fN = 0.0;
			} else {
				fN = 2 * recall * precision / (recall + precision);
			}
		} else {
			fN = 1.0;
		}
		
		truePositive += set.size();
		falsePositive += setResult.size() - set.size();
		falseNegative += setGround.size() - set.size();
		
		//analyze QUESTIONABLE
		setGround = new HashSet<Integer>();
		setResult = new HashSet<Integer>();
		set = new HashSet<Integer>();
		for(ChallengeAnnotation ca : list) {
			if(ca.judgment.equals("Q")) {
				setGround.add(ca.id);
			}
		}
		for(ChallengeAnnotation ca : cas.list) {
			if(ca.judgment.equals("Q")) {
				setResult.add(ca.id);
			}
		}
		setResult.retainAll(setGroundWhole);
		set.addAll(setGround);
		set.retainAll(setResult);
		recall = set.size() * 1.0 / setGround.size();
		precision = set.size() * 1.0 / setResult.size();

		if(setGround.size() != 0) {
			if(set.size() == 0) {
				fQ = 0.0;
			} else {
				fQ = 2 * recall * precision / (recall + precision);
			}
		} else {
			fQ = 1.0;
		}
		
		truePositive += set.size();
		falsePositive += setResult.size() - set.size();
		falseNegative += setGround.size() - set.size();
		
		//analyze UNMENTIONED
		setGround = new HashSet<Integer>();
		setResult = new HashSet<Integer>();
		set = new HashSet<Integer>();
		for(ChallengeAnnotation ca : list) {
			if(ca.judgment.equals("U")) {
				setGround.add(ca.id);
			}
		}
		for(ChallengeAnnotation ca : cas.list) {
			if(ca.judgment.equals("U")) {
				setResult.add(ca.id);
			}
		}
		setResult.retainAll(setGroundWhole);
		set.addAll(setGround);
		set.retainAll(setResult);
		recall = set.size() * 1.0 / setGround.size();
		precision = set.size() * 1.0 / setResult.size();
		
		if(setGround.size() != 0) {
			if(set.size() == 0) {
				fU = 0.0;
			} else {
				fU = 2 * recall * precision / (recall + precision);
			}
		} else {
			fU = 1.0;
		}
		
		truePositive += set.size();
		falsePositive += setResult.size() - set.size();
		falseNegative += setGround.size() - set.size();
		
		if(micro) {
			if(truePositive + falseNegative == 0) {
				score = 1.0;
			} else {
				if(truePositive == 0) {
					score = 0.0;
				} else {
					recall = truePositive * 1.0 / (truePositive + falseNegative);
					precision = truePositive * 1.0 / (truePositive + falsePositive);
					score = 2 * recall * precision / (precision + recall);
				}
			}
		} else {
			if(intuitive) {
				score = (fY + fN + fQ) / 3;
			} else {
				score = (fY + fN + fQ + fU) / 4;
			}
		}
		
		return score;
	}
	
	/**
	 * Evaluate another list of annotations using F measure, by using the current list of annotations.
	 * The two lists of annotations should be of the same disease, and the same source.
	 * Print the result to the standard output stream.
	 * */
	public Evaluation.Score evaluateF(ChallengeAnnotations cas) {
		Evaluation.Score score;												//the score to be returned
		HashSet setsGround[] = new HashSet[4];								//the sets from ground truth
		HashSet setsResult[] = new HashSet[4];								//the sets from output result
		HashSet<Integer> set;
		HashSet<Integer> setGroundWhole;
		HashSet<Integer> setResultWhole;
		
		//initialization
		score = new Evaluation.Score();
		setGroundWhole = this.getIDs();
		setResultWhole = cas.getIDs();
		for(int i = 0; i < 4; i++) {
			setsGround[i] = new HashSet<Integer>();
			setsResult[i] = new HashSet<Integer>();
		}
		
		//construct the sets of the ground truth
		for(ChallengeAnnotation ca : list) {
			if(ca.judgment.equals("Y")) {
				setsGround[0].add(ca.id);
			} else if(ca.judgment.equals("N")) {
				setsGround[1].add(ca.id);
			} else if(ca.judgment.equals("Q")) {
				setsGround[2].add(ca.id);
			} else if(ca.judgment.equals("U")) {
				setsGround[3].add(ca.id);
			} else {
				//System.out.println(ca.id);
				//System.out.println("Illegal judgement");
			}
		}
		
		//construct the sets of the result output
		for(ChallengeAnnotation ca : cas.list) {
			if(ca.judgment.equals("Y")) {
				setsResult[0].add(ca.id);
			} else if(ca.judgment.equals("N")) {
				setsResult[1].add(ca.id);
			} else if(ca.judgment.equals("Q")) {
				setsResult[2].add(ca.id);
			} else if(ca.judgment.equals("U")) {
				setsResult[3].add(ca.id);
			} else {
				//System.out.println(ca.id);
				//System.out.println("Illegal judgement");
			}
		}
		
		//compute the confusion matrix
		int i = 0;
		for(; i < 4; i++) {
			int j = 0;
			for(; j < 4; j++) {
				set = new HashSet<Integer>();
				//System.out.println(i + " " + j);
				set.addAll(setsResult[j]);
				set.retainAll(setsGround[i]);
				score.confusion[i][j] = set.size();
			}
			
			setsGround[i].removeAll(setResultWhole);
			score.confusion[i][j] = setsGround[i].size();
		}
		
		for(int j = 0; j < 4; j++) {
			setsResult[j].removeAll(setGroundWhole);
			score.confusion[i][j] = setsResult[j].size();
		}
		
		return score;
	}
	
	/**
	 * Test main method.
	 * */
	public static void main(String args[]) {
		ChallengeAnnotations cas = parse("output.xml", null, null);
		System.out.println(cas.toStringXMLBySource());
	}
}
