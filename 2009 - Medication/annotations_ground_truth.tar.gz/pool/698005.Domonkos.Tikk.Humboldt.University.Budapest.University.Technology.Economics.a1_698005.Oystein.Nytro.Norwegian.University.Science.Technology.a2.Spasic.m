1:
m="epinephrine" 20:0 20:0
do="0.5" 19:7 19:7
mo="nm"
f="nm"
du="nm"
r="proper pressure" 20:3 20:4
ln="narrative"
2:
m="epinephrine" 20:5 20:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="epinephrine" 22:6 22:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="beta blocker" 24:3 24:4
do="low dose" 24:1 24:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="baby aspirin" 26:8 26:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="neurontin" 40:2 40:2
do="300 mg" 40:3 40:4
mo="nm"
f="q.d." 40:5 40:5
du="nm"
r="nm"
ln="narrative"
7:
m="enteric-coated aspirin" 72:2 72:3
do="81 mg" 72:4 72:5
mo="p.o." 72:6 72:6
f="q.d." 72:7 72:7
du="nm"
r="nm"
ln="list"
8:
m="colace" 73:0 73:0
do="100 mg" 73:1 73:2
mo="p.o." 73:3 73:3
f="b.i.d." 73:4 73:4
du="x 7 days" 73:5 73:7
r="nm"
ln="list"
9:
m="lasix" 73:9 73:9
do="60 mg" 73:10 73:11
mo="p.o." 73:12 73:12
f="q.d." 73:13 73:13
du="nm"
r="nm"
ln="list"
10:
m="ibuprofen" 74:0 74:0
do="800 mg" 74:1 74:2
mo="p.o." 74:3 74:3
f="q.8h. p.r.n." 74:4 74:5
du="nm"
r="pain" 74:6 74:6
ln="list"
11:
m="lopressor" 74:8 74:8
do="25 mg" 74:9 74:10
mo="p.o." 74:11 74:11
f="t.i.d." 75:0 75:0
du="nm"
r="nm"
ln="list"
12:
m="atrovent nebulizer" 75:8 75:9
do="0.5 mg" 75:10 75:11
mo="nebulized" 76:0 76:0
f="q.i.d." 76:1 76:1
du="nm"
r="nm"
ln="list"
13:
m="niferex" 75:2 75:2
do="150 mg" 75:3 75:4
mo="p.o." 75:5 75:5
f="b.i.d." 75:6 75:6
du="nm"
r="nm"
ln="list"
14:
m="k-dur" 76:9 76:9
do="30 meq" 76:10 76:11
mo="p.o." 76:12 76:12
f="q.d." 77:0 77:0
du="nm"
r="nm"
ln="list"
15:
m="neurontin" 76:3 76:3
do="300 mg" 76:4 76:5
mo="p.o." 76:6 76:6
f="q.d." 76:7 76:7
du="nm"
r="nm"
ln="list"
16:
m="lasix" 77:7 77:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="flovent" 78:1 78:1
do="44 mcg/inh" 78:2 78:3
mo="nm"
f="b.i.d." 78:4 78:4
du="nm"
r="nm"
ln="list"
