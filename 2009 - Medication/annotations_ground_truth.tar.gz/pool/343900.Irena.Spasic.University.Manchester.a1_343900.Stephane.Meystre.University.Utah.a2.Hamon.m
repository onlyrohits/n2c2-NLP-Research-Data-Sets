1:
m="rhogam" 16:6 16:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="synthroid" 21:0 21:0
do="0.015 mg" 21:1 21:2
mo="nm"
f="daily" 21:3 21:3
du="nm"
r="hyperthyroidism" 20:0 20:0
ln="narrative"
3:
m="synthroid" 32:3 32:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="vitamins" 32:5 32:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="insulin" 48:1 48:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood sugars" 47:7 47:8
ln="narrative"
6:
m="insulin" 51:2 51:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood sugars" 49:9 49:10
ln="narrative"
7:
m="insulin" 52:4 52:4
do="nm"
mo="nm"
f="nm"
du="several days." 52:8 52:9
r="her fasting blood sugar" 52:10 53:2
ln="narrative"
8:
m="insulin" 55:1 55:1
do="ten units" 55:2 55:3
mo="nm"
f="qam" 55:6 55:6
du="nm"
r="nm"
ln="list"
9:
m="insulin...regular" 55:1 55:1,55:5 55:5
do="16 units" 56:4 56:5
mo="nm"
f="qpm." 56:7 56:7
du="nm"
r="nm"
ln="list"
10:
m="nph" 56:6 56:6
do="16 units" 56:4 56:5
mo="nm"
f="qpm" 56:7 56:7
du="nm"
r="nm"
ln="list"
