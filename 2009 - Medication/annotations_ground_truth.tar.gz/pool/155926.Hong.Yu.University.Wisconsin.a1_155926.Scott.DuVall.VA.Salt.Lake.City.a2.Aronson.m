1:
m="streptokinase" 19:5 19:5
do="nm"
mo="iv" 19:4 19:4
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="tpa." 19:7 19:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="nitroglycerin." 24:5 24:5
do="nm"
mo="sl" 24:4 24:4
f="nm"
du="nm"
r="typical substernal chest pain" 23:2 23:5
ln="narrative"
4:
m="nitroglycerin." 28:0 28:0
do="nm"
mo="sl" 27:11 27:11
f="nm"
du="nm"
r="pain" 27:6 27:6
ln="narrative"
5:
m="nitrates" 30:5 30:5
do="nm"
mo="sl" 30:2 30:2
f="nm"
du="nm"
r="her chest pain" 30:10 31:1
ln="narrative"
6:
m="nitrates" 30:5 30:5
do="nm"
mo="topical" 30:4 30:4
f="nm"
du="nm"
r="chest pain" 31:0 31:1
ln="narrative"
7:
m="beta blockade" 35:10 35:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="heparin" 35:5 35:5
do="nm"
mo="iv" 35:4 35:4
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="nitroglycerin" 35:8 35:8
do="nm"
mo="iv" 35:7 35:7
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="aspirin." 36:1 36:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="nitroglycerin" 45:5 45:5
do="140 micrograms" 45:7 46:0
mo="iv" 45:4 45:4
f="per minute" 46:1 46:2
du="nm"
r="nm"
ln="list"
12:
m="aspirin" 46:10 46:10
do="one" 46:11 46:11
mo="nm"
f="a day." 46:12 47:0
du="nm"
r="nm"
ln="list"
13:
m="heparin drip" 46:5 46:6
do="nm"
mo="iv" 46:4 46:4
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="lopressor" 46:8 46:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="heparin." 67:11 67:11
do="nm"
mo="iv" 67:10 67:10
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="calcium channel blocker" 91:6 91:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="mild hypertension" 90:5 90:6
ln="narrative"
17:
m="nitroglycerins" 94:6 94:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="chest pain" 93:3 93:4
ln="narrative"
18:
m="antacids" 95:0 95:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="chest pain" 93:3 93:4
ln="narrative"
19:
m="nifedipine xl" 106:5 106:6
do="90 mg" 106:7 107:0
mo="po" 107:1 107:1
f="q am" 107:2 107:3
du="nm"
r="nm"
ln="list"
20:
m="lopressor" 107:5 107:5
do="50 mg" 107:6 107:7
mo="po" 107:8 107:8
f="b.i.d." 107:9 107:9
du="nm"
r="nm"
ln="list"
21:
m="zantac" 107:11 107:11
do="150 mg" 107:12 107:13
mo="po" 107:14 107:14
f="q hs" 107:15 107:16
du="nm"
r="nm"
ln="list"
22:
m="aspirin" 108:0 108:0
do="81 mg" 108:1 108:2
mo="po" 108:3 108:3
f="q d" 108:4 108:5
du="nm"
r="nm"
ln="list"
23:
m="serax" 108:7 108:7
do="15 mg" 108:8 108:9
mo="po" 108:10 108:10
f="q 6 h" 108:11 108:13
du="nm"
r="nm"
ln="list"
24:
m="serax" 108:7 108:7
do="15 mg" 108:8 108:9
mo="po" 108:10 108:10
f="q hs prn" 108:15 108:17
du="nm"
r="nm"
ln="list"
25:
m="nitroglycerin" 109:0 109:0
do="1/150 grain" 109:1 109:2
mo="sl" 109:8 109:8
f="q 5 minutes...prn" 109:3 109:5,109:9 109:9
du="x 3" 109:6 109:7
r="chest pain" 109:10 109:11
ln="list"
