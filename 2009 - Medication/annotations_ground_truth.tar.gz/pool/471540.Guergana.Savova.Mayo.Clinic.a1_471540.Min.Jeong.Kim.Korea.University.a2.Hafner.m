1:
m="tylenol ( acetaminophen )" 19:0 19:3
do="650 mg" 19:4 19:5
mo="po" 19:6 19:6
f="q4h prn" 19:7 19:8
du="nm"
r="headache" 19:11 19:11
ln="list"
2:
m="tylenol ( acetaminophen )" 19:0 19:3
do="650 mg" 19:4 19:5
mo="po" 19:6 19:6
f="q4h prn" 19:7 19:8
du="nm"
r="pain" 19:9 19:9
ln="list"
3:
m="amiodarone" 20:0 20:0
do="100 mg" 20:1 20:2
mo="po" 20:3 20:3
f="daily" 20:4 20:4
du="nm"
r="nm"
ln="list"
4:
m="coumadin" 23:3 23:3
do="nm"
mo="po" 23:4 23:4
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="amiodarone hcl" 24:3 24:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="warfarin" 24:6 24:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="coumadin" 28:3 28:3
do="nm"
mo="po" 28:4 28:4
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="amiodarone hcl" 29:3 29:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="warfarin" 29:6 29:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="coumadin" 32:3 32:3
do="nm"
mo="po" 32:4 32:4
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="amiodarone hcl" 33:3 33:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="warfarin" 33:6 33:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="coumadin" 36:3 36:3
do="nm"
mo="po" 36:4 36:4
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="amiodarone hcl" 37:3 37:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="warfarin" 37:6 37:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="coumadin" 40:3 40:3
do="nm"
mo="po" 40:4 40:4
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="amiodarone hcl" 41:3 41:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="warfarin" 41:6 41:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="coumadin" 44:3 44:3
do="nm"
mo="po" 44:4 44:4
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="amiodarone hcl" 45:3 45:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="warfarin" 45:6 45:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="natural tears ( artificial tears )" 47:0 47:5
do="2 drop" 47:6 47:7
mo="ou" 47:8 47:8
f="bid" 47:9 47:9
du="nm"
r="nm"
ln="list"
23:
m="colace ( docusate sodium )" 48:0 48:4
do="100 mg" 48:5 48:6
mo="po" 48:7 48:7
f="bid" 48:8 48:8
du="nm"
r="nm"
ln="list"
24:
m="plaquenil sulfate ( hydroxychloroquine )" 49:0 49:4
do="200 mg" 49:5 49:6
mo="po" 49:7 49:7
f="bid" 49:8 49:8
du="nm"
r="nm"
ln="list"
25:
m="isordil ( isosorbide dinitrate )" 51:0 51:4
do="20 mg" 51:5 51:6
mo="po" 51:7 51:7
f="tid" 51:8 51:8
du="nm"
r="nm"
ln="list"
26:
m="lisinopril" 53:0 53:0
do="20 mg" 53:1 53:2
mo="po" 53:3 53:3
f="daily" 53:4 53:4
du="nm"
r="nm"
ln="list"
27:
m="milk of magnesia ( magnesium hydroxide )" 54:0 54:6
do="30 milliliters" 55:0 55:1
mo="po" 55:2 55:2
f="daily prn" 55:3 55:4
du="nm"
r="constipation" 55:5 55:5
ln="list"
28:
m="coumadin ( warfarin sodium )" 56:0 56:4
do="2.5 mg" 56:5 56:6
mo="po" 56:7 56:7
f="qpm" 56:8 56:8
du="nm"
r="nm"
ln="list"
29:
m="coumadin" 58:3 58:3
do="2.5 mg/ 5mg" 58:4 58:6
mo="nm"
f="once daily" 58:7 58:8
du="nm"
r="nm"
ln="list"
30:
m="amiodarone hcl" 64:3 64:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="warfarin" 64:6 64:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="norvasc ( amlodipine )" 66:0 66:3
do="10 mg" 66:4 66:5
mo="po" 66:6 66:6
f="daily" 66:7 66:7
du="nm"
r="nm"
ln="list"
33:
m="neurontin ( gabapentin )" 69:0 69:3
do="300 mg" 69:4 69:5
mo="po" 69:6 69:6
f="tid" 69:7 69:7
du="nm"
r="nm"
ln="list"
34:
m="nexium ( esomeprazole )" 70:0 70:3
do="20 mg" 70:4 70:5
mo="po" 70:6 70:6
f="daily" 70:7 70:7
du="nm"
r="nm"
ln="list"
35:
m="maalox-tablets quick dissolve/chewable" 71:0 71:2
do="1-2 tab" 71:3 71:4
mo="po" 71:5 71:5
f="q6h prn" 71:6 72:0
du="nm"
r="upset stomach" 72:1 72:2
ln="list"
36:
m="dulcolax rectal ( bisacodyl rectal )" 73:0 73:5
do="10 mg" 73:6 73:7
mo="pr" 73:8 73:8
f="daily prn" 73:9 74:0
du="nm"
r="constipation" 74:1 74:1
ln="list"
37:
m="clotrimazole 1% topical" 75:0 75:2
do="nm"
mo="topical tp" 75:3 75:4
f="bid" 75:5 75:5
du="nm"
r="nm"
ln="list"
38:
m="glyburide" 77:0 77:0
do="5 mg" 77:1 77:2
mo="po" 77:3 77:3
f="bid" 77:4 77:4
du="nm"
r="nm"
ln="list"
39:
m="glyburide" 79:3 79:3
do="nm"
mo="po" 79:4 79:4
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="lasix ( furosemide )" 82:0 82:3
do="20 mg" 82:4 82:5
mo="po" 82:6 82:6
f="daily" 82:7 82:7
du="nm"
r="nm"
ln="list"
41:
m="lasix" 86:4 86:4
do="20" 86:5 86:5
mo="nm"
f="qd" 86:6 86:6
du="nm"
r="nm"
ln="narrative"
42:
m="lasix" 88:3 88:3
do="nm"
mo="po" 88:4 88:4
f="nm"
du="nm"
r="nm"
ln="list"
43:
m="amiodarone" 146:3 146:3
do="100" 146:4 146:4
mo="nm"
f="qd" 146:5 146:5
du="nm"
r="nm"
ln="list"
44:
m="colace" 146:7 146:7
do="100" 146:8 146:8
mo="nm"
f="bid" 146:9 146:9
du="nm"
r="nm"
ln="list"
45:
m="lasix" 146:11 146:11
do="40mg" 146:12 146:12
mo="nm"
f="qd" 147:0 147:0
du="nm"
r="nm"
ln="list"
46:
m="glyburide" 147:2 147:2
do="5mg" 147:3 147:3
mo="nm"
f="bid" 147:4 147:4
du="nm"
r="nm"
ln="list"
47:
m="isordil" 147:10 147:10
do="20mg" 147:11 147:11
mo="nm"
f="tid" 147:12 147:12
du="nm"
r="nm"
ln="list"
48:
m="lisinopril" 147:14 147:14
do="20mg" 148:0 148:0
mo="nm"
f="qd" 148:1 148:1
du="nm"
r="nm"
ln="list"
49:
m="plaquenil" 147:6 147:6
do="200mg" 147:7 147:7
mo="nm"
f="bid" 147:8 147:8
du="nm"
r="nm"
ln="list"
50:
m="coumadin" 148:3 148:3
do="2.5mg" 148:7 148:7
mo="nm"
f="4dys/week" 148:8 148:8
du="nm"
r="nm"
ln="list"
51:
m="coumadin" 148:3 148:3
do="5mg" 148:4 148:4
mo="nm"
f="3dys/week" 148:5 148:5
du="nm"
r="nm"
ln="list"
52:
m="norvasc" 148:10 148:10
do="10mg" 148:11 148:11
mo="nm"
f="qd" 148:12 148:12
du="nm"
r="nm"
ln="list"
53:
m="neurontin" 149:0 149:0
do="300mg" 149:1 149:1
mo="nm"
f="tid" 149:2 149:2
du="nm"
r="nm"
ln="list"
54:
m="apap" 173:1 173:1
do="nm"
mo="nm"
f="prn." 173:2 173:2
du="nm"
r="pain" 172:10 172:10
ln="narrative"
55:
m="ivf" 182:4 182:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="lasix" 184:1 184:1
do="half dose" 184:3 184:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="glypizide" 190:3 190:3
do="nm"
mo="nm"
f="nm"
du="while in house" 190:4 190:6
r="nm"
ln="narrative"
58:
m="novolog" 190:7 190:7
do="sliding scale" 190:8 190:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="nph" 191:3 191:3
do="6 units" 191:4 191:5
mo="nm"
f="bid" 191:6 191:6
du="nm"
r="nm"
ln="narrative"
60:
m="coumadin" 194:6 194:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="lovenox" 197:3 197:3
do="5/2.5mg variable dose." 198:3 198:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="home regimens" 198:0 198:1
do="5/25mg" 198:3 198:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="lasix" 201:8 201:8
do="80mg" 201:7 201:7
mo="nm"
f="daily" 201:9 201:9
du="nm"
r="nm"
ln="narrative"
64:
m="lasix" 202:5 202:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
65:
m="lasix" 202:9 202:9
do="20" 202:10 202:10
mo="nm"
f="qd" 202:11 202:11
du="nm"
r="nm"
ln="narrative"
66:
m="lovenox/coumadin" 205:3 205:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
67:
m="coumadin" 208:15 208:15
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
68:
m="statin" 211:3 211:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
