1:
m="aspirin" 13:9 13:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="adenosine" 14:7 14:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="heparin" 14:4 14:4
do="nm"
mo="drip" 14:5 14:5
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="lopressor" 14:2 14:2
do="5 mg" 13:10 13:11
mo="intravenous" 14:1 14:1
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="lisinopril" 50:4 50:4
do="10 mg" 50:5 50:6
mo="nm"
f="once a day" 50:7 50:9
du="nm"
r="nm"
ln="list"
6:
m="zocor" 50:11 50:11
do="40 mg" 51:0 51:1
mo="nm"
f="once a day" 51:2 51:4
du="nm"
r="nm"
ln="list"
7:
m="enteric coated aspirin" 51:9 51:11
do="325 mg" 52:0 52:1
mo="nm"
f="every other day" 52:2 52:4
du="nm"
r="nm"
ln="list"
8:
m="vitamin e" 51:6 51:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="nph humulin insulin" 52:6 52:8
do="10" 53:1 53:1
mo="nm"
f="in the evening" 53:2 53:4
du="nm"
r="nm"
ln="list"
10:
m="nph humulin insulin" 52:6 52:8
do="40 units" 52:9 52:10
mo="nm"
f="in the morning" 52:11 52:13
du="nm"
r="nm"
ln="list"
11:
m="regular insulin" 53:6 53:7
do="6 units" 53:8 53:9
mo="nm"
f="twice a day" 53:10 53:12
du="nm"
r="nm"
ln="list"
12:
m="multivitamin." 54:0 54:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="keflex" 71:11 71:11
do="500 mg" 71:12 71:13
mo="nm"
f="four times a day" 71:14 72:2
du="for 10 days" 72:3 72:5
r="nm"
ln="narrative"
14:
m="enteric coated aspirin" 79:8 80:1
do="325 mg" 80:2 80:3
mo="nm"
f="once a day" 80:4 80:6
du="nm"
r="nm"
ln="list"
15:
m="ibuprofen" 80:8 80:8
do="200 to 800 mg" 81:0 81:3
mo="nm"
f="every 4 to 6 h p.r.n." 81:4 81:9
du="nm"
r="pain" 81:10 81:10
ln="list"
16:
m="nph humulin insulin" 81:12 81:14
do="14 units" 82:5 82:6
mo="nm"
f="in the evening" 82:7 82:9
du="nm"
r="nm"
ln="list"
17:
m="nph humulin insulin" 81:12 81:14
do="44 units" 81:15 82:0
mo="nm"
f="in the morning" 82:1 82:3
du="nm"
r="nm"
ln="list"
18:
m="regular insulin" 82:11 82:12
do="6 units" 82:13 83:0
mo="nm"
f="twice a day" 83:1 83:3
du="nm"
r="nm"
ln="list"
19:
m="niferex" 83:5 83:5
do="150 mg" 83:6 83:7
mo="nm"
f="twice a day" 83:8 83:10
du="nm"
r="nm"
ln="list"
20:
m="potassium chloride" 83:12 83:13
do="20 meq" 84:0 84:1
mo="nm"
f="once a day" 84:2 84:4
du="nm"
r="nm"
ln="list"
21:
m="atenolol" 84:14 84:14
do="50 mg" 84:15 84:16
mo="nm"
f="once a day" 85:0 85:2
du="nm"
r="nm"
ln="list"
22:
m="zocor" 84:6 84:6
do="40 mg" 84:7 84:8
mo="nm"
f="once in the evening" 84:9 84:12
du="nm"
r="nm"
ln="list"
23:
m="keflex" 85:11 85:11
do="500 mg" 85:12 85:13
mo="nm"
f="four times a day" 85:14 86:0
du="for 10 days" 86:1 86:3
r="his superficial sternal wound infection" 86:5 86:9
ln="list"
24:
m="lisinopril" 85:4 85:4
do="10 mg" 85:5 85:6
mo="nm"
f="once a day" 85:7 85:9
du="nm"
r="nm"
ln="list"
25:
m="torsemide" 87:0 87:0
do="60 mg" 87:1 87:2
mo="nm"
f="twice a day." 87:3 87:5
du="nm"
r="nm"
ln="list"
