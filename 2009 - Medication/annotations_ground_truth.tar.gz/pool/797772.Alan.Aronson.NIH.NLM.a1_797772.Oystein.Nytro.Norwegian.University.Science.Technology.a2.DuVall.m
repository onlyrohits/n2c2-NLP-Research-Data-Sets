1:
m="procainamide." 19:6 19:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 18:5 18:6
ln="narrative"
2:
m="insulin." 36:2 36:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus" 35:8 36:0
ln="narrative"
3:
m="aspirin" 40:4 40:4
do="325 mg" 40:5 40:6
mo="nm"
f="q.d." 40:7 40:7
du="nm"
r="nm"
ln="list"
4:
m="captopril" 40:9 40:9
do="75 mg" 41:0 41:1
mo="nm"
f="t.i.d." 41:2 41:2
du="nm"
r="nm"
ln="list"
5:
m="nph insulin" 41:4 41:5
do="18" 41:6 41:6
mo="nm"
f="q.a.m." 41:7 41:7
du="nm"
r="nm"
ln="list"
6:
m="nph insulin" 41:4 41:5
do="8" 41:9 41:9
mo="nm"
f="q.p.m." 41:10 41:10
du="nm"
r="nm"
ln="list"
7:
m="procainamide" 42:0 42:0
do="500 mg" 42:1 42:2
mo="nm"
f="t.i.d." 42:3 42:3
du="nm"
r="nm"
ln="list"
8:
m="simvastatin" 42:5 42:5
do="20 mg" 42:6 42:7
mo="nm"
f="once a day." 42:8 42:10
du="nm"
r="nm"
ln="list"
9:
m="aspirin." 88:6 88:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="the in-stent restenosis" 87:5 88:0
ln="narrative"
10:
m="procainamide" 90:0 90:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="procainamide." 91:4 91:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="procainamide" 91:7 91:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="aspirin" 98:4 98:4
do="325 mg" 98:5 98:6
mo="nm"
f="q.d." 98:7 98:7
du="nm"
r="nm"
ln="list"
14:
m="captopril" 99:0 99:0
do="75 mg" 99:1 99:2
mo="nm"
f="t.i.d." 99:3 99:3
du="nm"
r="nm"
ln="list"
15:
m="nph humulin insulin" 99:5 99:7
do="18 units" 99:8 99:9
mo="nm"
f="q.a.m." 99:10 99:10
du="nm"
r="nm"
ln="list"
16:
m="nph humulin insulin" 99:5 99:7
do="8 units" 100:0 100:1
mo="nm"
f="q.p.m." 100:2 100:2
du="nm"
r="nm"
ln="list"
17:
m="nitroglycerin sublingual tablets." 100:4 100:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="vitamin e." 100:8 101:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="simvastatin" 101:2 101:2
do="20 mg" 101:3 101:4
mo="nm"
f="q.h.s." 101:5 101:5
du="nm"
r="nm"
ln="list"
