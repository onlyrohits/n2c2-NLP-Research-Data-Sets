1:
m="prednisone" 17:5 17:5
do="5 mg" 17:6 17:7
mo="p.o." 17:8 17:8
f="b.i.d." 17:9 17:9
du="nm"
r="nm"
ln="list"
2:
m="lasix" 18:0 18:0
do="40 mg" 18:1 18:2
mo="p.o." 18:3 18:3
f="q. day." 18:4 18:5
du="nm"
r="nm"
ln="list"
3:
m="zocor" 18:8 18:8
do="40 mg" 18:9 19:0
mo="p.o." 19:1 19:1
f="q. day." 19:2 19:3
du="nm"
r="nm"
ln="list"
4:
m="atenolol" 19:6 19:6
do="25 mg" 19:7 19:8
mo="p.o." 19:9 19:9
f="q. day." 19:10 19:11
du="nm"
r="nm"
ln="list"
5:
m="nitropatch." 19:14 19:14
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="enteric coated aspirin" 20:2 20:4
do="nm"
mo="p.o." 20:5 20:5
f="q. day." 20:6 20:7
du="nm"
r="nm"
ln="list"
7:
m="timolol eye drops" 20:10 20:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="captopril" 21:5 21:5
do="18.75 mg" 21:6 21:7
mo="p.o." 21:8 21:8
f="three times a day." 21:9 21:12
du="nm"
r="nm"
ln="list"
9:
m="calcium supplementation." 22:9 22:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="tagamet" 22:0 22:0
do="50 mg" 22:1 22:2
mo="p.o." 22:3 22:3
f="twice a day." 22:4 22:6
du="nm"
r="nm"
ln="list"
11:
m="steroids" 32:7 32:7
do="stress" 32:6 32:6
mo="nm"
f="nm"
du="nm"
r="steroid withdrawal." 33:0 33:1
ln="narrative"
12:
m="dopamine." 36:6 36:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="h2 blockers." 41:9 42:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="captopril" 43:6 43:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="afterload reduction." 44:0 44:1
ln="narrative"
15:
m="oxygen supplementation" 45:4 45:5
do="two liters." 45:7 46:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="prednisone" 53:5 53:5
do="5 mg" 53:6 53:7
mo="p.o." 53:8 53:8
f="twice a day." 53:9 53:11
du="nm"
r="nm"
ln="list"
17:
m="enteric coated aspirin" 54:2 54:4
do="325 mg" 54:5 54:6
mo="p.o." 54:7 54:7
f="q. day." 55:0 55:1
du="nm"
r="nm"
ln="list"
18:
m="niferex" 55:13 55:13
do="150 mg" 55:14 55:15
mo="p.o." 56:0 56:0
f="twice a day." 56:1 56:3
du="nm"
r="nm"
ln="list"
19:
m="zantac" 55:4 55:4
do="150 mg" 55:5 55:6
mo="p.o." 55:7 55:7
f="twice a day." 55:8 55:10
du="nm"
r="nm"
ln="list"
20:
m="atrovent nebulizer" 56:6 56:7
do="0.5 mg" 56:8 56:9
mo="nm"
f="four times a day." 56:10 56:13
du="nm"
r="nm"
ln="list"
21:
m="timolol eye drops 0.5%" 57:2 57:5
do="one drop in both eyes" 57:6 57:10
mo="nm"
f="twice a day." 57:11 57:13
du="nm"
r="nm"
ln="list"
22:
m="atenolol" 58:0 58:0
do="25 mg" 58:1 58:2
mo="p.o." 58:3 58:3
f="twice a day." 58:4 58:6
du="nm"
r="nm"
ln="list"
23:
m="captopril" 58:9 58:9
do="12.5 mg" 58:10 58:11
mo="p.o." 58:12 58:12
f="three times a day." 58:13 59:2
du="nm"
r="nm"
ln="list"
24:
m="lasix" 59:5 59:5
do="40 mg" 59:6 59:7
mo="p.o." 59:8 59:8
f="q. day." 59:9 59:10
du="nm"
r="nm"
ln="list"
25:
m="potassium sr" 59:13 59:14
do="20 meq" 59:15 60:0
mo="p.o." 60:1 60:1
f="q. day." 60:2 60:3
du="nm"
r="nm"
ln="list"
26:
m="simvastatin" 60:6 60:6
do="40 mg" 60:7 60:8
mo="p.o." 60:9 60:9
f="q. day." 60:10 60:11
du="nm"
r="nm"
ln="list"
27:
m="ibuprofen" 61:0 61:0
do="200-800 mg" 61:1 61:2
mo="nm"
f="as needed...q.4-6h." 61:3 61:4,61:7 61:7
du="nm"
r="pain" 61:6 61:6
ln="list"
