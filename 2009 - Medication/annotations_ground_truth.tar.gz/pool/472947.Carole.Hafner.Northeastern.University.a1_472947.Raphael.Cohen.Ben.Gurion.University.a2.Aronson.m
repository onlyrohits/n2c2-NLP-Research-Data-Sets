1:
m="tylenol ( acetaminophen )" 16:0 16:3
do="650 mg" 16:4 16:5
mo="po" 16:6 16:6
f="q4h prn" 16:7 16:8
du="nm"
r="headache" 16:9 16:9
ln="list"
2:
m="cepacol" 17:0 17:0
do="1-2 lozenge" 17:1 17:2
mo="po" 17:3 17:3
f="q4h prn" 17:4 17:5
du="nm"
r="other:sore throat" 17:6 17:7
ln="list"
3:
m="vitamin b12 ( cyanocobalamin )" 18:0 18:4
do="1 , 000 mcg" 18:5 18:8
mo="im" 18:9 18:9
f="qd" 18:10 18:10
du="x 3 doses" 18:11 18:13
r="nm"
ln="list"
4:
m="dipyridamole" 19:0 19:0
do="25 mg" 19:1 19:2
mo="po" 19:3 19:3
f="qpm" 19:4 19:4
du="nm"
r="nm"
ln="list"
5:
m="lasix ( furosemide )" 20:0 20:3
do="10 mg" 20:4 20:5
mo="po" 20:6 20:6
f="qd" 20:7 20:7
du="nm"
r="nm"
ln="list"
6:
m="isordil ( isosorbide dinitrate )" 21:0 21:4
do="30 mg" 21:5 21:6
mo="po" 21:7 21:7
f="tid" 21:8 21:8
du="nm"
r="nm"
ln="list"
7:
m="ativan ( lorazepam )" 22:0 22:3
do="3.5 mg" 22:4 22:5
mo="po" 22:6 22:6
f="qhs prn" 22:7 22:8
du="nm"
r="insomnia" 22:9 22:9
ln="list"
8:
m="inderal ( propranolol hcl )" 23:0 23:4
do="10 mg" 23:5 23:6
mo="po" 23:7 23:7
f="qid" 23:8 23:8
du="nm"
r="nm"
ln="list"
9:
m="norvasc ( amlodipine )" 26:0 26:3
do="2.5 mg" 26:4 26:5
mo="po" 26:6 26:6
f="qd" 26:7 26:7
du="nm"
r="nm"
ln="list"
10:
m="nitroglycerin" 29:0 29:0
do="0.2%" 29:1 29:1
mo="topical tp" 29:2 29:3
f="bid" 29:4 29:4
du="nm"
r="nm"
ln="list"
11:
m="zetia ( ezetimibe )" 30:0 30:3
do="10 mg" 30:4 30:5
mo="po" 30:6 30:6
f="qd" 30:7 30:7
du="nm"
r="nm"
ln="list"
12:
m="azithromycin 500 mg pack" 31:0 31:3
do="500 mg" 31:4 31:5
mo="po" 31:6 31:6
f="qd" 31:7 31:7
du="x 4 doses" 31:8 31:10
r="nm"
ln="list"
13:
m="azithromycin" 33:5 33:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="lorazepam" 33:3 33:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="amlodipine besylate" 34:3 34:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="calcium phosphate" 35:0 35:1
do="nm"
mo="oral" 35:3 35:3
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="azithro." 64:4 64:4
do="500" 64:3 64:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="ivf." 86:8 86:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="azithromycin" 87:5 87:5
do="nm"
mo="nm"
f="nm"
du="x 5 days." 87:6 87:8
r="nm"
ln="narrative"
20:
m="b12" 93:14 93:14
do="1000ug" 93:15 93:15
mo="im" 93:16 93:16
f="x 1." 94:0 94:1
du="nm"
r="nm"
ln="narrative"
21:
m="b12" 103:8 103:8
do="nm"
mo="injections" 103:9 103:9
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="azithro" 107:2 107:2
do="nm"
mo="nm"
f="nm"
du="x 4 days" 107:3 107:5
r="nm"
ln="list"
23:
m="b12" 108:1 108:1
do="1000ug" 108:2 108:2
mo="nm"
f="qd" 108:3 108:3
du="for 2 more days" 108:4 108:7
r="nm"
ln="narrative"
