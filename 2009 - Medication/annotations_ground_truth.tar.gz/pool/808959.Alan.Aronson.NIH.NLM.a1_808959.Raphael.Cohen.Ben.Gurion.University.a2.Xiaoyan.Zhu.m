1:
m="insulin" 26:5 26:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus" 26:1 26:2
ln="narrative"
2:
m="lopressor" 31:1 31:1
do="50 mg" 31:2 31:3
mo="p.o." 31:4 31:4
f="t.i.d." 31:5 31:5
du="nm"
r="nm"
ln="list"
3:
m="lisinopril" 32:1 32:1
do="40 mg" 32:2 32:3
mo="p.o." 32:4 32:4
f="daily." 32:5 32:5
du="nm"
r="nm"
ln="list"
4:
m="aspirin" 33:1 33:1
do="325 mg" 33:2 33:3
mo="p.o." 33:4 33:4
f="daily." 33:5 33:5
du="nm"
r="nm"
ln="list"
5:
m="hydrochlorothiazide/triamterene" 34:1 34:1
do="one tablet" 34:2 34:3
mo="nm"
f="daily." 34:4 34:4
du="nm"
r="nm"
ln="list"
6:
m="atorvastatin" 35:1 35:1
do="80 mg" 35:2 35:3
mo="p.o." 35:4 35:4
f="daily." 35:5 35:5
du="nm"
r="nm"
ln="list"
7:
m="lantus" 36:1 36:1
do="50 cc" 36:2 36:3
mo="nm"
f="daily." 36:4 36:4
du="nm"
r="nm"
ln="list"
8:
m="aprotinin" 76:9 76:9
do="nm"
mo="nm"
f="nm"
du="x3." 76:1 76:1
r="nm"
ln="narrative"
9:
m="amiodarone" 87:10 87:10
do="nm"
mo="nm"
f="nm"
du="during the code." 87:11 88:1
r="nm"
ln="narrative"
10:
m="lidocaine" 87:8 87:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="lantus." 93:7 93:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="a known diabetic" 92:8 92:10
ln="narrative"
12:
m="novolog" 93:0 93:0
do="sliding scale" 93:1 93:2
mo="nm"
f="nm"
du="nm"
r="a known diabetic" 92:8 92:10
ln="narrative"
13:
m="flagyl" 96:10 96:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="presumed aspiration pneumonia." 96:12 97:1
ln="narrative"
14:
m="levofloxacin" 98:1 98:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="a positive uti" 97:8 97:10
ln="narrative"
15:
m="nitrofurantoin." 102:10 102:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="nitrofurantoin" 119:3 119:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="imipenem." 120:2 120:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="ceftazidime" 121:8 121:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="enterobacter in his urine" 120:12 121:2
ln="narrative"
19:
m="antihypertensive medication" 125:0 125:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="amlodipine" 133:9 133:9
do="5 mg" 133:10 133:11
mo="nm"
f="b.i.d." 133:12 133:12
du="nm"
r="nm"
ln="narrative"
21:
m="lopressor" 133:3 133:3
do="25 mg" 133:4 133:5
mo="nm"
f="q.6h." 133:6 133:6
du="nm"
r="nm"
ln="narrative"
22:
m="lasix" 138:5 138:5
do="20 mg" 138:6 138:7
mo="p.o." 138:8 138:8
f="b.i.d." 138:9 138:9
du="nm"
r="nm"
ln="narrative"
23:
m="lasix" 139:9 139:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="lantus" 141:9 141:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes management" 142:3 142:4
ln="narrative"
25:
m="novolog" 141:11 141:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes management" 142:3 142:4
ln="narrative"
26:
m="insulin" 142:0 142:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes management" 142:3 142:4
ln="narrative"
27:
m="aspirin" 143:6 143:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="atorvastatin." 143:8 143:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="imipenem" 147:8 147:8
do="nm"
mo="nm"
f="nm"
du="for six weeks" 148:6 148:8
r="a deep sternal infection" 146:5 146:8
ln="narrative"
30:
m="imipenem" 149:3 149:3
do="nm"
mo="nm"
f="nm"
du="for six weeks" 150:4 150:6
r="nm"
ln="narrative"
31:
m="vancomycin" 150:12 150:12
do="nm"
mo="nm"
f="nm"
du="for six weeks." 152:0 152:2
r="his sternal wound infection." 150:14 151:2
ln="narrative"
