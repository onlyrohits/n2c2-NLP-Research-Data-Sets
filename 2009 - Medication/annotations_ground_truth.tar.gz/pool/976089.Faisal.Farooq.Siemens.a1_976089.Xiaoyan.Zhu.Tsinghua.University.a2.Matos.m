1:
m="nitroglycerin." 15:0 15:0
do="nm"
mo="sublingual" 14:10 14:10
f="nm"
du="nm"
r="substernal chest pain" 14:1 14:3
ln="narrative"
2:
m="h2 blockers." 20:3 20:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="anemia" 19:1 19:1
ln="narrative"
3:
m="iron sulfate" 20:0 20:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="anemia" 19:1 19:1
ln="narrative"
4:
m="maalox." 32:3 32:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="nitroglycerins" 32:1 32:1
do="three" 31:13 31:13
mo="sublingual" 32:0 32:0
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="lopressor" 33:7 33:7
do="10 mg" 33:3 33:4
mo="iv" 33:6 33:6
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="h2 blockers." 35:9 35:10
do="nm"
mo="iv" 35:8 35:8
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="lasix" 35:6 35:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="packed red blood cells" 35:0 35:3
do="three units" 34:8 34:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="maalox" 54:3 54:3
do="four" 54:5 54:5
mo="sublinguals" 54:6 54:6
f="nm"
du="nm"
r="substernal chest pain" 52:5 52:7
ln="narrative"
11:
m="morphine" 54:11 54:11
do="12 mg" 54:8 54:9
mo="nm"
f="nm"
du="nm"
r="substernal chest pain" 52:5 52:7
ln="narrative"
12:
m="nitropaste." 55:4 55:4
do="three inches" 55:1 55:2
mo="nm"
f="nm"
du="nm"
r="substernal chest pain" 52:5 52:7
ln="narrative"
13:
m="kay ciel." 57:13 58:0
do="20 meq" 57:10 57:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="packed red blood cells" 59:5 59:8
do="two more units" 59:1 59:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="packed red blood cells" 60:5 60:8
do="two more units" 60:1 60:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="nitroglycerin" 61:1 61:1
do="100 units." 62:6 62:7
mo="iv" 61:0 61:0
f="nm"
du="nm"
r="pain." 62:1 62:1
ln="narrative"
17:
m="nitroglycerin" 61:1 61:1
do="50 units" 61:2 61:3
mo="iv" 61:0 61:0
f="nm"
du="nm"
r="pain." 62:1 62:1
ln="narrative"
18:
m="pepcid" 84:3 84:3
do="20 mg" 84:4 84:5
mo="p.o." 84:6 84:6
f="b.i.d.;" 84:7 84:7
du="nm"
r="nm"
ln="list"
19:
m="metoprolol" 85:0 85:0
do="50 mg" 85:1 85:2
mo="p.o." 85:3 85:3
f="b.i.d.;" 85:4 85:4
du="nm"
r="nm"
ln="list"
20:
m="nitroglycerin 1/150" 85:5 85:6
do="0.4 mg" 85:7 85:8
mo="sublingual" 85:9 85:9
f="p.r.n." 86:0 86:0
du="nm"
r="nm"
ln="list"
