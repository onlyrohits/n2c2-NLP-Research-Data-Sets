1:
m="aspirin" 10:5 10:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="severe frontal headaches with scintillations." 9:2 9:6
ln="narrative"
2:
m="fioricet." 10:7 10:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="severe frontal headaches with scintillations." 9:2 9:6
ln="narrative"
3:
m="tylenol" 10:3 10:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="severe frontal headaches with scintillations." 9:2 9:6
ln="narrative"
4:
m="valproic acid" 20:7 20:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="seizure disorder" 19:4 19:5
ln="narrative"
5:
m="medicines" 22:0 22:0
do="nm"
mo="nm"
f="p.r.n.;" 22:1 22:1
du="nm"
r="asthma" 21:5 21:5
ln="narrative"
6:
m="fioricet" 44:1 44:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic headaches" 43:1 43:2
ln="narrative"
7:
m="demerol" 48:8 48:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="headaches" 48:2 48:2
ln="narrative"
8:
m="fioricet" 49:8 49:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="headaches." 50:6 50:6
ln="narrative"
9:
m="percocet" 49:0 49:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="headaches" 48:2 48:2
ln="narrative"
10:
m="tylenol." 49:2 49:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="headaches" 48:2 48:2
ln="narrative"
11:
m="fioricet" 57:9 57:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="headaches" 56:6 56:6
ln="narrative"
12:
m="hydrochlorothiazide" 61:7 61:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic hypertension" 60:6 60:7
ln="narrative"
13:
m="beta blocker" 66:6 66:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic hypertension" 65:5 65:6
ln="narrative"
14:
m="labetolol" 66:10 66:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic hypertension" 65:5 65:6
ln="narrative"
15:
m="labetolol." 67:8 67:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="valproic acid" 70:5 70:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="seizure disorder" 69:0 69:1
ln="narrative"
17:
m="valproic acid" 71:5 71:6
do="250 mg" 72:7 72:8
mo="nm"
f="a week." 72:9 72:10
du="throughout this pregnancy." 72:0 72:2
r="nm"
ln="narrative"
18:
m="valproic acid" 71:5 71:6
do="small dose" 71:2 71:3
mo="nm"
f="nm"
du="throughout this pregnancy." 72:0 72:2
r="nm"
ln="narrative"
19:
m="valproic acid" 85:10 86:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="hydration" 93:7 93:7
do="nm"
mo="intravenous" 93:6 93:6
f="nm"
du="nm"
r="nm"
ln="narrative"
