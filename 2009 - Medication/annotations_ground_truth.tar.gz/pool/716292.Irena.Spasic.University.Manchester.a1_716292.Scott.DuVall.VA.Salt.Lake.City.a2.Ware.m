1:
m="digoxin" 15:6 15:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="his congestive heart failure." 14:16 14:19
ln="narrative"
2:
m="lasix" 15:8 15:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="his congestive heart failure." 14:16 14:19
ln="narrative"
3:
m="this regimen" 16:1 16:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="dobutamine" 21:0 21:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="nitroprusside" 21:6 21:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="tng" 21:3 21:3
do="nm"
mo="intravenous" 21:2 21:2
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="nipride" 23:4 23:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="tng" 23:2 23:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="dobutamine" 24:2 24:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="dobutamine" 46:6 46:6
do="15 mcg per kilogram" 46:8 47:0
mo="nm"
f="per minute;" 47:1 47:2
du="nm"
r="nm"
ln="list"
11:
m="captopril" 47:3 47:3
do="25 mg" 47:4 47:5
mo="p.o." 47:6 47:6
f="t.i.d." 47:7 47:7
du="nm"
r="nm"
ln="list"
12:
m="digoxin" 47:8 47:8
do="0.125 mg" 47:9 48:0
mo="p.o." 48:1 48:1
f="q.d." 48:2 48:2
du="nm"
r="nm"
ln="list"
13:
m="lasix" 48:3 48:3
do="160 mg" 48:4 48:5
mo="p.o." 48:6 48:6
f="b.i.d." 48:7 48:7
du="nm"
r="nm"
ln="list"
14:
m="potassium chloride" 48:8 48:9
do="20 meq" 48:10 48:11
mo="p.o." 49:0 49:0
f="b.i.d." 49:1 49:1
du="nm"
r="nm"
ln="list"
15:
m="atrovent" 49:7 49:7
do="two puffs" 49:9 49:10
mo="nm"
f="q.i.d." 49:11 49:11
du="nm"
r="nm"
ln="list"
16:
m="coumadin" 49:2 49:2
do="1 mg" 49:3 49:4
mo="p.o." 49:5 49:5
f="q.d." 49:6 49:6
du="nm"
r="nm"
ln="list"
17:
m="azmacort" 50:0 50:0
do="eight puffs" 50:2 50:3
mo="nm"
f="b.i.d." 50:4 50:4
du="nm"
r="nm"
ln="list"
18:
m="colace" 50:10 50:10
do="100 mg" 51:0 51:1
mo="p.o." 51:2 51:2
f="t.i.d." 51:3 51:3
du="nm"
r="nm"
ln="list"
19:
m="pepcid" 50:5 50:5
do="20 mg" 50:6 50:7
mo="p.o." 50:8 50:8
f="b.i.d." 50:9 50:9
du="nm"
r="nm"
ln="list"
20:
m="vancomycin" 51:4 51:4
do="1 gm" 51:5 51:6
mo="nm"
f="q. 12" 51:7 51:8
du="14 days;" 52:1 52:2
r="nm"
ln="list"
21:
m="ampicillin" 52:3 52:3
do="2 gm" 52:4 52:5
mo="iv" 52:6 52:6
f="q. 6" 52:7 52:8
du="nm"
r="nm"
ln="list"
22:
m="halcion" 53:2 53:2
do="0.125" 53:3 53:3
mo="p.o." 53:4 53:4
f="q.h.s. prn" 53:5 53:6
du="nm"
r="nm"
ln="list"
23:
m="serax" 53:7 53:7
do="15 mg" 53:8 53:9
mo="p.o." 53:10 53:10
f="q. 6 hours prn" 53:11 54:0
du="nm"
r="nm"
ln="list"
24:
m="vancomycin" 71:4 71:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="gram positive cocci" 70:3 70:5
ln="narrative"
25:
m="vancomycin" 74:3 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="ampicillin" 78:0 78:0
do="2 gm" 78:1 78:2
mo="iv" 78:3 78:3
f="q. 6." 78:4 78:5
du="nm"
r="gram negative enteric rods" 76:6 77:0
ln="narrative"
27:
m="dobutamine" 81:11 81:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
