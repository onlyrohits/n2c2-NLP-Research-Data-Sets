1:
m="packed red blood cells" 18:4 18:7
do="four units" 18:1 18:2
mo="nm"
f="nm"
du="during that hospitalization" 16:12 17:1
r="nm"
ln="narrative"
2:
m="pain medication" 41:10 42:0
do="nm"
mo="p.o." 41:9 41:9
f="nm"
du="nm"
r="his pain" 41:3 41:4
ln="narrative"
3:
m="percocet" 42:2 42:2
do="nm"
mo="p.o." 41:9 41:9
f="nm"
du="nm"
r="his pain" 41:3 41:4
ln="narrative"
4:
m="allopurinol" 59:2 59:2
do="300 mg" 59:3 59:4
mo="p.o." 59:5 59:5
f="q.d." 59:6 59:6
du="nm"
r="nm"
ln="list"
5:
m="atenolol" 59:8 59:8
do="25 mg" 60:0 60:1
mo="p.o." 60:2 60:2
f="q.d." 60:3 60:3
du="nm"
r="nm"
ln="list"
6:
m="colace" 60:5 60:5
do="100 mg" 60:6 60:7
mo="p.o." 60:8 60:8
f="b.i.d. p.r.n." 60:9 61:0
du="nm"
r="constipation" 61:1 61:1
ln="list"
7:
m="percocet" 61:3 61:3
do="1-2 tablets" 61:4 61:5
mo="p.o." 61:6 61:6
f="q.4h. p.r.n." 61:7 61:8
du="nm"
r="pain" 61:9 61:9
ln="list"
8:
m="flomax" 62:6 62:6
do="0.8 mg" 62:7 62:8
mo="p.o." 62:9 62:9
f="q.d." 62:10 62:10
du="nm"
r="nm"
ln="list"
9:
m="zantac" 62:0 62:0
do="150 mg" 62:1 62:2
mo="p.o." 62:3 62:3
f="b.i.d." 62:4 62:4
du="nm"
r="nm"
ln="list"
