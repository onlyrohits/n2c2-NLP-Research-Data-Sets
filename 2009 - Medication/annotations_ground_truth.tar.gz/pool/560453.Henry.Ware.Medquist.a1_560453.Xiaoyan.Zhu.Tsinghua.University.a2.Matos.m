1:
m="lisinopril" 36:1 36:1
do="10 mg" 36:2 36:3
mo="nm"
f="daily" 36:4 36:4
du="nm"
r="nm"
ln="list"
2:
m="lipitor" 37:1 37:1
do="40 mg" 37:2 37:3
mo="nm"
f="daily" 37:4 37:4
du="nm"
r="nm"
ln="list"
3:
m="klonopin" 38:1 38:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="metrogel" 39:1 39:1
do="nm"
mo="p.o." 39:2 39:2
f="at bedtime" 39:3 39:4
du="nm"
r="nm"
ln="list"
5:
m="lithium" 40:1 40:1
do="900 mg" 40:2 40:3
mo="nm"
f="at bedtime" 40:4 40:5
du="nm"
r="nm"
ln="list"
6:
m="acebutolol" 41:1 41:1
do="200 mg" 41:2 41:3
mo="nm"
f="daily" 41:4 41:4
du="nm"
r="nm"
ln="list"
7:
m="risperdal" 42:1 42:1
do="0.5 mg" 42:2 42:3
mo="nm"
f="at bedtime" 42:4 42:5
du="nm"
r="nm"
ln="list"
8:
m="vancomycin" 98:9 98:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="levofloxacin" 99:5 99:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="unasyn" 99:1 99:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="heparin" 100:4 100:4
do="therapeutic doses" 100:1 100:2
mo="nm"
f="nm"
du="nm"
r="pain" 100:10 100:10
ln="narrative"
12:
m="heparin" 100:4 100:4
do="therapeutic doses" 100:1 100:2
mo="nm"
f="nm"
du="nm"
r="swelling" 101:1 101:1
ln="narrative"
13:
m="oxycodone" 110:7 110:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="tylenol" 110:9 110:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="lidocaine patch" 111:0 111:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="nsaids" 112:6 112:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="nsaids" 114:6 114:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="her musculoskeletal pain." 115:0 115:2
ln="narrative"
18:
m="lithium" 124:0 124:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="lithium" 124:4 124:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="lithium" 127:3 127:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="fluids" 128:2 128:2
do="nm"
mo="iv" 128:1 128:1
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="lithium." 133:10 133:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="lithium" 134:5 134:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="lithium" 135:9 135:9
do="300 mg" 135:11 135:12
mo="nm"
f="at bedtime." 136:0 136:1
du="nm"
r="nm"
ln="narrative"
25:
m="lithium" 136:9 136:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="lithium" 138:0 138:0
do="300 mg" 138:5 138:6
mo="nm"
f="at bedtime" 138:7 138:8
du="nm"
r="nm"
ln="narrative"
27:
m="normal saline fluid boluses" 142:5 142:8
do="3 liters" 143:5 143:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="beta blockade" 145:2 145:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="beta-blocker" 145:8 145:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="lithium" 146:6 146:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="beta-blocker" 147:9 147:9
do="nm"
mo="nm"
f="nm"
du="until follow up at her primary care physician's office for her next appointment." 148:0 149:1
r="nm"
ln="narrative"
32:
m="beta blockade" 165:9 166:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="unasyn" 168:1 168:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="vancomycin." 168:3 168:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="levofloxacin" 169:9 169:9
do="nm"
mo="nm"
f="nm"
du="a seven-day course." 170:4 170:6
r="nm"
ln="narrative"
36:
m="levofloxacin." 171:9 171:9
do="nm"
mo="nm"
f="nm"
du="six more days" 171:0 171:2
r="nm"
ln="narrative"
37:
m="tylenol" 179:1 179:1
do="650 mg" 179:2 179:3
mo="p.o." 179:4 179:4
f="q.4h. p.r.n." 179:5 179:6
du="nm"
r="pain." 179:7 179:7
ln="list"
38:
m="klonopin" 180:1 180:1
do="1 mg" 180:2 180:3
mo="p.o." 180:4 180:4
f="at bedtime" 180:5 180:6
du="nm"
r="nm"
ln="list"
39:
m="oxycodone" 181:1 181:1
do="5 mg to 10 mg" 181:2 181:6
mo="p.o." 181:7 181:7
f="q.4h. p.r.n." 181:8 181:9
du="nm"
r="pain" 181:10 181:10
ln="list"
40:
m="risperdal" 183:1 183:1
do="0.5 mg" 183:2 183:3
mo="p.o." 183:4 183:4
f="at bedtime" 183:5 183:6
du="nm"
r="nm"
ln="list"
41:
m="levofloxacin" 184:1 184:1
do="500 mg" 184:2 184:3
mo="p.o." 184:4 184:4
f="daily" 184:5 184:5
du="for six days" 184:6 184:8
r="nm"
ln="list"
42:
m="ibuprofen" 186:1 186:1
do="600 mg" 186:2 186:3
mo="nm"
f="q.6h. p.r.n." 186:4 186:5
du="nm"
r="pain." 186:6 186:6
ln="list"
43:
m="lithium" 191:0 191:0
do="300 mg" 191:1 191:2
mo="p.o." 191:3 191:3
f="at bedtime" 191:4 191:5
du="nm"
r="nm"
ln="narrative"
