1:
m="heparin" 13:9 13:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="pulmonary embolism" 12:0 12:1
ln="narrative"
2:
m="coumadin." 14:1 14:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="pulmonary embolism" 12:0 12:1
ln="narrative"
3:
m="heparin." 49:0 49:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="coumadin." 56:9 56:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="ceftizoxime" 60:3 60:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="bactrim" 61:1 61:1
do="nm"
mo="p.o." 61:0 61:0
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="antibiotic." 62:3 62:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="coumadin" 63:4 63:4
do="1 mg" 62:9 62:10
mo="p.o." 63:0 63:0
f="q. h.s." 63:1 63:2
du="nm"
r="nm"
ln="narrative"
9:
m="coumadin." 70:5 70:5
do="1 mg" 70:1 70:2
mo="p.o." 70:3 70:3
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="bactrim" 71:2 71:2
do="one double strength tablet" 71:3 71:6
mo="p.o." 71:7 71:7
f="b.i.d.;" 72:0 72:0
du="nm"
r="nm"
ln="list"
11:
m="iron sulfate" 72:1 72:2
do="325 mg" 72:3 72:4
mo="p.o." 72:5 72:5
f="q.d.;" 72:6 72:6
du="nm"
r="nm"
ln="list"
12:
m="motrin" 72:7 72:7
do="800 mg" 72:8 72:9
mo="p.o." 72:10 72:10
f="t.i.d.;" 72:11 72:11
du="nm"
r="nm"
ln="list"
13:
m="colace" 73:0 73:0
do="100 mg" 73:1 73:2
mo="p.o." 73:3 73:3
f="t.i.d.;" 73:4 73:4
du="nm"
r="nm"
ln="list"
14:
m="coumadin" 73:5 73:5
do="1 mg" 73:6 73:7
mo="p.o." 73:8 73:8
f="q. h.s." 73:9 73:10
du="nm"
r="nm"
ln="list"
