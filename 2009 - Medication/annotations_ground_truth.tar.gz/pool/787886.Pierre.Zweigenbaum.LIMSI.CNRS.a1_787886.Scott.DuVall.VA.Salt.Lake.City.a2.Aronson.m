1:
m="ceftriaxone" 20:0 20:0
do="2 , 000 mg" 20:1 20:4
mo="iv" 20:5 20:5
f="qd" 20:6 20:6
du="nm"
r="nm"
ln="list"
2:
m="digoxin" 21:0 21:0
do="0.25 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qod" 21:4 21:4
du="nm"
r="nm"
ln="list"
3:
m="colace ( docusate sodium )" 22:0 22:4
do="100 mg" 22:5 22:6
mo="po" 22:7 22:7
f="bid" 22:8 22:8
du="nm"
r="nm"
ln="list"
4:
m="lasix ( furosemide )" 23:0 23:3
do="20 mg" 23:4 23:5
mo="po " 23:6 23:6
f="qod " 23:7 23:7
du="nm"
r="nm"
ln="list"
5:
m="isordil ( isosorbide dinitrate )" 24:0 24:4
do="40 mg" 24:5 24:6
mo="po " 24:7 24:7
f="bid " 24:8 24:8
du="nm"
r="nm"
ln="list"
6:
m="primidone" 26:0 26:0
do="50 mg" 26:1 26:2
mo="po" 26:3 26:3
f="bid" 26:4 26:4
du="nm"
r="nm"
ln="list"
7:
m="vancomycin hcl" 27:0 27:1
do="1 gm" 27:2 27:3
mo="iv" 27:4 27:4
f="q36h" 27:5 27:5
du="nm"
r="nm"
ln="list"
8:
m="simvastatin" 28:0 28:0
do="20 mg" 28:1 28:2
mo="po" 28:3 28:3
f="qhs" 28:4 28:4
du="nm"
r="nm"
ln="list"
9:
m="norvasc ( amlodipine )" 31:0 31:3
do="5 mg" 31:4 31:5
mo="po" 31:6 31:6
f="qd" 31:7 31:7
du="nm"
r="nm"
ln="list"
10:
m="lovenox ( enoxaparin )" 34:0 34:3
do="30 mg" 34:4 34:5
mo="sc" 34:6 34:6
f="qd" 34:7 34:7
du="nm"
r="nm"
ln="list"
11:
m="coreg ( carvedilol )" 35:0 35:3
do="25 mg" 35:4 35:5
mo="po" 35:6 35:6
f="bid" 35:7 35:7
du="number of doses required ( approximate ): 2" 38:0 38:7
r="nm"
ln="list"
12:
m="flomax ( tamsulosin )" 39:0 39:3
do="0.4 mg" 39:4 39:5
mo="po" 39:6 39:6
f="qpm" 39:7 39:7
du="nm"
r="nm"
ln="list"
13:
m="esomeprazole" 40:0 40:0
do="20 mg" 40:1 40:2
mo="po" 40:3 40:3
f="qd" 40:4 40:4
du="nm"
r="nm"
ln="list"
14:
m="lantus ( insulin glargine )" 41:0 41:4
do="7 units" 41:5 41:6
mo="sc" 41:7 41:7
f="qd" 41:8 41:8
du="nm"
r="nm"
ln="list"
15:
m="insulin aspart" 42:0 42:1
do="10 units" 49:7 49:8
mo="subcutaneously" 49:9 49:9
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="insulin aspart" 42:0 42:1
do="2 units" 44:7 44:8
mo="subcutaneously" 44:9 44:9
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="insulin aspart" 42:0 42:1
do="3 units" 45:7 45:8
mo="subcutaneously" 45:9 45:9
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="insulin aspart" 42:0 42:1
do="4 units" 46:7 46:8
mo="subcutaneously" 46:9 46:9
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="insulin aspart" 42:0 42:1
do="6 units" 47:7 47:8
mo="subcutaneously" 47:9 47:9
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="insulin aspart" 42:0 42:1
do="8 units" 48:7 48:8
mo="subcutaneously" 48:9 48:9
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="insulin aspart" 42:0 42:1
do="sliding scale" 42:2 42:3
mo="( subcutaneously ) sc" 42:4 42:7
f="ac" 42:8 42:8
du="nm"
r="nm"
ln="list"
22:
m="insulin aspart" 42:0 42:1
do="sliding scale" 42:2 42:3
mo="subcutaneously...sc" 42:5 42:5,42:7 42:7
f="ac" 42:8 42:8
du="nm"
r="nm"
ln="list"
23:
m="insulin aspart" 51:0 51:1
do="17 units" 51:2 51:3
mo="sc" 51:4 51:4
f="ac" 51:5 51:5
du="nm"
r="nm"
ln="list"
24:
m="abx." 75:10 75:10
do="nm"
mo="iv" 75:9 75:9
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="antibiotic regimen" 76:1 76:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="antibiotics" 77:2 77:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="ceftriaxone" 78:0 78:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="vanc." 78:2 78:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="aspirin." 85:6 85:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="isordil" 89:7 89:7
do="40" 89:8 89:8
mo="nm"
f="bid" 89:9 89:9
du="nm"
r="nm"
ln="list"
31:
m="lasix" 89:3 89:3
do="20" 89:4 89:4
mo="nm"
f="qod" 89:5 89:5
du="nm"
r="nm"
ln="list"
32:
m="prednisone" 89:11 89:11
do="2" 89:12 89:12
mo="nm"
f="qd" 89:13 89:13
du="nm"
r="nm"
ln="list"
33:
m="coreg" 90:8 90:8
do="25" 90:9 90:9
mo="nm"
f="bid" 90:10 90:10
du="nm"
r="nm"
ln="list"
34:
m="flomax" 90:12 90:12
do="0.4" 90:13 90:13
mo="nm"
f="qd" 90:14 90:14
du="nm"
r="nm"
ln="narrative"
35:
m="norvasc" 90:4 90:4
do="5" 90:5 90:5
mo="nm"
f="qd" 90:6 90:6
du="nm"
r="nm"
ln="list"
36:
m="prilosec otc" 90:16 90:17
do="20" 91:0 91:0
mo="nm"
f="qd" 91:1 91:1
du="nm"
r="nm"
ln="list"
37:
m="primidone" 90:0 90:0
do="50" 90:1 90:1
mo="nm"
f="bid" 90:2 90:2
du="nm"
r="nm"
ln="list"
38:
m="iss" 91:7 91:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="lantus" 91:9 91:9
do="7" 91:10 91:10
mo="nm"
f="qd" 91:11 91:11
du="nm"
r="nm"
ln="list"
40:
m="lipitor" 91:3 91:3
do="20" 91:4 91:4
mo="nm"
f="qd" 91:5 91:5
du="nm"
r="nm"
ln="list"
41:
m="lovenox" 91:17 91:17
do="30" 91:18 91:18
mo="nm"
f="qd" 91:19 91:19
du="nm"
r="nm"
ln="list"
42:
m="novolog" 91:13 91:13
do="17" 91:14 91:14
mo="nm"
f="qac" 91:15 91:15
du="nm"
r="nm"
ln="list"
43:
m="ceftriaxone" 92:5 92:5
do="2 gm" 92:6 92:7
mo="nm"
f="qd" 92:8 92:8
du="nm"
r="nm"
ln="list"
44:
m="colace" 92:14 92:14
do="100" 92:15 92:15
mo="nm"
f="bid" 92:16 92:16
du="nm"
r="nm"
ln="list"
45:
m="digoxin" 92:10 92:10
do="0.25" 92:11 92:11
mo="nm"
f="qod" 92:12 92:12
du="nm"
r="nm"
ln="list"
46:
m="vancomycin" 92:0 92:0
do="1 gm" 92:1 92:2
mo="nm"
f="qod" 92:3 92:3
du="nm"
r="nm"
ln="list"
47:
m="aspirin" 93:7 93:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
48:
m="ns" 93:3 93:3
do="500 cc" 93:4 93:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
49:
m="coreg" 109:6 109:6
do="nm"
mo="nm"
f="morning" 109:5 109:5
du="nm"
r="nm"
ln="narrative"
50:
m="lovenox." 112:6 112:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="primidone." 114:12 114:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="tremor" 114:7 114:7
ln="narrative"
52:
m="ceftriaxone" 116:9 116:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="osteomyelitis." 116:7 116:7
ln="narrative"
53:
m="vancomycin" 117:0 117:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="osteomyelitis." 116:7 116:7
ln="narrative"
54:
m="lantus" 121:10 121:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="insulin" 122:1 122:1
do="nm"
mo="nm"
f="qac " 122:2 122:2
du="nm"
r="nm"
ln="narrative"
56:
m="insulin" 122:4 122:4
do="ss" 122:5 122:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="flomax" 123:6 123:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="his bph." 123:8 123:9
ln="narrative"
58:
m="lovenox" 124:5 124:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
