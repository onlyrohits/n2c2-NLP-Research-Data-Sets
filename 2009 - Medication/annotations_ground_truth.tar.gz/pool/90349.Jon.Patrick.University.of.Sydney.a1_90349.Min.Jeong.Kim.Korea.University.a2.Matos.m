1:
m="tylenol ( acetaminophen )" 16:0 16:3
do="650 mg" 16:4 16:5
mo="po" 16:6 16:6
f="q4h prn" 16:7 16:8
du="nm"
r="headache" 16:9 16:9
ln="list"
2:
m="albuterol inhaler" 17:0 17:1
do="2 puff" 17:2 17:3
mo="inh" 17:4 17:4
f="qid" 17:5 17:5
du="nm"
r="nm"
ln="list"
3:
m="ecasa ( aspirin enteric coated )" 18:0 18:5
do="81 mg" 18:6 18:7
mo="po" 18:8 18:8
f="qd" 18:9 18:9
du="nm"
r="nm"
ln="list"
4:
m="atenolol" 19:0 19:0
do="25 mg" 19:1 19:2
mo="po" 19:3 19:3
f="bid" 19:4 19:4
du="nm"
r="nm"
ln="list"
5:
m="levoxyl ( levothyroxine sodium )" 20:0 20:4
do="75 mcg" 20:5 20:6
mo="po" 20:7 20:7
f="qd" 20:8 20:8
du="nm"
r="nm"
ln="list"
6:
m="zocor ( simvastatin )" 21:0 21:3
do="40 mg" 21:4 21:5
mo="po" 21:6 21:6
f="qhs" 21:7 21:7
du="nm"
r="nm"
ln="list"
7:
m="zocor" 26:3 26:3
do="nm"
mo="po" 26:4 26:4
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="imdur ( isosorbide mononit.( sr ) )" 29:0 29:6
do="30 mg" 29:7 29:8
mo="po" 29:9 29:9
f="qd" 29:10 29:10
du="nm"
r="nm"
ln="list"
9:
m="zantac ( ranitidine hcl )" 33:0 33:4
do="150 mg" 33:5 33:6
mo="po" 33:7 33:7
f="bid" 33:8 33:8
du="nm"
r="nm"
ln="list"
10:
m="celebrex ( celecoxib )" 34:0 34:3
do="200 mg" 34:4 34:5
mo="po" 34:6 34:6
f="qd" 34:7 34:7
du="nm"
r="nm"
ln="list"
11:
m="atenolol" 77:1 77:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="lipitor." 78:10 78:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="zocor" 78:12 78:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="aspirin." 79:0 79:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="bb" 79:2 79:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="imdur." 79:4 79:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="asa." 81:11 81:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="asa" 82:3 82:3
do="81mg" 82:10 82:10
mo="nm"
f="qd" 82:11 82:11
du="nm"
r="nm"
ln="narrative"
19:
m="atenolol" 86:10 86:10
do="1/2 dose ( 25mg )" 87:6 87:10
mo="nm"
f="bid" 87:3 87:3
du="nm"
r="nm"
ln="narrative"
20:
m="imdur" 88:4 88:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="persistent hypertension." 88:6 88:7
ln="narrative"
21:
m="ppi" 89:3 89:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="levoxyl" 91:4 91:4
do="75mcg" 91:8 91:8
mo="nm"
f="qd" 91:9 91:9
du="nm"
r="nm"
ln="narrative"
23:
m="levoxyl" 91:4 91:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="celebrex" 93:4 93:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="nsaids" 93:0 93:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="trochanteric bursitis." 92:1 92:2
ln="narrative"
26:
m="ibuprofen" 94:0 94:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="albuterol" 95:4 95:4
do="nm"
mo="inh" 95:5 95:5
f="prn" 95:6 95:6
du="nm"
r="asthma" 95:1 95:1
ln="narrative"
28:
m="lovenox" 96:1 96:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="dvt ppx" 96:3 96:4
ln="narrative"
