1:
m="diabeta" 15:9 15:9
do="5 mg" 15:11 15:12
mo="p o" 15:13 15:14
f="q am" 15:15 15:16
du="nm"
r="nm"
ln="list"
2:
m="paxil" 15:1 15:1
do="60 mg" 15:3 15:4
mo="p o" 15:5 15:6
f="q am" 15:7 15:8
du="nm"
r="nm"
ln="list"
3:
m="trazadone" 16:0 16:0
do="100 mg" 16:2 16:3
mo="nm"
f="q h.s." 16:4 16:5
du="nm"
r="nm"
ln="list"
4:
m="ultram" 16:6 16:6
do="100 mg" 16:8 16:9
mo="nm"
f="q 4-6 hours prn" 16:10 17:0
du="nm"
r="nm"
ln="list"
5:
m="bactroban ointment" 17:10 17:11
do="nm"
mo="nm"
f="b.i.d.;" 17:12 17:12
du="nm"
r="nm"
ln="list"
6:
m="reglan" 17:1 17:1
do="10 mg" 17:3 17:4
mo="nm"
f="q 6 hours prn" 17:5 17:8
du="nm"
r="nausea" 17:9 17:9
ln="list"
7:
m="afrin nasal spray" 18:4 18:6
do="nm"
mo="nm"
f="q 12 hours prn" 18:7 18:10
du="nm"
r="nm"
ln="list"
8:
m="lotrisone cream" 18:0 18:1
do="nm"
mo="topically" 18:3 18:3
f="b.i.d." 18:2 18:2
du="nm"
r="nm"
ln="list"
9:
m="proventil inhalers" 19:0 19:1
do="two puffs" 19:3 19:4
mo="nm"
f="prn" 19:5 19:5
du="nm"
r="nm"
ln="list"
10:
m="ancef" 37:8 37:8
do="nm"
mo="iv" 37:7 37:7
f="t.i.d." 37:9 37:9
du="nm"
r="nm"
ln="narrative"
11:
m="hibiclenz" 37:10 37:10
do="nm"
mo="showers" 38:0 38:0
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="heparin" 38:3 38:3
do="nm"
mo="sub-q" 38:2 38:2
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="azmacort inhalers" 46:7 46:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="albuterol nebulizer" 47:0 47:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="autologous red blood cells" 56:0 56:3
do="two (2) units" 55:5 55:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="blood" 59:8 59:8
do="two (2) units" 59:2 59:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="transfusion" 61:0 61:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="ancef" 66:0 66:0
do="nm"
mo="iv" 65:12 65:12
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="keflex" 70:4 70:4
do="nm"
mo="p o" 70:2 70:3
f="nm"
du="while two jackson-pratt drains were in" 70:5 70:10
r="nm"
ln="narrative"
20:
m="keflex" 73:4 73:4
do="500 mg" 73:6 73:7
mo="p o" 73:8 73:9
f="q.i.d." 73:10 73:10
du="nm"
r="nm"
ln="list"
21:
m="percocet" 73:13 73:13
do="one to two" 74:0 74:2
mo="p o" 74:3 74:4
f="q 4 hours prn" 74:5 74:8
du="nm"
r="pain" 74:9 74:9
ln="list"
22:
m="lotrisone" 75:0 75:0
do="nm"
mo="topically , tp" 75:1 75:3
f="b.i.d." 75:4 75:4
du="nm"
r="nm"
ln="list"
23:
m="paxil" 75:7 75:7
do="60 mg" 75:9 75:10
mo="p o" 75:11 75:12
f="q am" 75:13 75:14
du="nm"
r="nm"
ln="list"
24:
m="azmacort" 76:0 76:0
do="four puffs" 76:2 76:3
mo="inhaled" 76:4 76:4
f="q.i.d." 76:5 76:5
du="nm"
r="nm"
ln="list"
25:
m="bactroban" 76:8 76:8
do="nm"
mo="topically tp" 76:9 76:10
f="b.i.d." 77:0 77:0
du="nm"
r="nm"
ln="list"
26:
m="diabeta" 77:3 77:3
do="5 mg" 77:5 77:6
mo="p o" 77:7 77:8
f="q am" 77:9 77:10
du="nm"
r="nm"
ln="list"
27:
m="ferrous sulfate" 77:13 77:14
do="300 mg" 77:16 77:17
mo="p o" 77:18 77:19
f="t.i.d." 78:0 78:0
du="nm"
r="nm"
ln="list"
28:
m="proventil inhaler" 78:3 78:4
do="two puffs" 78:6 78:7
mo="inhaled" 78:8 78:8
f="q.i.d." 78:9 78:9
du="nm"
r="nm"
ln="list"
