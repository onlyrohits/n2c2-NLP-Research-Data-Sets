1:
m="lopressor" 13:7 13:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="non-q wave mi." 12:11 13:0
ln="narrative"
2:
m="dobutamine" 15:1 15:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="lopressor" 19:10 19:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="lopressor" 19:2 19:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="enteric-coated aspirin" 38:7 38:8
do="325 mg" 38:9 38:10
mo="p.o." 39:0 39:0
f="q.d." 39:1 39:1
du="nm"
r="nm"
ln="list"
6:
m="hctz" 38:1 38:1
do="50 mg" 38:2 38:3
mo="p.o." 38:4 38:4
f="q.d." 38:5 38:5
du="nm"
r="nm"
ln="list"
7:
m="glyburide" 39:9 39:9
do="5 mg" 39:10 39:11
mo="p.o." 40:0 40:0
f="q.d." 40:1 40:1
du="nm"
r="nm"
ln="list"
8:
m="zestril" 39:3 39:3
do="20 mg" 39:4 39:5
mo="p.o." 39:6 39:6
f="q.d." 39:7 39:7
du="nm"
r="nm"
ln="list"
9:
m="cough medicine" 40:5 40:6
do="nm"
mo="nm"
f="p.r.n." 40:7 40:7
du="nm"
r="nm"
ln="list"
10:
m="multivitamins" 40:3 40:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="ace inhibitor" 79:8 79:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="tachycardia." 79:0 79:0
ln="narrative"
12:
m="beta blocker" 79:5 79:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="tachycardia." 79:0 79:0
ln="narrative"
13:
m="aspirin." 80:3 80:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="tachycardia." 79:0 79:0
ln="narrative"
14:
m="lasix" 87:7 87:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="oxygen" 90:4 90:4
do="two liters" 89:11 90:0
mo="nasal cannula" 90:2 90:3
f="nm"
du="nm"
r="aspiration pneumonia" 88:2 88:3
ln="narrative"
16:
m="flagyl" 96:10 96:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="presumed aspiration pneumonia" 97:2 97:4
ln="narrative"
17:
m="vancomycin" 96:8 96:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="presumed aspiration pneumonia" 97:2 97:4
ln="narrative"
18:
m="levofloxacin" 97:0 97:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="presumed aspiration pneumonia" 97:2 97:4
ln="narrative"
19:
m="lovenox" 103:8 103:8
do="60 mg" 103:9 103:10
mo="subcu." 103:11 103:11
f="b.i.d." 103:12 103:12
du="for six months" 104:8 105:0
r="prophylaxis against dvt post-hip surgery" 104:1 104:5
ln="narrative"
20:
m="nexium" 108:2 108:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis...anticoagulation" 108:3 108:3,109:0 109:0
ln="narrative"
21:
m="hypoglycemics" 110:9 110:9
do="nm"
mo="oral" 110:8 110:8
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="insulin." 111:8 111:8
do="sliding scale" 111:6 111:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="k-dur" 118:12 118:12
do="20 meq" 118:9 118:10
mo="nm"
f="q.d." 119:0 119:0
du="nm"
r="nm"
ln="narrative"
24:
m="enteric-coated aspirin" 136:2 136:3
do="325 mg" 136:4 136:5
mo="p.o." 136:6 136:6
f="q.d." 136:7 136:7
du="nm"
r="nm"
ln="list"
25:
m="lopressor" 137:0 137:0
do="12.5 mg" 137:1 137:2
mo="p.o." 137:3 137:3
f="t.i.d." 137:4 137:4
du="nm"
r="nm"
ln="list"
26:
m="lisinopril" 139:0 139:0
do="5 mg" 139:1 139:2
mo="p.o." 139:3 139:3
f="q.d." 139:4 139:4
du="nm"
r="nm"
ln="list"
27:
m="lasix" 140:3 140:3
do="100 mg" 140:4 140:5
mo="p.o." 140:6 140:6
f="q.d." 140:7 140:7
du="nm"
r="nm"
ln="list"
28:
m="lovenox" 140:9 140:9
do="60 mg" 140:10 140:11
mo="subcu." 140:12 140:12
f="b.i.d." 140:13 140:13
du="x6 months" 140:14 141:0
r="nm"
ln="list"
29:
m="glipizide" 141:2 141:2
do="2.5 mg" 141:3 141:4
mo="p.o." 141:5 141:5
f="q.d." 141:6 141:6
du="nm"
r="nm"
ln="list"
30:
m="insulin" 141:10 141:10
do="sliding scale" 141:8 141:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="nexium" 141:12 141:12
do="20 mg" 142:0 142:1
mo="p.o." 142:2 142:2
f="q.d." 142:3 142:3
du="nm"
r="nm"
ln="list"
32:
m="silvadene" 142:5 142:5
do="nm"
mo="nm"
f="q.d." 143:10 143:10
du="nm"
r="foot wound" 143:6 143:7
ln="list"
33:
m="duoderm" 144:0 144:0
do="nm"
mo="nm"
f="q.3 days" 144:8 144:9
du="nm"
r="leg wound" 144:4 144:5
ln="list"
