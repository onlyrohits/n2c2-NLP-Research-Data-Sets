1:
m="cisplatin." 26:5 26:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="vp-16" 26:3 26:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="vancomycin" 30:5 30:5
do="nm"
mo="nm"
f="nm"
du="a ten-day course" 30:1 30:3
r="a mrsa urinary tract infection." 30:7 31:0
ln="narrative"
4:
m="levaquin" 64:4 64:4
do="500 mg." 64:5 64:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="magnesium" 64:2 64:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="vancomycin" 64:0 64:0
do="1 gm" 63:9 63:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="aspirin" 67:7 67:7
do="81 mg" 67:8 67:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="b12" 68:5 68:5
do="1000 mg" 68:6 68:7
mo="nm"
f="daily" 68:8 68:8
du="nm"
r="nm"
ln="list"
9:
m="baclofen" 68:0 68:0
do="5 mg" 68:1 68:2
mo="nm"
f="t.i.d." 68:3 68:3
du="nm"
r="nm"
ln="list"
10:
m="iron sulfate" 68:10 68:11
do="325 mg" 68:12 68:13
mo="nm"
f="daily" 69:0 69:0
du="nm"
r="nm"
ln="list"
11:
m="cymbalta" 69:2 69:2
do="20 mg" 69:3 69:4
mo="p.o." 69:5 69:5
f="b.i.d." 69:6 69:6
du="nm"
r="nm"
ln="list"
12:
m="neurontin" 69:8 69:8
do="100 mg" 69:9 69:10
mo="nm"
f="b.i.d." 69:11 69:11
du="nm"
r="nm"
ln="list"
13:
m="lamictal" 70:0 70:0
do="200 mg" 70:1 70:2
mo="nm"
f="b.i.d." 70:3 70:3
du="nm"
r="nm"
ln="list"
14:
m="levothyroxine" 70:9 70:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="prilosec" 70:5 70:5
do="20" 70:6 70:6
mo="nm"
f="daily" 70:7 70:7
du="nm"
r="nm"
ln="list"
16:
m="glucophage" 71:0 71:0
do="500" 71:1 71:1
mo="nm"
f="once a day" 71:2 71:4
du="nm"
r="nm"
ln="list"
17:
m="niacin" 71:12 71:12
do="500" 71:13 71:13
mo="nm"
f="once a day" 71:14 72:1
du="nm"
r="nm"
ln="list"
18:
m="reglan" 71:6 71:6
do="10" 71:7 71:7
mo="nm"
f="once a day" 71:8 71:10
du="nm"
r="nm"
ln="list"
19:
m="nicoderm patch" 72:15 73:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="senna" 72:3 72:3
do="2 tabs" 72:4 72:5
mo="nm"
f="b.i.d." 72:6 72:6
du="nm"
r="nm"
ln="list"
21:
m="zocor" 72:8 72:8
do="20 mg" 72:9 72:10
mo="nm"
f="once a day" 72:11 72:13
du="nm"
r="nm"
ln="list"
22:
m="colace" 73:2 73:2
do="100 mg" 73:3 73:4
mo="p.o." 73:5 73:5
f="b.i.d." 73:6 73:6
du="nm"
r="nm"
ln="list"
23:
m="lopressor" 73:8 73:8
do="100 mg" 73:9 73:10
mo="p.o." 73:11 73:11
f="b.i.d." 73:12 73:12
du="nm"
r="nm"
ln="list"
24:
m="lidoderm 5% patch" 74:0 74:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="ducolox" 75:2 75:2
do="nm"
mo="nm"
f="p.r.n." 74:10 74:10
du="nm"
r="nm"
ln="list"
26:
m="lactulose" 75:6 75:6
do="nm"
mo="nm"
f="p.r.n." 74:10 74:10
du="nm"
r="nm"
ln="list"
27:
m="mylanta" 75:4 75:4
do="nm"
mo="nm"
f="p.r.n." 74:10 74:10
du="nm"
r="nm"
ln="list"
28:
m="prednisone" 75:12 75:12
do="50 mg" 76:0 76:1
mo="nm"
f="p.r.n." 74:10 74:10
du="nm"
r="nm"
ln="list"
29:
m="seroquel" 75:8 75:8
do="100 mg" 75:9 75:10
mo="nm"
f="p.r.n." 74:10 74:10
du="nm"
r="nm"
ln="list"
30:
m="tylenol" 75:0 75:0
do="nm"
mo="nm"
f="p.r.n." 74:10 74:10
du="nm"
r="nm"
ln="list"
31:
m="dilaudid" 76:4 76:4
do="1 mg." 76:5 76:6
mo="nm"
f="p.r.n." 74:10 74:10
du="nm"
r="nm"
ln="list"
32:
m="antibiotics" 96:1 96:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="an infection" 95:4 95:5
ln="narrative"
33:
m="sedating medications" 97:5 97:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="vancomycin" 102:0 102:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="a presumed repeated mrsa uti." 102:2 102:6
ln="narrative"
35:
m="ciprofloxacin" 104:6 104:6
do="700 mg" 104:7 104:8
mo="p.o." 104:9 104:9
f="b.i.d." 104:10 104:10
du="12 days" 105:5 105:6
r="a presumed urinary tract infection" 105:8 106:0
ln="narrative"
36:
m="antipsychotics" 113:6 113:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="behavioral modification" 113:8 114:0
ln="narrative"
37:
m="haldol" 113:3 113:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="behavioral modification" 113:8 114:0
ln="narrative"
38:
m="haldol" 115:7 115:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="seroquel" 117:2 117:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="chemotherapy" 119:8 119:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="non-small cell lung cancer" 119:0 119:3
ln="narrative"
41:
m="sedating medications" 135:4 135:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="reglan" 136:3 136:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="baclofen" 137:0 137:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="cymbalta" 137:6 137:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="dilaudid" 137:2 137:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="trazodone." 137:4 137:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="dilaudid" 141:3 141:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="seroquel" 142:2 142:2
do="nm"
mo="nm"
f="p.r.n." 142:5 142:5
du="nm"
r="nm"
ln="narrative"
49:
m="cymbalta" 149:8 149:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="depression." 150:2 150:2
ln="narrative"
50:
m="lamictal" 149:2 149:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="complex seizures" 148:0 148:1
ln="narrative"
51:
m="lamictal" 149:2 149:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="olfactory hallucinations" 148:3 148:4
ln="narrative"
52:
m="tramadol" 152:3 152:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="this pain" 152:7 152:8
ln="narrative"
53:
m="tylenol" 152:5 152:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="this pain" 152:7 152:8
ln="narrative"
54:
m="novolog" 154:7 154:7
do="sliding scale" 154:8 155:0
mo="nm"
f="nm"
du="nm"
r="diabetes" 155:2 155:2
ln="narrative"
55:
m="levothyroxine" 156:0 156:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="graves'" 156:5 156:5
ln="narrative"
56:
m="levothyroxine" 156:0 156:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="radioiodine ablation." 157:0 157:1
ln="narrative"
57:
m="seroquel" 159:3 159:3
do="100 mg" 159:4 159:5
mo="p.o." 159:6 159:6
f="b.i.d." 159:7 159:7
du="nm"
r="disorientation" 158:4 158:4
ln="narrative"
58:
m="seroquel" 159:3 159:3
do="100 mg" 159:4 159:5
mo="p.o." 159:6 159:6
f="b.i.d." 159:7 159:7
du="nm"
r="intermittent agitation" 158:1 158:2
ln="narrative"
59:
m="zydis" 160:0 160:0
do="5 mg" 160:1 160:2
mo="p.o." 160:3 160:3
f="b.i.d. p.r.n." 160:4 160:5
du="nm"
r="nm"
ln="narrative"
60:
m="zydis" 160:0 160:0
do="nm"
mo="nm"
f="p.r.n." 161:0 161:0
du="over the course of her hospitalization" 161:1 161:6
r="nm"
ln="narrative"
61:
m="sedating medications" 162:2 162:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
