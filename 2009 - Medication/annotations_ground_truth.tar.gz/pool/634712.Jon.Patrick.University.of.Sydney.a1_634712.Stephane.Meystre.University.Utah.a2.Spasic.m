1:
m="tylenol ( acetaminophen )" 16:0 16:3
do="650-1 , 000 mg" 16:4 16:7
mo="po" 16:8 16:8
f="q4h prn" 16:9 16:10
du="nm"
r="pain" 16:11 16:11
ln="list"
2:
m="amiodarone" 17:0 17:0
do="200 mg" 17:1 17:2
mo="po" 17:3 17:3
f="qd" 17:4 17:4
du="nm"
r="nm"
ln="list"
3:
m="coumadin" 18:14 18:14
do="nm"
mo="po" 18:15 18:15
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="amiodarone hcl" 19:3 19:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="warfarin" 19:6 19:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="coumadin" 22:3 22:3
do="nm"
mo="po" 22:4 22:4
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="amiodarone hcl" 23:3 23:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="warfarin" 23:6 23:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="amiodarone hcl" 27:5 27:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="warfarin" 27:3 27:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="amiodarone hcl" 30:5 30:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="warfarin" 30:3 30:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="colace ( docusate sodium )" 32:0 32:4
do="100 mg" 32:5 32:6
mo="po" 32:7 32:7
f="bid" 32:8 32:8
du="nm"
r="nm"
ln="list"
14:
m="lasix ( furosemide )" 33:0 33:3
do="80 mg" 33:4 33:5
mo="po" 33:6 33:6
f="bid" 33:7 33:7
du="nm"
r="nm"
ln="list"
15:
m="micronase ( glyburide )" 44:0 44:3
do="10 mg" 44:4 44:5
mo="po" 44:6 44:6
f="bid" 44:7 44:7
du="nm"
r="nm"
ln="list"
16:
m="plaquenil ( hydroxychloroquine )" 55:0 55:3
do="200 mg" 55:4 55:5
mo="po" 55:6 55:6
f="bid" 55:7 55:7
du="nm"
r="nm"
ln="list"
17:
m="isordil ( isosorbide dinitrate )" 57:0 57:4
do="40 mg" 57:5 57:6
mo="po" 57:7 57:7
f="tid" 57:8 57:8
du="nm"
r="nm"
ln="list"
18:
m="lisinopril" 59:0 59:0
do="20 mg" 59:1 59:2
mo="po" 59:3 59:3
f="bid" 59:4 59:4
du="nm"
r="nm"
ln="list"
19:
m="kcl immediate rel." 62:3 62:5
do="nm"
mo="po" 62:6 62:6
f="qd" 62:8 62:8
du="nm"
r="nm"
ln="list"
20:
m="lisinopril" 64:3 64:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="potassium chloride" 64:5 65:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="potassium chloride" 68:3 68:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="lisinopril" 69:0 69:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="kcl immediate rel." 72:3 72:5
do="nm"
mo="po" 72:6 72:6
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="lisinopril" 73:3 73:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="potassium chloride" 73:5 74:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="lopressor ( metoprolol tartrate )" 75:0 75:4
do="25 mg" 75:5 75:6
mo="po" 75:7 75:7
f="bid" 75:8 75:8
du="nm"
r="nm"
ln="list"
28:
m="nitroglycerin 1/150 ( 0.4 mg )" 85:0 85:5
do="1 tab" 85:6 85:7
mo="sl" 85:8 85:8
f="q5min x 3 prn" 85:9 86:0
du="nm"
r="chest pain" 86:1 86:2
ln="list"
29:
m="coumadin ( warfarin sodium )" 87:0 87:4
do="2.5 mg" 88:7 88:8
mo="po" 88:10 88:10
f="qmwf" 88:9 88:9
du="nm"
r="nm"
ln="list"
30:
m="coumadin ( warfarin sodium )" 87:0 87:4
do="5 mg" 88:2 88:3
mo="po" 88:10 88:10
f="qtthsat;" 88:4 88:4
du="nm"
r="nm"
ln="list"
31:
m="amiodarone hcl" 94:3 94:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="warfarin" 94:6 94:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="norvasc ( amlodipine )" 96:0 96:3
do="10 mg" 96:4 96:5
mo="po" 96:6 96:6
f="qd" 96:7 96:7
du="nm"
r="nm"
ln="list"
34:
m="lovenox ( enoxaparin )" 97:0 97:3
do="70 mg" 97:4 97:5
mo="sc" 97:6 97:6
f="q12h" 97:7 97:7
du="x 4 days" 97:8 97:10
r="nm"
ln="list"
35:
m="amiodarone" 118:6 118:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="coumadin" 119:1 119:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="mvr" 118:10 118:10
ln="narrative"
37:
m="cardiac regimen" 127:4 127:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="coumadin" 128:3 128:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="lopressor" 128:1 128:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="amio" 129:0 129:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="isordil" 129:8 129:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="lasix" 129:6 129:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="lisinopril" 129:4 129:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="norvasc" 129:2 129:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="coumadin" 136:4 136:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="mvr" 136:6 136:6
ln="narrative"
46:
m="lopressor" 143:0 143:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="coumadin" 148:4 148:4
do="home dosing." 148:7 148:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="lovenox" 149:6 149:6
do="nm"
mo="nm"
f="nm"
du="for 4days" 149:3 149:4
r="nm"
ln="narrative"
49:
m="lovenox" 153:5 153:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="lovenox" 156:7 156:7
do="nm"
mo="injections" 156:8 156:8
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="coumadin" 157:9 157:9
do="regular" 157:8 157:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
