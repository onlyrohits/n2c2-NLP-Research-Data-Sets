1:
m="dobutamine" 22:5 22:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="captopril" 31:1 31:1
do="25 mg" 31:9 31:10
mo="nm"
f="t.i.d." 31:11 31:11
du="nm"
r="nm"
ln="narrative"
3:
m="captopril" 31:1 31:1
do="37.5 mg" 31:6 31:7
mo="nm"
f="t.i.d." 31:11 31:11
du="nm"
r="nm"
ln="narrative"
4:
m="captopril" 45:2 45:2
do="25 mg" 45:3 45:4
mo="p.o." 45:5 45:5
f="t.i.d." 45:6 45:6
du="nm"
r="nm"
ln="list"
5:
m="isordil" 45:8 45:8
do="40 mg" 45:9 45:10
mo="p.o." 46:0 46:0
f="t.i.d." 46:1 46:1
du="nm"
r="nm"
ln="list"
6:
m="lipitor" 46:3 46:3
do="20 mg" 46:4 46:5
mo="p.o." 46:6 46:6
f="q.d." 46:7 46:7
du="nm"
r="nm"
ln="list"
7:
m="nph insulin" 46:9 47:0
do="65 units" 47:1 47:2
mo="subcu" 47:3 47:3
f="b.i.d." 47:4 47:4
du="nm"
r="nm"
ln="list"
8:
m="torsemide" 47:9 47:9
do="120 mg" 47:10 47:11
mo="p.o." 47:12 47:12
f="q.a.m." 48:0 48:0
du="nm"
r="nm"
ln="list"
9:
m="xanax" 47:6 47:6
do="nm"
mo="nm"
f="p.r.n." 47:7 47:7
du="nm"
r="nm"
ln="list"
10:
m="digoxin" 48:8 48:8
do="0.125 mg" 48:9 48:10
mo="p.o." 48:11 48:11
f="q.d." 48:12 48:12
du="nm"
r="nm"
ln="list"
11:
m="torsemide" 48:2 48:2
do="80 mg" 48:3 48:4
mo="p.o." 48:5 48:5
f="q.p.m." 48:6 48:6
du="nm"
r="nm"
ln="list"
12:
m="prozac" 49:6 49:6
do="20 mg" 49:7 49:8
mo="p.o." 49:9 49:9
f="q.d." 49:10 49:10
du="nm"
r="nm"
ln="list"
13:
m="synthroid" 49:0 49:0
do="250 mcg" 49:1 49:2
mo="p.o." 49:3 49:3
f="q.d." 49:4 49:4
du="nm"
r="nm"
ln="list"
14:
m="ace inhibitor" 75:7 75:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="diuretics" 75:3 75:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="nitrates" 75:5 75:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="synthroid" 80:3 80:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
