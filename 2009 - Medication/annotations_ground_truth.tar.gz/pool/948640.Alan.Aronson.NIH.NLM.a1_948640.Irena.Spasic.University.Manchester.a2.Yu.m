1:
m="ecasa ( aspirin enteric coated )" 16:0 16:5
do="325 mg" 16:6 16:7
mo="po" 16:8 16:8
f="qd" 16:9 16:9
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 17:16 17:16
do="nm"
mo="po" 17:17 17:17
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 18:3 18:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 18:5 18:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="folate ( folic acid )" 20:0 20:4
do="1 mg" 20:5 20:6
mo="po" 20:7 20:7
f="qd" 20:8 20:8
du="nm"
r="nm"
ln="list"
6:
m="lisinopril" 21:0 21:0
do="30 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qd" 21:4 21:4
du="nm"
r="nm"
ln="list"
7:
m="potassium chloride immed. rel." 23:3 23:6
do="nm"
mo="po" 23:7 23:7
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="lisinopril" 25:3 25:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="potassium chloride" 25:5 26:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="thiamine hcl" 27:0 27:1
do="100 mg" 27:2 27:3
mo="po" 27:4 27:4
f="qd" 27:5 27:5
du="nm"
r="nm"
ln="list"
11:
m="mvi therapeutic ( therapeutic multivitamins )" 28:0 28:5
do="1 tab" 28:6 28:7
mo="po" 28:8 28:8
f="qd" 28:9 28:9
du="nm"
r="nm"
ln="list"
12:
m="simvastatin" 29:16 29:16
do="nm"
mo="po" 29:17 29:17
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="niacin" 30:3 30:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="vit. b-3" 30:5 30:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="simvastatin" 31:0 31:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="creon 20 ( pancrelipase 20000u )" 32:0 32:5
do="4 capsule" 32:6 32:7
mo="po" 32:8 32:8
f="tid" 32:9 32:9
du="nm"
r="nm"
ln="list"
17:
m="levofloxacin" 34:0 34:0
do="500 mg" 34:1 34:2
mo="po" 34:3 34:3
f="qd" 34:4 34:4
du="nm"
r="nm"
ln="list"
18:
m="iron products" 36:1 36:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="ciprofloxacin" 37:4 37:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="levofloxacin" 37:2 37:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="levofloxacin" 42:5 42:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="warfarin" 42:3 42:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="lantus ( insulin glargine )" 44:0 44:4
do="20 units" 44:5 44:6
mo="sc" 44:7 44:7
f="qd" 44:8 44:8
du="nm"
r="nm"
ln="list"
24:
m="lasix ( furosemide )" 46:0 46:3
do="40 mg" 46:4 46:5
mo="po" 46:6 46:6
f="qd" 46:7 46:7
du="nm"
r="nm"
ln="list"
25:
m="lipitor ( atorvastatin )" 47:0 47:3
do="20 mg" 47:4 47:5
mo="po" 47:6 47:6
f="qd" 47:7 47:7
du="nm"
r="nm"
ln="list"
26:
m="niacin" 49:3 49:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="vit. b-3" 49:5 49:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="atorvastatin calcium" 50:0 50:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="coumadin ( warfarin sodium )" 52:0 52:4
do="5 mg" 52:5 52:6
mo="po" 52:7 52:7
f="qpm" 52:8 52:8
du="nm"
r="nm"
ln="list"
30:
m="aspirin" 56:3 56:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="warfarin" 56:5 56:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="simvastatin" 57:3 57:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="warfarin" 57:5 57:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="levofloxacin" 58:3 58:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="warfarin" 58:5 58:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="levofloxacin" 59:3 59:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="warfarin" 59:5 59:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="ivf" 117:10 117:10
do="5 liters" 117:7 117:8
mo="nm"
f="nm"
du="nm"
r="hypovolemia." 117:1 117:1
ln="narrative"
39:
m="insulin." 118:0 118:0
do="36u" 117:12 117:12
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="insulin" 121:4 121:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="dmii" 120:2 120:2
ln="narrative"
41:
m="lantus" 122:2 122:2
do="20 units" 121:14 122:0
mo="nm"
f="qam" 122:3 122:3
du="nm"
r="nm"
ln="narrative"
42:
m="insulin" 123:2 123:2
do="nm"
mo="nm"
f="qam" 122:3 122:3
du="nm"
r="nm"
ln="narrative"
43:
m="lantus" 124:3 124:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="lispro" 124:5 124:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="lantus" 125:5 125:5
do="titrated to 20 units" 125:0 125:3
mo="nm"
f="qhs" 125:6 125:6
du="nm"
r="nm"
ln="narrative"
46:
m="lispro" 125:10 125:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="fs ranging from 120-600." 125:12 126:2
ln="narrative"
47:
m="lantus" 127:9 127:9
do="16" 127:10 127:10
mo="nm"
f="nm"
du="nm"
r="his fs" 126:5 126:6
ln="narrative"
48:
m="lantus" 129:1 129:1
do="20" 129:2 129:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="lispro" 129:4 129:4
do="ss" 129:5 129:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="lantus" 133:4 133:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="lispro" 133:6 133:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="coumadin" 134:3 134:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="pacer clot." 134:7 134:8
ln="narrative"
53:
m="coumadin" 136:0 136:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="clot" 134:12 134:12
ln="narrative"
54:
m="coumadin" 137:8 137:8
do="5" 137:9 137:9
mo="nm"
f="qd" 137:10 137:10
du="for one week." 138:8 138:10
r="nm"
ln="narrative"
55:
m="coumadin" 140:6 140:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="acei" 143:7 143:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="asa" 143:5 143:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
58:
m="statin." 143:10 143:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="coumadin." 151:8 151:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
60:
m="coumadin" 154:9 154:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="lantus" 155:0 155:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="insulin" 158:7 158:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="lantus" 158:13 158:13
do="20 units" 158:10 158:11
mo="nm"
f="every night at 10 pm" 158:15 159:1
du="nm"
r="nm"
ln="narrative"
64:
m="your medications" 162:0 162:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
65:
m="lantus" 168:4 168:4
do="nm"
mo="nm"
f="every night at 10 pm" 168:5 168:9
du="nm"
r="nm"
ln="narrative"
66:
m="insulin" 169:7 169:7
do="20 units" 169:4 169:5
mo="shot" 169:2 169:2
f="nm"
du="nm"
r="nm"
ln="narrative"
67:
m="other medications" 172:5 172:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
