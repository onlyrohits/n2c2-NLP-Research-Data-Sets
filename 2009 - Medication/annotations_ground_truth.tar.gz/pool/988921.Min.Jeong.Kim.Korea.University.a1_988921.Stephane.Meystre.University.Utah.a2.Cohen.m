1:
m="amiodarone;" 10:5 10:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="paroxysmal atrial fibrillation" 10:0 10:2
ln="narrative"
2:
m="gentamicin" 36:7 36:7
do="250 mg" 36:8 36:9
mo="nm"
f="nm"
du="times one" 36:10 36:11
r="a right upper lobe infiltrate" 35:7 35:11
ln="narrative"
3:
m="clindamycin" 37:0 37:0
do="600 mg." 37:1 37:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="clindamycin" 38:1 38:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia" 37:7 37:7
ln="narrative"
5:
m="lasix" 39:9 39:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="amiodarone." 40:8 40:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="lisinopril" 40:0 40:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="solu-medrol" 41:1 41:1
do="40 mg" 41:2 41:3
mo="intravenous" 41:4 41:4
f="q.6 hours " 41:5 41:6
du="nm"
r="possible asthma." 41:8 41:9
ln="narrative"
9:
m="amiodarone." 55:0 55:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="paroxysmal atrial fibrillation" 54:0 54:2
ln="narrative"
10:
m="amiodarone" 57:4 57:4
do="200 mg" 57:5 57:6
mo="p.o." 57:7 57:7
f="q.d." 57:8 57:8
du="nm"
r="nm"
ln="list"
11:
m="glyburide" 58:0 58:0
do="5 mg" 58:1 58:2
mo="p.o." 58:3 58:3
f="q.d." 58:4 58:4
du="nm"
r="nm"
ln="list"
12:
m="lopressor" 58:6 58:6
do="50 mg" 58:7 58:8
mo="p.o." 58:9 58:9
f="b.i.d." 59:0 59:0
du="nm"
r="nm"
ln="list"
13:
m="lisinopril" 59:7 59:7
do="40 mg" 59:8 59:9
mo="p.o." 59:10 59:10
f="q.d." 59:11 59:11
du="nm"
r="nm"
ln="list"
14:
m="prempro" 59:2 59:2
do="0.625/2.5" 59:3 59:3
mo="p.o." 59:4 59:4
f="q.d." 59:5 59:5
du="nm"
r="nm"
ln="list"
15:
m="beclomethasone" 60:7 60:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="coumadin" 60:0 60:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="nitroglycerin" 60:2 60:2
do="nm"
mo="sublingual" 60:3 60:3
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="zantac" 60:5 60:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="ventolin." 61:0 61:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="aspirin" 62:9 62:9
do="325" 62:10 62:10
mo="p.o." 62:11 62:11
f="q.d." 63:0 63:0
du="nm"
r="nm"
ln="list"
21:
m="lovenox" 62:4 62:4
do="60 mg" 62:5 62:6
mo="nm"
f="b.i.d." 62:7 62:7
du="nm"
r="nm"
ln="list"
22:
m="clindamycin" 63:8 63:8
do="600" 63:9 63:9
mo="intravenous" 63:10 63:10
f="q.8" 64:0 64:0
du="nm"
r="nm"
ln="list"
23:
m="lisinopril" 63:2 63:2
do="40 mg" 63:3 63:4
mo="p.o." 63:5 63:5
f="b.i.d." 63:6 63:6
du="nm"
r="nm"
ln="list"
24:
m="albuterol" 64:12 64:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="digoxin" 64:2 64:2
do="0.25" 64:3 64:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="lopressor" 64:5 64:5
do="100 mg" 64:6 64:7
mo="nm"
f="b.i.d." 64:8 64:8
du="nm"
r="nm"
ln="list"
27:
m="zantac" 64:10 64:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="amiodarone" 65:5 65:5
do="300 mg" 65:6 65:7
mo="nm"
f="once a day." 65:8 65:10
du="nm"
r="nm"
ln="list"
29:
m="flovent" 65:0 65:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="solu-medrol" 65:2 65:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="prednisone" 111:9 111:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="tapazole" 111:1 111:1
do="10 mg" 111:2 111:3
mo="p.o." 111:4 111:4
f="b.i.d." 111:5 111:5
du="nm"
r="nm"
ln="narrative"
33:
m="amiodarone" 114:8 114:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="calcium channel blockers" 120:1 120:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="lopressor." 120:8 120:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="clindamycin" 121:6 121:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia:" 121:0 121:0
ln="narrative"
37:
m="antibiotics." 124:0 124:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="bactrim double strength" 126:4 126:6
do="nm"
mo="nm"
f="b.i.d." 126:7 126:7
du="a total of seven days." 126:9 127:1
r="uric crystals" 125:8 125:9
ln="narrative"
39:
m="ativan" 130:0 130:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="a full panic attack" 128:10 129:2
ln="narrative"
40:
m="ativan" 130:0 130:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="severe anxiety" 128:5 128:6
ln="narrative"
41:
m="glyburide" 132:2 132:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus:" 132:0 132:1
ln="narrative"
42:
m="glyburide" 133:6 133:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus:" 132:0 132:1
ln="narrative"
43:
m="insulin" 133:3 133:3
do="sliding scale." 133:4 133:5
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus:" 132:0 132:1
ln="narrative"
44:
m="lasix" 138:5 138:5
do="20 mg" 138:2 138:3
mo="p.o." 138:6 138:6
f="q.d." 138:7 138:7
du="nm"
r="fluid accumulation" 137:6 137:7
ln="narrative"
45:
m="amiodarone" 141:3 141:3
do="200 mg" 141:4 141:5
mo="p.o." 141:6 141:6
f="q.d." 141:7 141:7
du="nm"
r="nm"
ln="narrative"
46:
m="lisinopril" 142:0 142:0
do="40 mg" 142:1 142:2
mo="p.o." 142:3 142:3
f="b.i.d." 142:4 142:4
du="nm"
r="nm"
ln="narrative"
47:
m="coumadin" 143:12 143:12
do="5.0 mg" 143:13 144:0
mo="p.o." 144:1 144:1
f="q.p.m." 144:2 144:2
du="nm"
r="nm"
ln="narrative"
48:
m="tapazole" 143:0 143:0
do="10 mg" 143:1 143:2
mo="p.o." 143:3 143:3
f="b.i.d." 143:4 143:4
du="nm"
r="nm"
ln="narrative"
49:
m="zantac" 143:6 143:6
do="150 mg" 143:7 143:8
mo="p.o." 143:9 143:9
f="b.i.d." 143:10 143:10
du="nm"
r="nm"
ln="narrative"
50:
m="bactrim double strength" 144:4 144:6
do="one tablet" 144:7 144:8
mo="p.o." 144:9 144:9
f="b.i.d" 144:10 144:10
du="times four days" 145:0 145:2
r="nm"
ln="list"
51:
m="prempro" 145:6 145:6
do="0.625/2.5 mg" 145:7 145:8
mo="p.o." 145:9 145:9
f="q.d." 145:10 145:10
du="nm"
r="nm"
ln="narrative"
52:
m="atenolol" 146:12 146:12
do="150 mg" 146:13 146:14
mo="p.o." 147:0 147:0
f="q.d." 147:1 147:1
du="nm"
r="nm"
ln="narrative"
53:
m="glyburide" 146:0 146:0
do="5 mg" 146:1 146:2
mo="p.o." 146:3 146:3
f="q.d." 146:4 146:4
du="nm"
r="nm"
ln="narrative"
54:
m="lasix" 146:6 146:6
do="20 mg" 146:7 146:8
mo="p.o." 146:9 146:9
f="q.d." 146:10 146:10
du="nm"
r="nm"
ln="narrative"
55:
m="diltiazem cd" 147:3 147:4
do="240 mg" 147:5 147:6
mo="p.o." 147:7 147:7
f="q.d." 147:8 147:8
du="nm"
r="nm"
ln="narrative"
