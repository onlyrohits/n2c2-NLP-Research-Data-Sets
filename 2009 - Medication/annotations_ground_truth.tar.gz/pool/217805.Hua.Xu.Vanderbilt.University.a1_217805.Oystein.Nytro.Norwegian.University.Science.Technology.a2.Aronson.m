1:
m="atenolol" 16:0 16:0
do="125 mg" 16:1 16:2
mo="po" 16:3 16:3
f="daily" 16:4 16:4
du="nm"
r="nm"
ln="list"
2:
m="lipitor ( atorvastatin )" 17:0 17:3
do="80 mg" 17:4 17:5
mo="po" 17:6 17:6
f="daily" 17:7 17:7
du="nm"
r="nm"
ln="list"
3:
m="atorvastatin calcium" 21:5 22:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="miconazole nitrate" 21:2 21:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="atorvastatin calcium" 23:5 24:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="miconazole nitrate" 23:2 23:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="niacin" 25:3 25:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="vit. b-3" 25:5 25:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="atorvastatin calcium" 26:0 26:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="keflex ( cephalexin )" 27:0 27:3
do="500 mg" 27:4 27:5
mo="po" 27:6 27:6
f="qid" 27:7 27:7
du="nm"
r="nm"
ln="list"
11:
m="plavix ( clopidogrel )" 30:0 30:3
do="75 mg" 30:4 30:5
mo="po" 30:6 30:6
f="daily" 30:7 30:7
du="nm"
r="nm"
ln="list"
12:
m="enteric coated asa" 32:0 32:2
do="325 mg" 32:3 32:4
mo="po" 32:5 32:5
f="daily" 32:6 32:6
du="nm"
r="nm"
ln="list"
13:
m="lasix ( furosemide )" 33:0 33:3
do="80 mg" 33:4 33:5
mo="po" 33:6 33:6
f="bid starting in am" 33:7 33:10
du="nm"
r="nm"
ln="list"
14:
m="potassium chloride slow rel. ( kcl slow release )" 34:0 34:8
do="10 meq" 35:0 35:1
mo="po" 35:2 35:2
f="daily" 35:3 35:3
du="nm"
r="nm"
ln="list"
15:
m="lisinopril" 38:3 38:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="potassium chloride" 38:5 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="lisinopril" 40:3 40:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="potassium chloride" 40:5 41:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="lisinopril" 42:0 42:0
do="5 mg" 42:1 42:2
mo="po" 42:3 42:3
f="daily" 42:4 42:4
du="nm"
r="nm"
ln="list"
20:
m="potassium chloride immed. rel." 45:3 45:6
do="nm"
mo="po" 45:7 45:7
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="lisinopril" 47:3 47:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="potassium chloride" 47:5 48:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="lisinopril" 49:3 49:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="potassium chloride" 49:5 50:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="potassium chloride" 53:3 53:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="lisinopril" 54:0 54:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="potassium chloride" 55:3 55:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="lisinopril" 56:0 56:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="miconazole nitrate 2% cream" 57:0 57:3
do="nm"
mo="tp" 57:4 57:4
f="bid" 57:5 57:5
du="nm"
r="nm"
ln="list"
30:
m="lipitor" 61:3 61:3
do="nm"
mo="po" 61:4 61:4
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="atorvastatin calcium" 62:5 63:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="miconazole nitrate" 62:2 62:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="miconazole nitrate" 66:4 66:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="simvastatin" 66:2 66:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="miconazole nitrate" 67:4 67:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="simvastatin" 67:2 67:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="miconazole nitrate 2% powder" 69:0 69:3
do="nm"
mo="topical tp" 69:4 69:5
f="bid" 69:6 69:6
du="nm"
r="nm"
ln="list"
38:
m="lipitor" 73:3 73:3
do="nm"
mo="po" 73:4 73:4
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="atorvastatin calcium" 74:5 75:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="miconazole nitrate" 74:2 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="niaspan ( nicotinic acid sustained release )" 76:0 76:6
do="0.5 gm" 76:7 76:8
mo="po" 76:9 76:9
f="qpm" 76:10 76:10
du="nm"
r="nm"
ln="list"
42:
m="aspirin" 77:2 77:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="facial flushing" 78:1 78:2
ln="list"
43:
m="lipitor" 81:3 81:3
do="nm"
mo="po" 81:4 81:4
f="nm"
du="nm"
r="nm"
ln="list"
44:
m="niacin" 82:3 82:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
45:
m="vit. b-3" 82:5 82:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
46:
m="atorvastatin calcium" 83:0 83:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
47:
m="niacin" 86:5 86:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
48:
m="simvastatin" 86:3 86:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
49:
m="vit. b-3" 87:0 87:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
50:
m="nitro." 112:0 112:0
do="nm"
mo="sl" 111:14 111:14
f="nm"
du="nm"
r="chest pain" 111:10 111:11
ln="narrative"
51:
m="asa" 117:8 117:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="le cellulitis" 117:13 118:0
ln="narrative"
52:
m="keflex" 117:10 117:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="le cellulitis" 117:13 118:0
ln="narrative"
53:
m="lasix" 123:6 123:6
do="40mg" 123:7 123:7
mo="nm"
f="qd" 123:8 123:8
du="nm"
r="nm"
ln="list"
54:
m="lipitor" 123:10 123:10
do="80mg" 124:0 124:0
mo="nm"
f="qd" 124:1 124:1
du="nm"
r="nm"
ln="list"
55:
m="norvasc" 123:3 123:3
do="10mg" 123:4 123:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
56:
m="asa" 124:11 124:11
do="325mg" 124:12 124:12
mo="nm"
f="qd" 125:0 125:0
du="nm"
r="nm"
ln="list"
57:
m="atenolol" 124:3 124:3
do="100mg" 124:4 124:4
mo="nm"
f="qd" 124:5 124:5
du="nm"
r="nm"
ln="list"
58:
m="isordil" 124:7 124:7
do="20mg" 124:8 124:8
mo="nm"
f="tid" 124:9 124:9
du="nm"
r="nm"
ln="list"
59:
m="asa" 164:6 164:6
do="statin/high dose" 164:4 164:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
60:
m="statin/high" 164:4 164:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="atenolol" 165:7 165:7
do="100mg" 165:9 165:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="atenolol" 165:7 165:7
do="125 mg." 165:11 166:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="plavix" 165:2 165:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
64:
m="niaspan" 166:2 166:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="low hdl" 166:4 166:5
ln="narrative"
65:
m="b-blocker" 171:14 171:14
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
66:
m="lasix" 171:1 171:1
do="40 mg" 171:3 171:4
mo="po" 171:5 171:5
f="daily" 171:6 171:6
du="nm"
r="nm"
ln="narrative"
67:
m="lasix" 171:1 171:1
do="80 mg" 171:8 171:9
mo="po" 171:10 171:10
f="bid" 171:11 171:11
du="nm"
r="nm"
ln="narrative"
68:
m="isordil." 172:4 172:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="norvasc" 172:1 172:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
70:
m="norvasc" 172:7 172:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
71:
m="asa/plavix" 174:8 174:8
do="nm"
mo="nm"
f="nm"
du="x 1 year." 175:2 175:4
r="nm"
ln="narrative"
72:
m="asa/plavix" 174:8 174:8
do="nm"
mo="nm"
f="nm"
du="x 1 year" 175:2 175:4
r="nm"
ln="narrative"
73:
m="abx" 180:11 180:11
do="nm"
mo="nm"
f="nm"
du="started 7/14 , stop 9/22" 181:0 181:4
r="nm"
ln="narrative"
74:
m="keflex" 180:0 180:0
do="nm"
mo="nm"
f="nm"
du="x 2 weeks" 180:1 180:3
r="peripheral vascular disease." 179:4 179:6
ln="narrative"
75:
m="potassium" 181:12 181:12
do="10 meq" 182:0 182:1
mo="nm"
f="daily" 182:2 182:2
du="nm"
r="nm"
ln="narrative"
76:
m="lasix." 182:5 182:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
77:
m="aspirin" 185:11 185:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
78:
m="plavix." 186:0 186:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
79:
m="these medications" 186:4 186:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
80:
m="atenolol." 187:8 187:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
81:
m="lasix" 187:5 187:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
82:
m="antibiotics" 188:0 188:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="cellulitis" 188:2 188:2
ln="narrative"
83:
m="toe cream." 188:10 189:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
