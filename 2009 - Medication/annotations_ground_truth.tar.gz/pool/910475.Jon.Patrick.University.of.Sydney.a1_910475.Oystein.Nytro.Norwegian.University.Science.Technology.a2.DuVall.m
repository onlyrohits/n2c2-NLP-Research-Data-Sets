1:
m="antianginal regimen" 28:11 28:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="aspirin." 30:4 30:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="dobutamine" 32:0 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="nitroglycerins" 40:6 40:6
do="three" 40:4 40:4
mo="sublingual" 40:5 40:5
f="nm"
du="nm"
r="her pain" 41:5 41:6
ln="narrative"
5:
m="nitroglycerins" 40:6 40:6
do="three" 40:4 40:4
mo="sublingual" 40:5 40:5
f="nm"
du="nm"
r="her typical anginal symptoms" 38:0 38:3
ln="narrative"
6:
m="nitroglycerins" 40:6 40:6
do="three" 40:4 40:4
mo="sublingual" 40:5 40:5
f="nm"
du="nm"
r="shortness of breath" 39:2 39:4
ln="narrative"
7:
m="atenolol" 47:5 47:5
do="50 mg" 47:6 47:7
mo="p.o." 47:8 47:8
f="q.d." 47:9 47:9
du="nm"
r="nm"
ln="list"
8:
m="axid" 48:0 48:0
do="150 mg" 48:1 48:2
mo="p.o." 48:3 48:3
f="b.i.d." 48:4 48:4
du="nm"
r="nm"
ln="list"
9:
m="enteric coated aspirin" 48:6 48:8
do="325 mg" 48:9 48:10
mo="p.o." 48:11 48:11
f="q.d." 48:12 48:12
du="nm"
r="nm"
ln="list"
10:
m="coumadin" 49:6 49:6
do="10 mg" 49:7 49:8
mo="p.o." 49:9 49:9
f="q.h.s." 49:10 49:10
du="nm"
r="nm"
ln="list"
11:
m="diltiazem" 50:0 50:0
do="240 mg" 50:1 50:2
mo="p.o." 50:3 50:3
f="q.d." 50:4 50:4
du="nm"
r="nm"
ln="list"
12:
m="lisinopril" 50:6 50:6
do="10 mg" 50:7 50:8
mo="p.o." 50:9 50:9
f="q.d." 50:10 50:10
du="nm"
r="nm"
ln="list"
13:
m="lopipd" 50:12 50:12
do="600 mg" 50:13 51:0
mo="p.o." 51:1 51:1
f="q.d." 51:2 51:2
du="nm"
r="nm"
ln="list"
14:
m="insulin , nph" 51:10 51:12
do="50 units" 52:2 52:3
mo="nm"
f="q.p.m." 52:4 52:4
du="nm"
r="nm"
ln="list"
15:
m="insulin , nph" 51:10 51:12
do="75 units" 51:14 51:15
mo="sub-q" 51:16 51:16
f="q.a.m." 52:0 52:0
du="nm"
r="nm"
ln="list"
16:
m="lasix" 51:4 51:4
do="40 mg" 51:5 51:6
mo="p.o." 51:7 51:7
f="q.d." 51:8 51:8
du="nm"
r="nm"
ln="list"
17:
m="insulin regular" 52:6 52:7
do="25 units" 52:8 52:9
mo="sub-q" 52:10 52:10
f="q.a.m." 52:11 52:11
du="nm"
r="nm"
ln="list"
18:
m="heparin" 82:6 82:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="unstable angina." 83:4 83:5
ln="narrative"
19:
m="insulin" 96:1 96:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="her blood sugars" 96:10 97:1
ln="narrative"
20:
m="enteric coated aspirin" 98:4 98:6
do="325 mg" 98:7 99:0
mo="p.o." 99:1 99:1
f="q.d.;" 99:2 99:2
du="nm"
r="nm"
ln="list"
21:
m="lasix" 99:3 99:3
do="40 mg" 99:4 99:5
mo="p.o." 99:6 99:6
f="q.d.;" 99:7 99:7
du="nm"
r="nm"
ln="list"
22:
m="lopid" 99:8 99:8
do="600 mg" 99:9 99:10
mo="p.o." 100:0 100:0
f="q.d.;" 100:1 100:1
du="nm"
r="nm"
ln="list"
23:
m="insulin nph" 100:2 100:3
do="100 units" 100:4 100:5
mo="sub-q" 100:6 100:6
f="q.a.m." 100:7 100:7
du="nm"
r="nm"
ln="list"
24:
m="insulin nph" 100:2 100:3
do="70 units" 100:9 100:10
mo="sub-q" 100:11 100:11
f="q.h.s." 101:0 101:0
du="nm"
r="nm"
ln="list"
25:
m="insulin regular" 101:2 101:3
do="25 units" 101:4 101:5
mo="sub-q" 101:6 101:6
f="q.a.m.;" 101:7 101:7
du="nm"
r="nm"
ln="list"
26:
m="lisinopril" 101:8 101:8
do="10 mg" 101:9 101:10
mo="p.o." 102:0 102:0
f="q.d.;" 102:1 102:1
du="nm"
r="nm"
ln="list"
27:
m="nitroglycerin 1/150th" 102:2 102:3
do="one tablet" 102:4 102:5
mo="sublingual" 102:6 102:6
f="q. 5 minutes x 3 p.r.n." 102:7 103:2
du="nm"
r="chest pain;" 103:3 103:4
ln="list"
28:
m="coumadin" 103:10 103:10
do="10 mg" 103:11 103:12
mo="p.o." 104:0 104:0
f="q.h.s.;" 104:1 104:1
du="nm"
r="nm"
ln="list"
29:
m="omeprazole" 103:5 103:5
do="20 mg" 103:6 103:7
mo="p.o." 103:8 103:8
f="q.d.;" 103:9 103:9
du="nm"
r="nm"
ln="list"
30:
m="diltiazem cd" 104:2 104:3
do="240 mg" 104:4 104:5
mo="p.o." 104:6 104:6
f="q.d." 104:7 104:7
du="nm"
r="nm"
ln="list"
