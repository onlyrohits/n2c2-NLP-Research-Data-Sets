1:
m="ciprofloxacin" 28:3 28:3
do="nm"
mo="nm"
f="nm"
du="seven-day course" 28:0 28:1
r="pain." 28:7 28:7
ln="narrative"
2:
m="oxycodone" 28:5 28:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain." 28:7 28:7
ln="narrative"
3:
m="ciprofloxacin" 29:0 29:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="ciprofloxacin." 30:4 30:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="oxycodone" 30:2 30:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="antibiotics." 32:0 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="ampicillin" 41:11 41:11
do="2 g" 41:12 41:13
mo="iv" 41:14 41:14
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="flagyl" 42:5 42:5
do="500 mg" 42:6 42:7
mo="iv" 42:8 42:8
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="gentamicin" 42:0 42:0
do="80 mg" 42:1 42:2
mo="iv" 42:3 42:3
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="insulin." 42:13 42:13
do="8 units" 42:10 42:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="flagyl." 74:7 74:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="levofloxacin" 74:2 74:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="vancomycin" 74:4 74:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="flagyl" 77:7 77:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="levofloxacin" 77:2 77:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="vancomycin" 77:4 77:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="vancomycin." 82:10 82:10
do="nm"
mo="nm"
f="nm"
du="eight weeks" 82:7 82:8
r="nm"
ln="narrative"
18:
m="flagyl" 85:0 85:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="levofloxacin" 85:2 85:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="erythromycin" 92:8 92:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="erythromycin" 95:2 95:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="reglan" 95:6 95:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="compazine" 97:10 97:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nausea." 98:0 98:0
ln="narrative"
24:
m="cozaar" 104:2 104:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="lasix" 104:0 104:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="iron supplementation." 113:10 114:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="iron deficient." 113:4 113:5
ln="narrative"
27:
m="darbepoetin" 115:7 115:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="her anemia" 115:0 115:1
ln="narrative"
28:
m="erythropoietin" 116:2 116:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="her anemia" 115:0 115:1
ln="narrative"
29:
m="aspirin" 117:7 117:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="calcium channel blocker." 118:3 118:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="statin" 118:0 118:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="beta-blocker" 119:0 119:0
do="nm"
mo="nm"
f="nm"
du="during her hospital course" 119:1 119:4
r="nm"
ln="narrative"
33:
m="aspart" 121:4 121:4
do="nm"
mo="nm"
f="nm"
du="during her hospital stay." 121:5 121:8
r="nm"
ln="narrative"
34:
m="nph" 121:2 121:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="insulin regimen" 123:8 124:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="heparin" 125:7 125:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="nexium." 125:9 125:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="tylenol" 133:1 133:1
do="650 mg" 133:2 133:3
mo="p.o." 133:4 133:4
f="q.4. p.r.n." 133:5 133:6
du="nm"
r="headache." 133:7 133:7
ln="list"
39:
m="aspirin" 134:1 134:1
do="81 mg" 134:2 134:3
mo="p.o." 134:4 134:4
f="daily." 134:5 134:5
du="nm"
r="nm"
ln="list"
40:
m="colace" 135:1 135:1
do="100 mg" 135:2 135:3
mo="p.o." 135:4 135:4
f="b.i.d." 135:5 135:5
du="nm"
r="nm"
ln="list"
41:
m="heparin" 136:1 136:1
do="5000 units" 136:2 136:3
mo="subq" 136:4 136:4
f="t.i.d." 136:5 136:5
du="nm"
r="nm"
ln="list"
42:
m="dilaudid" 137:1 137:1
do="0.4-0.8 mg" 137:2 137:3
mo="p.o." 137:4 137:4
f="q.4. p.r.n." 137:5 137:6
du="nm"
r="pain." 137:7 137:7
ln="list"
43:
m="insulin nph human" 138:1 138:3
do="20 units" 138:4 138:5
mo="subq" 138:6 138:6
f="b.i.d." 138:7 138:7
du="nm"
r="nm"
ln="list"
44:
m="lactulose" 139:1 139:1
do="30 ml" 139:2 139:3
mo="p.o." 139:4 139:4
f="q.i.d. p.r.n." 139:5 139:6
du="nm"
r="constipation." 139:7 139:7
ln="list"
45:
m="reglan" 140:1 140:1
do="5 mg" 140:2 140:3
mo="p.o." 140:4 140:4
f="q.a.c." 140:5 140:5
du="nm"
r="nm"
ln="list"
46:
m="reglan" 141:1 141:1
do="5 mg" 141:2 141:3
mo="p.o." 141:4 141:4
f="q.h.s." 141:5 141:5
du="nm"
r="nm"
ln="list"
47:
m="lopressor" 142:1 142:1
do="50 mg" 142:2 142:3
mo="p.o." 142:4 142:4
f="q.i.d." 142:5 142:5
du="nm"
r="nm"
ln="list"
48:
m="senna tablets" 143:1 143:2
do="two tabs" 143:3 143:4
mo="p.o." 143:5 143:5
f="b.i.d." 143:6 143:6
du="nm"
r="nm"
ln="list"
49:
m="norvasc" 144:1 144:1
do="10 mg" 144:2 144:3
mo="p.o." 144:4 144:4
f="daily." 144:5 144:5
du="nm"
r="nm"
ln="list"
50:
m="compazine" 145:1 145:1
do="5-10 mg" 145:2 145:3
mo="p.o." 145:4 145:4
f="q.6h. p.r.n." 145:5 145:6
du="nm"
r="nausea." 145:7 145:7
ln="list"
51:
m="nephrocaps" 146:1 146:1
do="one tab" 146:2 146:3
mo="p.o." 146:4 146:4
f="daily." 146:5 146:5
du="nm"
r="nm"
ln="list"
52:
m="insulin aspart" 147:1 147:2
do="sliding scale" 147:3 147:4
mo="subq" 147:5 147:5
f="a.c." 147:6 147:6
du="nm"
r="nm"
ln="list"
53:
m="insulin aspart" 148:1 148:2
do="4 units" 148:3 148:4
mo="subq" 148:5 148:5
f="q.a.c." 148:6 148:6
du="nm"
r="nm"
ln="list"
54:
m="lipitor" 149:1 149:1
do="80 mg" 149:2 149:3
mo="p.o." 149:4 149:4
f="daily." 149:5 149:5
du="nm"
r="nm"
ln="list"
55:
m="protonix" 150:1 150:1
do="40 mg" 150:2 150:3
mo="p.o." 150:4 150:4
f="daily." 150:5 150:5
du="nm"
r="nm"
ln="list"
56:
m="vancomycin" 151:1 151:1
do="1 g" 151:2 151:3
mo="iv" 151:4 151:4
f="three times a week." 151:5 151:8
du="nm"
r="nm"
ln="list"
57:
m="ergocalciferol" 153:1 153:1
do="50 , 000 units" 153:2 153:5
mo="p.o." 153:6 153:6
f="q. week" 153:7 153:8
du="for six weeks." 153:9 153:11
r="nm"
ln="list"
