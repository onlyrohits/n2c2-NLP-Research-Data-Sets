1:
m="colace ( docusate sodium )" 16:0 16:4
do="100 mg" 16:5 16:6
mo="po" 16:7 16:7
f="bid" 16:8 16:8
du="nm"
r="nm"
ln="list"
2:
m="nexium ( esomeprazole )" 17:0 17:3
do="40 mg" 17:4 17:5
mo="po" 17:6 17:6
f="bid" 17:7 17:7
du="nm"
r="nm"
ln="list"
3:
m="dilaudid ( hydromorphone hcl )" 18:0 18:4
do="2-6 mg" 18:5 18:6
mo="po" 18:7 18:7
f="q4h prn" 18:8 18:9
du="nm"
r="pain" 18:10 18:10
ln="list"
4:
m="atrovent hfa inhaler ( ipratropium inhaler )" 19:0 19:6
do="2 puff" 20:0 20:1
mo="inh" 20:2 20:2
f="qid prn" 20:3 20:4
du="nm"
r="shortness of breath" 20:5 20:7
ln="list"
5:
m="lopressor ( metoprolol tartrate )" 24:0 24:4
do="12.5 mg" 24:5 24:6
mo="po" 24:7 24:7
f="bid" 24:8 24:8
du="nm"
r="nm"
ln="list"
6:
m="ms contin ( morphine controlled release )" 27:0 27:6
do="45 mg" 27:7 27:8
mo="po" 27:9 27:9
f="qam" 27:10 27:10
du="nm"
r="nm"
ln="list"
7:
m="ms contin ( morphine controlled release )" 28:0 28:6
do="30 mg" 28:7 28:8
mo="po" 28:9 28:9
f="qpm" 28:10 28:10
du="nm"
r="nm"
ln="list"
8:
m="simvastatin" 29:0 29:0
do="80 mg" 29:1 29:2
mo="po" 29:3 29:3
f="daily" 29:4 29:4
du="nm"
r="nm"
ln="list"
9:
m="terazosin hcl" 32:0 32:1
do="10 mg" 32:2 32:3
mo="po" 32:4 32:4
f="daily" 32:5 32:5
du="number of doses required ( approximate ): 3" 33:0 33:7
r="nm"
ln="list"
10:
m="dilaudid" 54:2 54:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="his increased discomfort." 54:10 55:0
ln="narrative"
11:
m="lovenox" 59:2 59:2
do="nm"
mo="nm"
f="nm"
du="during his admission." 59:6 59:8
r="dvt prophylaxis" 59:4 59:5
ln="narrative"
12:
m="oral medications." 61:5 61:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="his pain" 60:12 61:0
ln="narrative"
13:
m="narcotic" 69:9 69:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain control." 69:11 69:12
ln="narrative"
14:
m="this medication." 71:1 71:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="narcotic pain medications" 72:4 72:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="constipation" 73:0 73:0
ln="narrative"
16:
m="this medication" 72:1 72:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="stool softener ( colace )" 73:12 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="constipation" 73:0 73:0
ln="narrative"
18:
m="home medications" 82:2 82:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
