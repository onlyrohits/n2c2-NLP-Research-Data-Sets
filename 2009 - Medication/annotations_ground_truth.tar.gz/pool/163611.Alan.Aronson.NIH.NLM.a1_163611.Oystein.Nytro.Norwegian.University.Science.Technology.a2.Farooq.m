1:
m="lasix" 26:7 26:7
do="80 mg" 27:4 27:5
mo="p.o." 27:6 27:6
f="b.i.d." 27:7 27:7
du="nm"
r="a chf exacerbation" 25:9 25:11
ln="narrative"
2:
m="lasix" 30:2 30:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="lasix" 41:6 41:6
do="100 mg" 41:7 41:8
mo="iv" 41:5 41:5
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="levofloxacin" 41:13 41:13
do="750 mg" 41:10 41:11
mo="nm"
f="nm"
du="x1." 41:14 41:14
r="nm"
ln="narrative"
5:
m="aspirin" 45:3 45:3
do="81 mg" 45:4 45:5
mo="nm"
f="daily" 45:7 45:7
du="nm"
r="nm"
ln="list"
6:
m="diltiazem extended release" 45:9 46:0
do="120 mg" 46:1 46:2
mo="nm"
f="daily" 46:3 46:3
du="nm"
r="nm"
ln="list"
7:
m="tylenol" 45:0 45:0
do="nm"
mo="nm"
f="p.r.n." 45:1 45:1
du="nm"
r="nm"
ln="list"
8:
m="colace" 46:5 46:5
do="100 mg" 46:6 46:7
mo="nm"
f="twice daily" 46:8 46:9
du="nm"
r="nm"
ln="list"
9:
m="iron sulfate" 46:11 46:12
do="325 mg" 46:13 47:0
mo="nm"
f="three times daily" 47:1 47:3
du="nm"
r="nm"
ln="list"
10:
m="folic acid" 47:5 47:6
do="1 mg" 47:7 47:8
mo="nm"
f="daily" 47:9 47:9
du="nm"
r="nm"
ln="list"
11:
m="lasix" 47:11 47:11
do="80 mg" 47:12 47:13
mo="p.o." 47:14 47:14
f="twice daily" 48:0 48:1
du="nm"
r="nm"
ln="list"
12:
m="gabapentin" 48:3 48:3
do="100 mg" 48:4 48:5
mo="nm"
f="twice daily" 48:6 48:7
du="nm"
r="nm"
ln="list"
13:
m="nph insulin" 48:9 48:10
do="20 units" 48:11 48:12
mo="subcutaneously" 49:0 49:0
f="daily" 49:1 49:1
du="nm"
r="nm"
ln="list"
14:
m="regular insulin" 49:3 49:4
do="sliding scale" 49:5 49:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="xalatan eye drops" 49:8 50:0
do="one drop" 50:1 50:2
mo="each eye" 50:3 50:4
f="q.p.m." 50:5 50:5
du="nm"
r="nm"
ln="list"
16:
m="metoprolol" 50:7 50:7
do="12.5 mg" 50:8 50:9
mo="nm"
f="twice daily" 50:10 50:11
du="nm"
r="nm"
ln="list"
17:
m="senna tablets" 51:0 51:1
do="nm"
mo="nm"
f="twice daily" 51:2 51:3
du="nm"
r="nm"
ln="list"
18:
m="simvastatin" 51:5 51:5
do="40 mg" 51:6 51:7
mo="nm"
f="once daily." 51:8 51:9
du="nm"
r="nm"
ln="list"
19:
m="antibiotics." 114:1 114:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia" 113:5 113:5
ln="narrative"
20:
m="aspirin" 123:8 123:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="beta-blocker" 124:0 124:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="statin medications." 124:2 124:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="lasix" 131:9 131:9
do="100" 131:7 131:7
mo="iv" 131:8 131:8
f="nm"
du="for several days." 131:10 132:1
r="nm"
ln="narrative"
24:
m="lasix" 133:0 133:0
do="80 mg" 133:2 133:3
mo="p.o." 133:4 133:4
f="b.i.d." 133:5 133:5
du="nm"
r="nm"
ln="narrative"
25:
m="beta-blocker." 137:0 137:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="calcium channel blocker" 137:2 137:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="amyloid." 139:7 139:7
ln="narrative"
27:
m="diltiazem" 137:6 137:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="amyloid." 139:7 139:7
ln="narrative"
28:
m="nitrate" 140:4 140:4
do="nm"
mo="nm"
f="nm"
du="during this admission" 140:5 140:7
r="reduce preload" 140:11 141:0
ln="narrative"
29:
m="coumadin" 163:0 163:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="amyloid" 164:3 164:3
ln="narrative"
30:
m="coumadin" 163:0 163:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="anticoagulation" 163:2 163:2
ln="narrative"
31:
m="coumadin" 163:0 163:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 163:5 163:6
ln="narrative"
32:
m="coumadin" 166:6 166:6
do="3.5 mg" 166:7 166:8
mo="nm"
f="every evening" 166:9 166:10
du="nm"
r="nm"
ln="narrative"
33:
m="levofloxacin" 174:5 174:5
do="750 mg" 174:7 174:8
mo="nm"
f="daily." 174:9 174:9
du="five-day course" 174:2 174:3
r="pneumonia." 173:6 173:6
ln="narrative"
34:
m="antibiotics" 175:2 175:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="coumadin" 182:1 182:1
do="nm"
mo="nm"
f="nm"
du="during this admission" 182:2 182:4
r="amyloid" 183:0 183:0
ln="narrative"
36:
m="coumadin" 182:1 182:1
do="nm"
mo="nm"
f="nm"
du="during this admission" 182:2 182:4
r="atrial fibrillation" 182:6 182:7
ln="narrative"
37:
m="coumadin" 183:2 183:2
do="3.5 mg" 183:8 183:9
mo="nm"
f="nm"
du="nm"
r="subtherapeutic inr." 184:0 184:1
ln="narrative"
38:
m="coumadin" 183:2 183:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="nph insulin" 190:7 190:8
do="20 units" 190:11 190:12
mo="subcutaneous" 191:0 191:0
f="daily" 191:1 191:1
du="nm"
r="diabetes." 189:8 189:8
ln="narrative"
40:
m="insulin" 191:6 191:6
do="sliding scale." 191:7 191:8
mo="nm"
f="nm"
du="nm"
r="diabetes." 189:8 189:8
ln="narrative"
41:
m="nph" 192:6 192:6
do="10 units" 192:10 193:0
mo="nm"
f="nm"
du="nm"
r="persistent hypoglycemia" 192:1 192:2
ln="narrative"
42:
m="nph insulin" 193:2 193:3
do="10 units" 192:10 193:0
mo="subcutaneous" 193:4 193:4
f="daily." 193:5 193:5
du="nm"
r="persistent hypoglycemia" 192:1 192:2
ln="narrative"
43:
m="magnesium supplementation" 203:4 203:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="myoclonic jerks" 201:2 201:3
ln="narrative"
44:
m="oxycodone" 205:6 205:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="low back pain" 204:7 204:9
ln="narrative"
45:
m="lovenox" 211:8 211:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="dvt" 211:6 211:6
ln="narrative"
46:
m="coumadin." 212:4 212:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis:" 211:1 211:1
ln="narrative"
47:
m="tylenol" 223:1 223:1
do="650 mg" 223:2 223:3
mo="p.o." 223:4 223:4
f="q.4h. p.r.n." 223:5 223:6
du="nm"
r="nm"
ln="list"
48:
m="aspirin" 224:1 224:1
do="81 mg" 224:2 224:3
mo="p.o." 224:4 224:4
f="daily." 224:5 224:5
du="nm"
r="nm"
ln="list"
49:
m="colace" 225:1 225:1
do="100 mg" 225:2 225:3
mo="p.o." 225:4 225:4
f="b.i.d." 225:5 225:5
du="nm"
r="nm"
ln="list"
50:
m="ferrous sulfate" 226:1 226:2
do="325 mg" 226:3 226:4
mo="p.o." 226:5 226:5
f="three times daily." 226:6 226:8
du="nm"
r="nm"
ln="list"
51:
m="folic acid" 227:1 227:2
do="1 mg" 227:3 227:4
mo="by mouth" 227:5 227:6
f="once daily." 227:7 227:8
du="nm"
r="nm"
ln="list"
52:
m="lasix" 228:1 228:1
do="80 mg" 228:2 228:3
mo="p.o." 228:4 228:4
f="twice daily." 228:5 228:6
du="nm"
r="nm"
ln="list"
53:
m="gabapentin" 229:1 229:1
do="100 mg" 229:2 229:3
mo="by mouth" 229:4 229:5
f="b.i.d." 229:6 229:6
du="nm"
r="nm"
ln="list"
54:
m="insulin nph" 230:1 230:2
do="10 units" 230:3 230:4
mo="subcutaneous" 230:5 230:5
f="daily." 230:6 230:6
du="nm"
r="nm"
ln="list"
55:
m="combivent" 231:1 231:1
do="2 puffs" 231:2 231:3
mo="inhaled" 231:4 231:4
f="four times daily p.r.n." 231:5 231:8
du="while the patient is recovering from his pneumonia." 232:4 233:0
r="shortness of breath" 231:9 232:1
ln="list"
56:
m="combivent" 231:1 231:1
do="2 puffs" 231:2 231:3
mo="inhaled" 231:4 231:4
f="four times daily p.r.n." 231:5 231:8
du="while the patient is recovering from his pneumonia." 232:4 233:0
r="wheezing" 232:3 232:3
ln="list"
57:
m="isosorbide dinitrate" 234:1 234:2
do="20 mg" 234:3 234:4
mo="p.o." 234:5 234:5
f="three times daily." 234:6 234:8
du="nm"
r="nm"
ln="list"
58:
m="xalatan eye drops" 235:1 235:3
do="one drop" 235:4 235:5
mo="each eye" 235:6 235:7
f="q.p.m." 235:8 235:8
du="nm"
r="nm"
ln="list"
59:
m="metoprolol tartrate" 236:1 236:2
do="12.5 mg" 236:3 236:4
mo="by mouth" 236:5 236:6
f="twice daily." 236:7 236:8
du="nm"
r="nm"
ln="list"
60:
m="oxycodone" 237:1 237:1
do="2.5 mg" 237:2 237:3
mo="by mouth" 237:4 237:5
f="every six hours p.r.n." 237:6 237:9
du="nm"
r="pain." 237:10 237:10
ln="list"
61:
m="senna tablets" 238:1 238:2
do="two tablets" 238:3 238:4
mo="by mouth" 238:5 238:6
f="twice daily." 238:7 238:8
du="nm"
r="nm"
ln="list"
62:
m="simvastatin" 239:1 239:1
do="40 mg" 239:2 239:3
mo="by mouth" 239:4 239:5
f="at bedtime." 239:6 239:7
du="nm"
r="nm"
ln="list"
63:
m="multivitamin" 240:1 240:1
do="one tablet" 240:2 240:3
mo="by mouth" 240:4 240:5
f="daily." 240:6 240:6
du="nm"
r="nm"
ln="list"
64:
m="coumadin" 241:1 241:1
do="3.5 mg" 241:2 241:3
mo="by mouth" 241:4 241:5
f="q.p.m." 241:6 241:6
du="nm"
r="nm"
ln="list"
65:
m="diltiazem" 243:0 243:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
66:
m="nph insulin" 243:3 243:4
do="10 units" 244:3 244:4
mo="nm"
f="daily." 244:5 244:5
du="nm"
r="nm"
ln="narrative"
67:
m="nph insulin" 243:3 243:4
do="10 units" 244:3 244:4
mo="nm"
f="daily" 244:5 244:5
du="nm"
r="nm"
ln="narrative"
68:
m="multivitamin" 244:7 244:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="coumadin" 245:4 245:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
70:
m="isosorbide dinitrate" 245:0 245:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
71:
m="coumadin" 250:4 250:4
do="nm"
mo="nm"
f="as necessary" 250:5 250:6
du="nm"
r="target inr" 250:8 250:9
ln="narrative"
72:
m="insulin" 270:2 270:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
73:
m="coumadin" 273:5 273:5
do="nm"
mo="nm"
f="as needed" 273:6 273:7
du="nm"
r="nm"
ln="narrative"
