1:
m="lasix" 75:3 75:3
do="nm"
mo="iv" 75:2 75:2
f="nm"
du="nm"
r="congestive heart failure" 74:3 74:5
ln="narrative"
2:
m="zaroxolyn" 75:6 75:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="congestive heart failure" 74:3 74:5
ln="narrative"
3:
m="lasix" 81:7 81:7
do="nm"
mo="oral" 81:6 81:6
f="nm"
du="nm"
r="her diuresis" 81:10 82:0
ln="narrative"
4:
m="that medication." 83:9 83:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="torsemide" 83:1 83:1
do="nm"
mo="oral" 83:0 83:0
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="coumadin." 89:5 89:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="anticoagulation" 89:3 89:3
ln="narrative"
7:
m="heparin" 89:0 89:0
do="nm"
mo="intravenous" 88:6 88:6
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="heparin" 91:2 91:2
do="nm"
mo="iv" 91:1 91:1
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="levofloxacin." 99:2 99:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="a bacterial urinary tract infection" 97:1 97:5
ln="narrative"
10:
m="levofloxacin" 100:2 100:2
do="nm"
mo="iv" 100:1 100:1
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="cefixime." 101:0 101:0
do="nm"
mo="p.o." 100:9 100:9
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="cefixime" 101:9 101:9
do="nm"
mo="p.o." 101:8 101:8
f="nm"
du="a five-day course" 101:4 101:6
r="nm"
ln="narrative"
13:
m="that medicine" 102:9 102:10
do="nm"
mo="nm"
f="nm"
du="a 10-day course." 103:1 103:3
r="nm"
ln="narrative"
14:
m="insulin" 106:1 106:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus" 105:1 105:2
ln="narrative"
15:
m="insulin" 108:5 108:5
do="nm"
mo="subcutaneous injections." 108:6 108:7
f="nm"
du="during this hospitalization" 107:7 107:9
r="her blood sugar" 107:12 108:1
ln="narrative"
16:
m="ferrous sulfate" 111:15 112:0
do="300 mg" 112:1 112:2
mo="p.o." 112:3 112:3
f="q.d." 112:4 112:4
du="nm"
r="nm"
ln="list"
17:
m="vitamin c" 111:5 111:6
do="500 mg" 111:7 111:8
mo="p.o." 111:9 111:9
f="q.d." 111:10 111:10
du="nm"
r="nm"
ln="list"
18:
m="insulin lente" 112:9 112:10
do="30 u" 113:1 113:2
mo="subcutaneous" 113:0 113:0
f="q.h.s." 113:3 113:3
du="nm"
r="nm"
ln="list"
19:
m="insulin regular" 113:8 113:9
do="30 u" 113:11 113:12
mo="subcutaneous" 113:10 113:10
f="q.h.s." 114:0 114:0
du="nm"
r="nm"
ln="list"
20:
m="synthroid" 114:5 114:5
do="200 mcg" 114:6 114:7
mo="p.o." 114:8 114:8
f="q.d." 114:9 114:9
du="nm"
r="nm"
ln="list"
21:
m="zaroxolyn" 114:14 114:14
do="5 mg" 114:15 114:16
mo="p.o." 114:17 114:17
f="q.a.m." 115:0 115:0
du="nm"
r="nm"
ln="list"
22:
m="tamoxifen" 115:5 115:5
do="20 mg" 115:6 115:7
mo="p.o." 115:8 115:8
f="q.h.s." 115:9 115:9
du="nm"
r="nm"
ln="list"
23:
m="vitamin e" 115:14 115:15
do="400 u" 115:16 115:17
mo="p.o." 115:18 115:18
f="q.d." 116:0 116:0
du="nm"
r="nm"
ln="list"
24:
m="coumadin" 116:5 116:5
do="5 mg" 116:6 116:7
mo="p.o." 116:8 116:8
f="q.h.s." 116:9 116:9
du="nm"
r="nm"
ln="list"
25:
m="multivitamins" 116:14 116:14
do="1 tablet" 116:15 116:16
mo="p.o." 117:0 117:0
f="q.d." 117:1 117:1
du="nm"
r="nm"
ln="list"
26:
m="insulin 70/30" 117:15 117:16
do="35 u" 117:17 117:18
mo="subcu." 118:0 118:0
f="q.a.m." 118:1 118:1
du="nm"
r="nm"
ln="list"
27:
m="zocor" 117:6 117:6
do="40 mg" 117:7 117:8
mo="p.o." 117:9 117:9
f="q.h.s." 117:10 117:10
du="nm"
r="nm"
ln="list"
28:
m="neurontin" 118:6 118:6
do="100 mg" 118:12 118:13
mo="p.o." 118:14 118:14
f="at 2:00 p.m." 118:15 119:1
du="nm"
r="nm"
ln="list"
29:
m="neurontin" 118:6 118:6
do="300 mg" 118:7 118:8
mo="p.o." 118:9 118:9
f="q.a.m." 118:10 118:10
du="nm"
r="nm"
ln="list"
30:
m="neurontin" 118:6 118:6
do="300 mg" 119:3 119:4
mo="p.o." 119:5 119:5
f="q.h.s." 119:6 119:6
du="nm"
r="nm"
ln="list"
31:
m="serevent" 119:11 119:11
do="1 puff" 119:13 119:14
mo="inhaled" 119:12 119:12
f="b.i.d." 119:15 119:15
du="nm"
r="nm"
ln="list"
32:
m="torsemide" 120:3 120:3
do="100" 120:4 120:4
mo="p.o." 120:5 120:5
f="q.a.m." 120:6 120:6
du="nm"
r="nm"
ln="list"
33:
m="trusopt" 120:11 120:11
do="1 drop" 120:12 120:13
mo="nm"
f="b.i.d." 120:14 120:14
du="nm"
r="nm"
ln="list"
34:
m="flonase" 121:3 121:3
do="1-2 sprays" 121:5 121:6
mo="nasal" 121:4 121:4
f="b.i.d." 121:7 121:7
du="nm"
r="nm"
ln="list"
35:
m="xalatan" 121:12 121:12
do="1 drop" 121:13 121:14
mo="ocular." 121:15 121:15
f="q.h.s." 122:0 122:0
du="nm"
r="nm"
ln="list"
36:
m="celebrex" 122:14 122:14
do="100 mg" 122:15 122:16
mo="p.o." 123:0 123:0
f="b.i.d." 123:1 123:1
du="nm"
r="nm"
ln="list"
37:
m="pulmicort" 122:5 122:5
do="1 puff" 122:7 122:8
mo="inhaled" 122:6 122:6
f="b.i.d." 122:9 122:9
du="nm"
r="nm"
ln="list"
38:
m="avandia" 123:6 123:6
do="4 mg" 123:7 123:8
mo="p.o." 123:9 123:9
f="q.d." 123:10 123:10
du="nm"
r="nm"
ln="list"
39:
m="hyzaar 12.5 mg/50 mg" 123:15 123:18
do="1 tablet" 124:0 124:1
mo="p.o." 124:2 124:2
f="q.d." 124:3 124:3
du="nm"
r="nm"
ln="list"
40:
m="nexium" 124:8 124:8
do="20 mg" 124:9 124:10
mo="p.o." 124:11 124:11
f="q.d." 124:12 124:12
du="nm"
r="nm"
ln="list"
41:
m="potassium chloride" 124:17 125:0
do="20 meq" 125:1 125:2
mo="p.o." 125:3 125:3
f="b.i.d." 125:4 125:4
du="nm"
r="nm"
ln="list"
42:
m="suprax" 125:9 125:9
do="400 mg" 125:10 125:11
mo="p.o." 125:12 125:12
f="q.d." 125:13 125:13
du="x4 days" 125:14 125:15
r="nm"
ln="list"
43:
m="albuterol" 126:3 126:3
do="2 puffs" 126:5 126:6
mo="inhaled" 126:4 126:4
f="q.i.d. p.r.n." 126:7 126:8
du="nm"
r="wheezing" 126:9 126:9
ln="list"
44:
m="miconazole 2% powder" 127:3 127:5
do="nm"
mo="topically" 127:7 127:7
f="b.i.d." 127:10 127:10
du="nm"
r="itching." 128:0 128:0
ln="list"
