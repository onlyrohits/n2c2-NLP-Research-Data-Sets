1:
m="decadron" 17:10 17:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="flexeril" 18:2 18:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="motrin" 18:0 18:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="percocet" 71:11 71:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="colace" 82:5 82:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="flexeril" 83:2 83:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="klonopin" 83:0 83:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="percocet" 83:4 83:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
