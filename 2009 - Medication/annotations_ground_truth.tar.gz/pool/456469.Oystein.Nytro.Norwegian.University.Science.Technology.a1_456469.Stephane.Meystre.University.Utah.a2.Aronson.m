1:
m="keflex" 23:8 23:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="toprol" 28:10 28:10
do="150 mg" 29:2 29:3
mo="p.o." 29:4 29:4
f="daily" 29:5 29:5
du="nm"
r="blood pressure" 31:3 31:4
ln="narrative"
3:
m="magnesium" 29:12 29:12
do="2 mg" 29:9 29:10
mo="nm"
f="nm"
du="nm"
r="sinus rhythm...hypertensive...frequent PVCs" 30:6 30:7,31:6 31:6,32:1 32:2
ln="narrative"
4:
m="keflex" 40:5 40:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="left lower extremity erythema" 38:8 39:2
ln="narrative"
5:
m="keflex" 82:10 82:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="left lower extremity erythema" 83:0 83:3
ln="narrative"
6:
m="lasix" 84:9 84:9
do="low dose" 84:7 84:8
mo="nm"
f="nm"
du="one week" 83:8 84:0
r="mild persistent postoperative pulmonary effusions" 84:11 85:2
ln="narrative"
7:
m="medication" 94:3 94:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="tylenol" 100:5 100:5
do="325 mg" 100:6 100:7
mo="p.o." 101:0 101:0
f="q.6h. p.r.n." 101:1 101:2
du="nm"
r="pain" 101:3 101:3
ln="list"
9:
m="tylenol" 100:5 100:5
do="325 mg" 100:6 100:7
mo="p.o." 101:0 101:0
f="q.6h. p.r.n." 101:1 101:2
du="nm"
r="temperature" 101:5 101:5
ln="list"
10:
m="amlodipine" 102:2 102:2
do="5 mg" 102:3 102:4
mo="p.o." 102:5 102:5
f="daily" 102:6 102:6
du="nm"
r="nm"
ln="list"
11:
m="atorvastatin" 102:8 102:8
do="10 mg" 102:9 102:10
mo="p.o." 102:11 102:11
f="daily" 103:0 103:0
du="nm"
r="nm"
ln="list"
12:
m="captopril" 103:2 103:2
do="6.25 mg" 103:3 103:4
mo="p.o." 103:5 103:5
f="t.i.d." 103:6 103:6
du="nm"
r="nm"
ln="list"
13:
m="keflex" 103:8 103:8
do="500 mg" 103:9 103:10
mo="p.o." 103:11 103:11
f="q.i.d." 103:12 103:12
du="times total of seven days" 104:0 104:4
r="nm"
ln="list"
14:
m="colace" 104:11 104:11
do="100 mg" 104:12 104:13
mo="p.o." 105:0 105:0
f="b.i.d. p.r.n." 105:1 105:2
du="nm"
r="constipation" 105:3 105:3
ln="list"
15:
m="enteric-coated aspirin" 105:5 105:6
do="325 mg" 105:7 105:8
mo="p.o." 106:0 106:0
f="daily" 106:1 106:1
du="nm"
r="nm"
ln="list"
16:
m="hydrochlorothiazide" 106:11 106:11
do="12.5 mg" 107:0 107:1
mo="p.o." 107:2 107:2
f="daily" 107:3 107:3
du="nm"
r="nm"
ln="list"
17:
m="lasix" 106:3 106:3
do="40 mg" 106:4 106:5
mo="p.o." 106:6 106:6
f="daily" 106:7 106:7
du="x7 days" 106:8 106:9
r="nm"
ln="list"
18:
m="lantus" 107:11 107:11
do="24 units" 107:12 107:13
mo="subcu" 108:0 108:0
f="q. 10 p.m." 108:1 108:3
du="nm"
r="nm"
ln="list"
19:
m="novolog" 107:5 107:5
do="3 units" 107:6 107:7
mo="subcu" 107:8 107:8
f="ac" 107:9 107:9
du="nm"
r="nm"
ln="list"
20:
m="potassium slow release" 108:9 108:11
do="20 meq" 108:12 108:13
mo="p.o." 109:0 109:0
f="daily" 109:1 109:1
du="x7 days" 109:2 109:3
r="nm"
ln="list"
21:
m="niferex" 109:11 109:11
do="150 mg" 109:12 109:13
mo="p.o." 110:0 110:0
f="b.i.d." 110:1 110:1
du="nm"
r="nm"
ln="list"
22:
m="toprol-xl" 109:5 109:5
do="150 mg" 109:6 109:7
mo="p.o." 109:8 109:8
f="daily" 109:9 109:9
du="nm"
r="nm"
ln="list"
23:
m="ambien" 110:13 110:13
do="5 mg" 111:0 111:1
mo="p.o." 111:2 111:2
f="nightly p.r.n." 111:3 111:4
du="nm"
r="insomnia" 111:5 111:5
ln="list"
24:
m="oxycodone" 110:3 110:3
do="5 to 10 mg" 110:4 110:7
mo="p.o." 110:8 110:8
f="q.4h. p.r.n." 110:9 110:10
du="nm"
r="pain" 110:11 110:11
ln="list"
25:
m="novolog" 111:7 111:7
do="6 units" 111:8 111:9
mo="subcu" 111:10 111:10
f="with breakfast" 111:11 112:0
du="nm"
r="nm"
ln="list"
26:
m="novolog" 112:6 112:6
do="4 units" 112:7 112:8
mo="subcu" 112:9 112:9
f="with lunch" 112:10 112:11
du="nm"
r="nm"
ln="list"
27:
m="novolog" 113:3 113:3
do="4 units" 113:4 113:5
mo="subcu" 113:6 113:6
f="with dinner" 113:7 113:8
du="nm"
r="nm"
ln="list"
28:
m="novolog" 114:0 114:0
do="0 units" 114:13 115:0
mo="subcu" 115:1 115:1
f="nm"
du="nm"
r="blood sugar" 114:6 114:7
ln="list"
29:
m="novolog" 114:0 114:0
do="10 units" 119:3 119:4
mo="subcu" 119:5 119:5
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="novolog" 114:0 114:0
do="2 units" 115:10 115:11
mo="subcu" 115:12 115:12
f="nm"
du="nm"
r="blood sugar" 115:3 115:4
ln="list"
31:
m="novolog" 114:0 114:0
do="3 units" 116:6 116:7
mo="subcu" 116:8 116:8
f="nm"
du="nm"
r="blood sugar" 115:14 116:0
ln="list"
32:
m="novolog" 114:0 114:0
do="4 units" 117:1 117:2
mo="subcu" 117:3 117:3
f="nm"
du="nm"
r="blood sugar" 116:10 116:11
ln="list"
33:
m="novolog" 114:0 114:0
do="6 units" 117:12 117:13
mo="subcu" 117:14 117:14
f="nm"
du="nm"
r="blood sugar" 117:5 117:6
ln="list"
34:
m="novolog" 114:0 114:0
do="8 units" 118:7 118:8
mo="subcu" 118:9 118:9
f="nm"
du="nm"
r="blood sugar" 118:0 118:1
ln="list"
35:
m="novolog" 114:0 114:0
do="sliding scale" 114:1 114:2
mo="subcu" 114:3 114:3
f="ac" 114:4 114:4
du="nm"
r="nm"
ln="list"
36:
m="novolog" 120:3 120:3
do="sliding scale" 120:4 120:5
mo="subcu" 120:6 120:6
f="q.h.s." 120:7 120:7
du="nm"
r="nm"
ln="list"
37:
m="novolog" 121:6 121:6
do="0 units" 122:7 122:8
mo="subcu" 122:9 122:9
f="at bedtime" 121:7 121:8
du="nm"
r="nm"
ln="list"
38:
m="novolog" 121:6 121:6
do="2 units" 123:4 123:5
mo="subcu" 123:6 123:6
f="at bedtime" 121:7 121:8
du="nm"
r="nm"
ln="list"
39:
m="novolog" 121:6 121:6
do="3 units" 123:15 123:16
mo="subcu" 124:0 124:0
f="at bedtime" 121:7 121:8
du="nm"
r="nm"
ln="list"
40:
m="novolog" 121:6 121:6
do="4 units" 124:9 124:10
mo="subcu" 124:11 124:11
f="at bedtime" 121:7 121:8
du="nm"
r="nm"
ln="list"
41:
m="novolog" 121:6 121:6
do="nm"
mo="subcu" 122:9 122:9
f="at bedtime" 121:7 121:8
du="nm"
r="nm"
ln="list"
