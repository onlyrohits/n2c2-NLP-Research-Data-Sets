1:
m="coumadin" 21:6 21:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="pulmonary embolism" 19:9 20:0
ln="narrative"
2:
m="coumadin" 21:8 21:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="pulmonary embolism" 19:9 20:0
ln="narrative"
3:
m="metformin" 23:0 23:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="her diabetes mellitus" 23:2 23:4
ln="narrative"
4:
m="this medication" 23:5 23:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="lipitor" 42:1 42:1
do="10 mg" 42:2 42:3
mo="nm"
f="once a day." 42:4 42:6
du="nm"
r="nm"
ln="list"
6:
m="metformin" 43:1 43:1
do="100 mg" 43:8 43:9
mo="nm"
f="in the afternoon." 43:10 43:12
du="nm"
r="nm"
ln="list"
7:
m="metformin" 43:1 43:1
do="500 mg" 43:2 43:3
mo="nm"
f="in the morning" 43:4 43:6
du="nm"
r="nm"
ln="list"
8:
m="coumadin" 44:1 44:1
do="11 mg." 44:2 44:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="tylenol" 45:1 45:1
do="nm"
mo="nm"
f="p.r.n." 45:2 45:2
du="nm"
r="joint pain." 45:4 45:5
ln="list"
10:
m="coumadin" 61:8 61:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="coumadin" 63:3 63:3
do="11 mg" 64:3 64:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="heparin." 63:1 63:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="metformin" 69:0 69:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus" 68:6 68:7
ln="narrative"
14:
m="regular insulin" 70:7 70:8
do="sliding scale." 70:9 70:10
mo="nm"
f="nm"
du="during her hospital course" 69:9 70:1
r="nm"
ln="narrative"
15:
m="metformin" 71:1 71:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="miconazole suppository" 73:8 74:0
do="nm"
mo="nm"
f="nm"
du="for five days." 74:3 74:5
r="white creamy discharge from her vagina" 72:8 73:4
ln="narrative"
17:
m="duoneb" 82:1 82:1
do="3/0.5 mg" 82:2 82:3
mo="nm"
f="q.6h." 82:4 82:4
du="nm"
r="nm"
ln="list"
18:
m="coumadin" 83:1 83:1
do="12 mg" 83:2 83:3
mo="p.o." 83:4 83:4
f="nightly." 83:5 83:5
du="nm"
r="nm"
ln="list"
19:
m="lipitor" 84:1 84:1
do="10 mg" 84:2 84:3
mo="p.o." 84:4 84:4
f="once a day." 84:5 84:7
du="nm"
r="nm"
ln="list"
20:
m="metformin" 85:1 85:1
do="1000 mg" 85:9 85:10
mo="p.o." 85:2 85:2
f="in the afternoon." 85:11 86:0
du="nm"
r="nm"
ln="list"
21:
m="metformin" 85:1 85:1
do="500 mg" 85:3 85:4
mo="p.o." 85:2 85:2
f="in the morning" 85:5 85:7
du="nm"
r="nm"
ln="list"
22:
m="colace" 87:1 87:1
do="100 mg" 87:2 87:3
mo="p.o." 87:7 87:7
f="twice a day" 87:4 87:6
du="nm"
r="nm"
ln="list"
23:
m="dilaudid" 88:1 88:1
do="2-4 mg" 88:2 88:3
mo="p.o." 88:5 88:5
f="q.3h." 88:4 88:4
du="nm"
r="nm"
ln="list"
