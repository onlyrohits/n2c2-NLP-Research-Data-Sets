1:
m="duoneb ( albuterol and ipratropium nebulizer )" 19:0 19:6
do="3/0.5 mg" 20:0 20:1
mo="inh" 20:2 20:2
f="q6h " 20:3 20:3
du="nm"
r="nm"
ln="list"
2:
m="allopurinol" 21:0 21:0
do="100 mg" 21:1 21:2
mo="po" 21:3 21:3
f="daily" 21:4 21:4
du="nm"
r="nm"
ln="list"
3:
m="amoxicillin" 22:0 22:0
do="250 mg" 22:1 22:2
mo="po" 22:3 22:3
f="tid" 22:4 22:4
du="x 9 doses" 22:5 22:7
r="nm"
ln="list"
4:
m="enteric coated aspirin ( aspirin enteric coated )" 25:0 25:7
do="81 mg" 26:0 26:1
mo="po" 26:2 26:2
f="daily" 26:3 26:3
du="nm"
r="nm"
ln="list"
5:
m="atenolol" 27:0 27:0
do="25 mg" 27:1 27:2
mo="po" 27:3 27:3
f="daily" 27:4 27:4
du="nm"
r="nm"
ln="list"
6:
m="pulmicort turbuhaler ( budesonide oral inhaler )" 28:0 28:6
do="1 puff" 29:0 29:1
mo="inh" 29:2 29:2
f="bid" 29:3 29:3
du="nm"
r="nm"
ln="list"
7:
m="lasix ( furosemide )" 30:0 30:3
do="40 mg" 30:4 30:5
mo="po" 30:6 30:6
f="daily" 30:7 30:7
du="nm"
r="nm"
ln="list"
8:
m="lasix" 32:17 32:17
do="nm"
mo="po" 32:18 32:18
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="reglan ( metoclopramide hcl )" 35:0 35:4
do="10 mg" 35:5 35:6
mo="po" 35:7 35:7
f="qid" 35:8 35:8
du="nm"
r="nm"
ln="list"
10:
m="ranitidine hcl" 36:0 36:1
do="150 mg" 36:2 36:3
mo="po" 36:4 36:4
f="daily" 36:5 36:5
du="nm"
r="nm"
ln="list"
11:
m="senna tablets ( sennosides )" 37:0 37:4
do="2 tab" 37:5 37:6
mo="po" 37:7 37:7
f="bid prn" 37:8 37:9
du="nm"
r="constipation" 37:10 37:10
ln="list"
12:
m="zocor ( simvastatin )" 38:0 38:3
do="40 mg" 38:4 38:5
mo="po" 38:6 38:6
f="bedtime" 38:7 38:7
du="nm"
r="nm"
ln="list"
13:
m="multivitamin" 43:3 43:3
do="nm"
mo="po" 43:5 43:5
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="niacin" 45:5 45:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="simvastatin" 45:3 45:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="vit. b-3" 46:0 46:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="multivitamin therapeutic ( therapeutic multivi... )" 47:0 47:5
do="1 tab" 48:0 48:1
mo="po" 48:2 48:2
f="daily" 48:3 48:3
du="nm"
r="nm"
ln="list"
18:
m="niacin" 51:5 51:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="simvastatin" 51:3 51:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="vit. b-3" 52:0 52:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="dobutamine" 83:1 83:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="amox" 97:13 97:13
do="nm"
mo="nm"
f="nm"
du="for 3 days." 98:5 98:7
r="uti" 97:2 97:2
ln="narrative"
23:
m="reglan." 97:0 97:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nausea" 96:8 96:8
ln="narrative"
24:
m="amoxicillin" 99:5 99:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="home medicines" 99:1 99:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="reglan" 99:7 99:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
