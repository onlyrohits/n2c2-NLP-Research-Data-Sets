1:
m="nitroglycerins" 25:0 25:0
do="two" 24:8 24:8
mo="nm"
f="per week" 25:1 25:2
du="nm"
r="nm"
ln="narrative"
2:
m="nitroglycerin" 26:4 26:4
do="one" 26:3 26:3
mo="nm"
f="per day." 26:5 26:6
du="nm"
r="escalating chest pain" 25:10 26:1
ln="narrative"
3:
m="nitroglycerin." 27:4 27:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 26:8 26:8
ln="narrative"
4:
m="amiodarone" 28:6 28:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="digoxin" 28:1 28:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="coumadin" 29:5 29:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="plavix" 29:0 29:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="nitroglycerins" 30:9 30:9
do="two" 30:8 30:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="enalapril" 32:6 32:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="lopressor" 32:4 32:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="lovenox" 32:8 32:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="plavix" 33:1 33:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="lasix" 59:4 59:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="morphine" 59:6 59:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="nitro" 60:3 60:3
do="nm"
mo="drip" 60:4 60:4
f="nm"
du="nm"
r="hypotensive respiratory distress" 58:1 58:3
ln="narrative"
16:
m="amiodarone" 66:5 66:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="beta-blocker" 68:9 68:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="ace inhibitor" 69:0 69:1
do="titrated" 69:3 69:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="digoxin." 76:5 76:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 75:8 76:0
ln="narrative"
20:
m="coumadin" 77:1 77:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="mucomyst" 81:0 81:0
do="nm"
mo="precath" 81:1 81:1
f="nm"
du="nm"
r="chronic renal insufficiency" 80:4 80:6
ln="narrative"
22:
m="flomax" 84:6 84:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="urinary retention" 83:8 83:9
ln="narrative"
23:
m="lantus" 88:7 88:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="metformin" 88:0 88:0
do="home dose" 87:9 87:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="insulin." 89:1 89:1
do="sliding scale" 88:9 89:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="packed red blood cells" 91:12 92:2
do="three units" 91:9 91:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="coumadin" 100:4 100:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="amiodarone" 107:1 107:1
do="200 mg" 107:2 107:3
mo="p.o." 107:4 107:4
f="daily." 107:5 107:5
du="nm"
r="nm"
ln="list"
29:
m="enteric-coated aspirin" 108:1 108:2
do="325 mg" 108:3 108:4
mo="p.o." 108:5 108:5
f="daily." 108:6 108:6
du="nm"
r="nm"
ln="list"
30:
m="librium" 109:1 109:1
do="10 mg" 109:2 109:3
mo="p.o." 109:4 109:4
f="b.i.d." 109:5 109:5
du="nm"
r="nm"
ln="list"
31:
m="colace" 110:1 110:1
do="200 mg" 110:2 110:3
mo="p.o." 110:4 110:4
f="b.i.d." 110:5 110:5
du="nm"
r="nm"
ln="list"
32:
m="ferrous gluconate" 111:1 111:2
do="324 mg" 111:3 111:4
mo="p.o." 111:5 111:5
f="t.i.d." 111:6 111:6
du="nm"
r="nm"
ln="list"
33:
m="lasix" 112:1 112:1
do="40 mg" 112:2 112:3
mo="p.o." 112:4 112:4
f="b.i.d." 112:5 112:5
du="nm"
r="nm"
ln="list"
34:
m="nitroglycerin" 113:1 113:1
do="one tab" 113:2 113:3
mo="p.o." 113:4 113:4
f="q.5 minutes p.r.n." 113:5 113:7
du="nm"
r="chest pain" 113:8 113:9
ln="list"
35:
m="dilantin" 114:1 114:1
do="100 mg" 114:2 114:3
mo="p.o." 114:4 114:4
f="b.i.d." 114:5 114:5
du="nm"
r="nm"
ln="list"
36:
m="senna" 115:1 115:1
do="two tabs" 115:2 115:3
mo="p.o." 115:4 115:4
f="b.i.d." 115:5 115:5
du="nm"
r="nm"
ln="list"
37:
m="coumadin" 116:1 116:1
do="3 mg" 116:2 116:3
mo="p.o." 116:4 116:4
f="q.p.m." 116:5 116:5
du="nm"
r="nm"
ln="list"
38:
m="lipitor" 117:1 117:1
do="80 mg" 117:2 117:3
mo="p.o." 117:4 117:4
f="daily." 117:5 117:5
du="nm"
r="nm"
ln="list"
39:
m="flomax" 118:1 118:1
do="0.4 mg" 118:2 118:3
mo="p.o." 118:4 118:4
f="daily." 118:5 118:5
du="nm"
r="nm"
ln="list"
40:
m="plavix" 119:1 119:1
do="75 mg" 119:2 119:3
mo="p.o." 119:4 119:4
f="daily." 119:5 119:5
du="nm"
r="nm"
ln="list"
41:
m="lantus" 120:1 120:1
do="14 units" 120:2 120:3
mo="subcutaneous" 120:4 120:4
f="at nighttime." 120:5 120:6
du="nm"
r="nm"
ln="list"
42:
m="metformin" 121:1 121:1
do="500 mg" 121:2 121:3
mo="p.o." 121:4 121:4
f="b.i.d." 121:5 121:5
du="nm"
r="nm"
ln="list"
43:
m="ranitidine" 122:1 122:1
do="150 mg" 122:2 122:3
mo="nm"
f="b.i.d." 122:4 122:4
du="nm"
r="nm"
ln="list"
44:
m="digoxin" 123:1 123:1
do="0.125 mg" 123:2 123:3
mo="p.o." 123:4 123:4
f="daily." 123:5 123:5
du="nm"
r="nm"
ln="list"
45:
m="enalapril" 124:1 124:1
do="10 mg" 124:2 124:3
mo="p.o." 124:4 124:4
f="daily." 124:5 124:5
du="nm"
r="nm"
ln="list"
46:
m="atenolol" 125:1 125:1
do="50 mg" 125:2 125:3
mo="p.o." 125:4 125:4
f="b.i.d." 125:5 125:5
du="nm"
r="nm"
ln="list"
47:
m="coumadin" 131:5 131:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
