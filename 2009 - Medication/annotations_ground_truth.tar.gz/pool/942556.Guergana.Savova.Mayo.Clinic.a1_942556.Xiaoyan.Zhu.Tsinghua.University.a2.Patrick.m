1:
m="enteric coated asa" 19:0 19:2
do="325 mg" 19:3 19:4
mo="po" 19:5 19:5
f="daily" 19:6 19:6
du="nm"
r="nm"
ln="list"
2:
m="tessalon perles ( benzonatate )" 20:0 20:4
do="100 mg" 20:5 20:6
mo="po" 20:7 20:7
f="tid prn" 20:8 21:0
du="number of doses required (approximate): 6" 22:0 22:7
r="shortness of breath" 21:1 21:3
ln="list"
3:
m="plavix ( clopidogrel )" 23:0 23:3
do="75 mg" 23:4 23:5
mo="po" 23:6 23:6
f="daily" 23:7 23:7
du="nm"
r="nm"
ln="list"
4:
m="codeine phosphate" 25:0 25:1
do="15 mg" 25:2 25:3
mo="po" 25:4 25:4
f="q3h prn" 25:5 25:6
du="nm"
r="pain" 25:7 25:7
ln="list"
5:
m="dextromethorphan hbr" 27:0 27:1
do="10 mg" 27:2 27:3
mo="po" 27:4 27:4
f="q6h prn" 27:5 27:6
du="nm"
r="other:cough" 27:7 27:7
ln="list"
6:
m="zetia ( ezetimibe )" 30:0 30:3
do="10 mg" 30:4 30:5
mo="po" 30:6 30:6
f="daily" 30:7 30:7
du="nm"
r="nm"
ln="list"
7:
m="lantus ( insulin glargine )" 31:0 31:4
do="20 units" 31:5 31:6
mo="sc" 31:7 31:7
f="bedtime" 31:8 31:8
du="nm"
r="nm"
ln="list"
8:
m="potassium chloride immed. rel. ( kcl immediate... )" 33:0 33:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="kcl" 35:9 35:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="kcl immediate release" 35:1 35:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="potassium chloride" 39:3 39:4
do="20 meq" 39:7 39:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="kcl" 50:8 50:8
do="20 meq" 51:2 52:0
mo="orally" 52:1 52:1
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="kcl" 50:8 50:8
do="40 meq" 50:9 50:10
mo="orally" 50:11 50:11
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="kcl" 54:8 54:8
do="40 meq" 54:9 54:10
mo="orally" 54:11 54:11
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="kcl" 56:8 56:8
do="20 meq" 56:9 56:10
mo="orally" 56:11 56:11
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="kcl" 58:10 58:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="diovan" 65:3 65:3
do="nm"
mo="po" 65:4 65:4
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="potassium chloride" 66:3 66:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="valsartan" 67:0 67:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="maalox-tablets quick dissolve/chewable" 68:0 68:2
do="1-2 tab" 68:3 68:4
mo="po" 68:5 68:5
f="q6h prn" 68:6 69:0
du="nm"
r="upset stomach" 69:1 69:2
ln="list"
21:
m="magnesium gluconate" 70:0 70:1
do="sliding scale" 70:2 70:3
mo="po ( orally )" 70:4 70:7
f="daily" 70:8 70:8
du="nm"
r="nm"
ln="list"
22:
m="magnesium" 71:6 71:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="mg gluconate" 77:12 77:13
do="3 gm" 77:10 77:11
mo="orally" 78:0 78:0
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="mg gluconate" 79:10 79:11
do="2 gm" 79:8 79:9
mo="orally" 79:12 79:12
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="mg gluconate" 80:10 80:11
do="1 gm" 80:8 80:9
mo="orally" 80:12 80:12
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="nitroglycerin 1/150 ( 0.4 mg )" 83:0 83:5
do="1 tab" 83:6 83:7
mo="sl" 83:8 83:8
f="q5min" 83:9 83:9
du="x 3" 83:10 83:11
r="chest pain" 84:1 84:2
ln="list"
27:
m="oxycodone" 85:0 85:0
do="5-10 mg" 85:1 85:2
mo="po" 85:3 85:3
f="q6h prn" 85:4 85:5
du="nm"
r="pain" 85:6 85:6
ln="list"
28:
m="pindolol" 86:0 86:0
do="5 mg" 86:1 86:2
mo="po" 86:3 86:3
f="bid" 86:4 86:4
du="nm"
r="nm"
ln="list"
29:
m="zocor ( simvastatin )" 89:0 89:3
do="80 mg" 89:4 89:5
mo="po" 89:6 89:6
f="bedtime" 89:7 89:7
du="nm"
r="nm"
ln="list"
30:
m="diovan ( valsartan )" 92:0 92:3
do="160 mg" 92:4 92:5
mo="po" 92:6 92:6
f="daily" 92:7 92:7
du="nm"
r="nm"
ln="list"
31:
m="potassium chloride" 96:3 96:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="valsartan" 97:0 97:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="estradiol 0.05" 138:3 138:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="lantus" 138:0 138:0
do="40u" 138:1 138:1
mo="nm"
f="qd" 138:2 138:2
du="nm"
r="nm"
ln="list"
35:
m="diltiazem" 139:0 139:0
do="180 mg" 139:1 139:2
mo="nm"
f="qd" 139:3 139:3
du="nm"
r="nm"
ln="list"
36:
m="hctz" 139:4 139:4
do="25 mg" 139:5 139:6
mo="nm"
f="qd" 140:0 140:0
du="nm"
r="nm"
ln="list"
37:
m="zetia" 140:1 140:1
do="10mg" 140:2 140:2
mo="nm"
f="qd" 141:0 141:0
du="nm"
r="nm"
ln="list"
38:
m="diovan" 141:1 141:1
do="160 mg" 141:2 141:3
mo="nm"
f="qd" 142:0 142:0
du="nm"
r="nm"
ln="list"
39:
m="plavix" 142:1 142:1
do="75 mg" 142:2 142:3
mo="nm"
f="qd" 143:0 143:0
du="nm"
r="nm"
ln="list"
40:
m="zocor" 143:1 143:1
do="80 mg" 143:2 143:3
mo="nm"
f="qd" 144:0 144:0
du="nm"
r="nm"
ln="list"
41:
m="asa" 144:1 144:1
do="325 mg" 144:2 144:3
mo="nm"
f="qd" 145:0 145:0
du="nm"
r="nm"
ln="list"
42:
m="asa" 146:3 146:3
do="325 mg" 146:4 146:5
mo="nm"
f="qd" 146:6 146:6
du="nm"
r="nm"
ln="list"
43:
m="lantus" 147:0 147:0
do="20u" 147:1 147:1
mo="nm"
f="qd" 147:2 147:2
du="nm"
r="nm"
ln="list"
44:
m="plavix" 147:3 147:3
do="75 mg" 147:4 147:5
mo="nm"
f="qd" 148:0 148:0
du="nm"
r="nm"
ln="list"
45:
m="zetia" 148:1 148:1
do="10mg" 148:2 148:2
mo="nm"
f="qd" 149:0 149:0
du="nm"
r="nm"
ln="list"
46:
m="famotidine" 149:1 149:1
do="20 mg" 149:2 149:3
mo="nm"
f="bid" 150:0 150:0
du="nm"
r="nm"
ln="list"
47:
m="pindolol" 150:1 150:1
do="5 mg" 150:2 150:3
mo="nm"
f="bid" 151:0 151:0
du="nm"
r="nm"
ln="list"
48:
m="lovenox" 151:1 151:1
do="40" 151:2 151:2
mo="sc" 151:3 151:3
f="qd" 152:0 152:0
du="nm"
r="nm"
ln="list"
49:
m="nicotine patch" 152:1 153:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
50:
m="mgso4" 153:1 153:1
do="ss" 154:0 154:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
51:
m="kcl" 154:1 154:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
52:
m="novolog" 155:0 155:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
53:
m="plavix" 186:8 186:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="zetia" 186:12 186:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="zocor" 186:10 186:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="heparin" 187:3 187:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="lantus" 195:5 195:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
58:
m="novolog" 195:7 195:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="insulin." 197:0 197:0
do="home doses" 196:10 196:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
60:
m="anticoagulation" 199:4 199:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="asa" 200:4 200:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="plavix" 200:2 200:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
