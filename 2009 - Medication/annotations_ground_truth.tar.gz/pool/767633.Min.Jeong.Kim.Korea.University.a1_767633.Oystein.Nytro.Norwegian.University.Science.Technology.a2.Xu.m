1:
m="calcium carbonate" 16:0 16:1
do="1 , 500 mg ( 600 mg elem ca )/" 16:2 16:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
2:
m="vit d" 16:12 16:13
do="200 iu 1 tab" 16:14 17:1
mo="po" 17:2 17:2
f="bid" 17:3 17:3
du="nm"
r="nm"
ln="list"
3:
m="acetylsalicylic acid" 18:0 18:1
do="81 mg" 18:2 18:3
mo="po" 18:4 18:4
f="daily" 18:5 18:5
du="nm"
r="nm"
ln="list"
4:
m="calcitriol" 19:0 19:0
do="0.5 mcg" 19:1 19:2
mo="po" 19:3 19:3
f="daily" 19:4 19:4
du="nm"
r="nm"
ln="list"
5:
m="phoslo ( calcium acetate ( 1 gelcap=667 mg ) )" 20:0 20:9
do="1 , 334 mg" 21:0 21:3
mo="po" 21:4 21:4
f="tid" 21:5 21:5
du="number of doses required ( approximate ): 4" 22:0 22:7
r="nm"
ln="list"
6:
m="nexium ( esomeprazole )" 23:0 23:3
do="40 mg" 23:4 23:5
mo="po" 23:6 23:6
f="daily" 23:7 23:7
du="nm"
r="nm"
ln="list"
7:
m="lasix ( furosemide )" 24:0 24:3
do="40 mg" 24:4 24:5
mo="po" 24:6 24:6
f="daily" 24:7 24:7
du="nm"
r="nm"
ln="list"
8:
m="toprol xl ( metoprolol succinate extended release )" 25:0 25:7
do="25 mg" 26:0 26:1
mo="po" 26:2 26:2
f="daily...with meals" 26:3 26:3,27:2 27:3
du="nm"
r="nm"
ln="list"
9:
m="nephrocaps ( nephro-vit rx )" 29:0 29:4
do="1 tab" 29:5 29:6
mo="po" 29:7 29:7
f="daily" 29:8 29:8
du="nm"
r="nm"
ln="list"
10:
m="simvastatin" 31:3 31:3
do="nm"
mo="po" 31:4 31:4
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="niacin" 32:3 32:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="vit. b-3" 32:5 32:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="simvastatin" 33:0 33:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="simvastatin" 34:0 34:0
do="10 mg" 34:1 34:2
mo="po" 34:3 34:3
f="bedtime" 34:4 34:4
du="nm"
r="nm"
ln="list"
15:
m="niacin" 38:3 38:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="vit. b-3" 38:5 38:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="simvastatin" 39:0 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="niacin" 40:3 40:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="vit. b-3" 40:5 40:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="simvastatin" 41:0 41:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="tylenol" 80:12 80:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 80:2 80:2
ln="narrative"
22:
m="aspirin" 130:0 130:0
do="81 mg" 130:1 130:2
mo="po" 130:3 130:3
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="qdcalcitriol" 130:4 130:4
do="0.5mcg" 130:5 130:5
mo="po" 130:6 130:6
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="qdcalcium carbonate" 130:7 130:8
do="500mg" 130:9 130:9
mo="po" 130:10 130:10
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="nephrocaps" 131:7 131:7
do="1 tab" 131:8 131:9
mo="po" 131:10 131:10
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="tidlasix" 131:0 131:0
do="40 mg" 131:1 131:2
mo="po" 131:3 131:3
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="hrs.toprol xl" 132:6 132:7
do="25 mg" 133:0 133:1
mo="po" 133:2 133:2
f="qdzocor" 133:3 133:3
du="nm"
r="nm"
ln="list"
28:
m="transdermal" 132:1 132:1
do="0.2mg/hr" 132:3 132:3
mo="patch" 132:2 132:2
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="qdzocor" 133:3 133:3
do="10mg" 133:4 133:4
mo="po" 133:5 133:5
f="qhs" 133:6 133:6
du="nm"
r="nm"
ln="list"
30:
m="vitamin supplements" 189:10 190:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="nephrocaps." 190:3 190:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="phosphate" 190:4 190:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="calcitriol" 193:8 193:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic hypocalcemia" 193:0 193:1
ln="narrative"
34:
m="nephrocaps." 203:6 203:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="nutritional supplements/boost." 203:4 203:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="heparin" 208:1 208:1
do="nm"
mo="nm"
f="tid." 208:2 208:2
du="nm"
r="esophagitis" 208:7 208:7
ln="narrative"
37:
m="nexium" 208:3 208:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="esophagitis." 208:7 208:7
ln="narrative"
