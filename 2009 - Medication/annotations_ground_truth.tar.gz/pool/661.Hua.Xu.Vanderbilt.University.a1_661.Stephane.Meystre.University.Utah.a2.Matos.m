1:
m="acetylsalicylic acid" 16:0 16:1
do="325 mg" 16:2 16:3
mo="po" 16:4 16:4
f="qd" 16:5 16:5
du="nm"
r="nm"
ln="list"
2:
m="colace ( docusate sodium )" 17:0 17:4
do="100 mg" 17:5 17:6
mo="po" 17:7 17:7
f="bid" 17:8 17:8
du="nm"
r="nm"
ln="list"
3:
m="enalapril maleate" 18:0 18:1
do="10 mg" 18:2 18:3
mo="po" 18:4 18:4
f="bid" 18:5 18:5
du="nm"
r="nm"
ln="list"
4:
m="nph humulin insulin ( insulin nph human )" 33:0 33:7
do="2 units" 34:0 34:1
mo="nm"
f="qam;" 34:2 34:2
du="nm"
r="nm"
ln="list"
5:
m="nph humulin insulin ( insulin nph human )" 33:0 33:7
do="2 units" 34:7 34:8
mo="nm"
f="qam" 34:9 34:9
du="nm"
r="nm"
ln="list"
6:
m="nph humulin insulin ( insulin nph human )" 33:0 33:7
do="3 units" 34:10 34:11
mo="nm"
f="qpm" 34:12 34:12
du="nm"
r="nm"
ln="list"
7:
m="nph humulin insulin ( insulin nph human )" 33:0 33:7
do="3 units" 34:3 34:4
mo="sc" 34:6 34:6
f="qpm" 34:5 34:5
du="nm"
r="nm"
ln="list"
8:
m="ntg 1/150 ( nitroglycerin 1/150 ( 0.4 mg ) )" 35:0 35:9
do="1 tab" 36:0 36:1
mo="sl" 36:2 36:2
f="q5min x 3 prn" 36:3 36:6
du="nm"
r="chest pain" 36:7 36:8
ln="list"
9:
m="zocor ( simvastatin )" 37:0 37:3
do="40 mg" 37:4 37:5
mo="po" 37:6 37:6
f="qhs" 37:7 37:7
du="nm"
r="nm"
ln="list"
10:
m="nephrocaps" 42:3 42:3
do="nm"
mo="po" 42:4 42:4
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="niacin" 43:5 43:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="simvastatin" 43:3 43:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="vit. b-3" 44:0 44:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="imdur ( isosorbide mononit.( sr ) )" 49:0 49:6
do="30 mg" 49:7 49:8
mo="po" 49:9 49:9
f="qd" 49:10 49:10
du="nm"
r="nm"
ln="list"
15:
m="nephrocaps ( nephro-vit rx )" 53:0 53:4
do="2 tab" 53:5 53:6
mo="po" 53:7 53:7
f="qd" 53:8 53:8
du="nm"
r="nm"
ln="list"
16:
m="niacin" 56:5 56:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="simvastatin" 56:3 56:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="vit. b-3" 57:0 57:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="nexium ( esomeprazole )" 58:0 58:3
do="20 mg" 58:4 58:5
mo="po" 58:6 58:6
f="qd" 58:7 58:7
du="nm"
r="nm"
ln="list"
20:
m="toprol xl ( metoprolol ( sust. rel. ) )" 59:0 59:8
do="200 mg" 59:9 59:10
mo="po" 59:11 59:11
f="qhs" 59:12 59:12
du="nm"
r="nm"
ln="list"
21:
m="persantine" 83:0 83:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="abx" 92:7 92:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="ns" 94:0 94:0
do="1 liter" 93:11 93:12
mo="nm"
f="nm"
du="nm"
r="his bp" 94:4 94:5
ln="narrative"
24:
m="asa" 115:8 115:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nstemi:" 115:3 115:3
ln="narrative"
25:
m="beta blocker" 115:10 116:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nstemi:" 115:3 115:3
ln="narrative"
26:
m="imdur" 116:2 116:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nstemi:" 115:3 115:3
ln="narrative"
27:
m="ntg" 116:6 116:6
do="nm"
mo="nm"
f="prn." 116:7 116:7
du="nm"
r="nstemi:" 115:3 115:3
ln="narrative"
28:
m="zocor" 116:4 116:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nstemi:" 115:3 115:3
ln="narrative"
29:
m="enalapril" 130:7 130:7
do="10mg" 130:9 130:9
mo="nm"
f="bid" 130:10 130:10
du="nm"
r="nm"
ln="narrative"
30:
m="renal meds." 135:6 135:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="home nexium" 141:7 141:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="heparin" 142:3 142:3
do="nm"
mo="sq" 142:2 142:2
f="nm"
du="nm"
r="dvt prophylaxis" 142:7 142:8
ln="list"
