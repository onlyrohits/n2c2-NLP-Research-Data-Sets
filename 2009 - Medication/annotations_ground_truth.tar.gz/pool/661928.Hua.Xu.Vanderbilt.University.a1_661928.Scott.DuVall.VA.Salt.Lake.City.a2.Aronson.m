1:
m="acetylsalicylic acid" 19:0 19:1
do="81 mg" 19:2 19:3
mo="po " 19:4 19:4
f="daily " 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="atorvastatin" 20:0 20:0
do="80 mg" 20:1 20:2
mo="po" 20:3 20:3
f="daily" 20:4 20:4
du="nm"
r="nm"
ln="list"
3:
m="coreg ( carvedilol )" 21:0 21:3
do="3.125 mg" 21:4 21:5
mo="po " 21:6 21:6
f="bid " 21:7 21:7
du="nm"
r="nm"
ln="list"
4:
m="plavix ( clopidogrel )" 27:0 27:3
do="75 mg" 27:4 27:5
mo="po" 27:6 27:6
f="daily" 27:7 27:7
du="nm"
r="nm"
ln="list"
5:
m="lasix ( furosemide )" 28:0 28:3
do="80 mg" 28:4 28:5
mo="po" 28:6 28:6
f="daily" 28:7 28:7
du="nm"
r="nm"
ln="list"
6:
m="insulin 70/30 human" 29:0 29:2
do="35 units" 29:6 29:7
mo="sc" 29:9 29:9
f="qpm" 29:8 29:8
du="nm"
r="nm"
ln="list"
7:
m="insulin 70/30 human" 29:0 29:2
do="35 units" 30:3 30:4
mo="nm"
f="qpm" 30:5 30:5
du="nm"
r="nm"
ln="list"
8:
m="insulin 70/30 human" 29:0 29:2
do="50 units" 29:3 29:4
mo="nm"
f="qam;" 29:5 29:5
du="nm"
r="nm"
ln="list"
9:
m="insulin 70/30 human" 29:0 29:2
do="50 units" 30:0 30:1
mo="nm"
f="qam 35" 30:2 30:3
du="nm"
r="nm"
ln="list"
10:
m="imdur er ( isosorbide mononitrate ( sr ) )" 31:0 31:8
do="30 mg" 31:9 31:10
mo="po" 31:11 31:11
f="daily" 31:12 31:12
du="nm"
r="nm"
ln="list"
11:
m="lisinopril" 35:0 35:0
do="10 mg" 35:1 35:2
mo="po" 35:3 35:3
f="daily" 35:4 35:4
du="nm"
r="nm"
ln="list"
12:
m="spironolactone" 38:3 38:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="lisinopril" 39:0 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="potassium chloride" 40:3 40:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="lisinopril" 41:0 41:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="potassium chloride" 42:3 42:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="lisinopril" 43:0 43:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="metamucil sugar free ( psyllium ( metamucil ) su... )" 44:0 44:9
do="1 packet" 45:0 45:1
mo="po" 45:2 45:2
f="daily" 45:3 45:3
du="nm"
r="nm"
ln="list"
19:
m="spironolactone" 46:0 46:0
do="50 mg" 46:1 46:2
mo="po" 46:3 46:3
f="daily" 46:4 46:4
du="nm"
r="nm"
ln="list"
20:
m="lisinopril" 50:3 50:3
do="nm"
mo="po" 50:4 50:4
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="spironolactone" 51:3 51:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="lisinopril" 52:0 52:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="kcl immediate release" 55:3 55:5
do="nm"
mo="po" 55:6 55:6
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="potassium chloride" 57:4 57:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="spironolactone" 57:2 57:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="potassium chloride immed. rel." 61:3 61:6
do="nm"
mo="po" 61:7 61:7
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="potassium chloride" 63:4 63:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="spironolactone" 63:2 63:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="captopril" 66:3 66:3
do="nm"
mo="po" 66:4 66:4
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="captopril" 67:5 67:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="spironolactone" 67:3 67:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="insulin aspart" 69:0 69:1
do="0 units" 70:9 70:10
mo="subcutaneously" 70:11 70:11
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="insulin aspart" 69:0 69:1
do="10 units" 76:7 76:8
mo="subcutaneously" 76:9 76:9
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="insulin aspart" 69:0 69:1
do="2 units" 71:7 71:8
mo="subcutaneously" 71:9 71:9
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="insulin aspart" 69:0 69:1
do="3 units" 72:7 72:8
mo="subcutaneously" 72:9 72:9
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="insulin aspart" 69:0 69:1
do="4 units" 73:7 73:8
mo="subcutaneously" 73:9 73:9
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="insulin aspart" 69:0 69:1
do="6 units" 74:7 74:8
mo="subcutaneously" 74:9 74:9
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="insulin aspart" 69:0 69:1
do="8 units" 75:7 75:8
mo="subcutaneously" 75:9 75:9
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="insulin aspart" 69:0 69:1
do="sliding scale" 69:2 69:3
mo="( subcutaneously ) sc" 69:4 69:7
f="ac" 69:8 69:8
du="nm"
r="nm"
ln="list"
40:
m="nitro" 110:12 110:12
do="two" 110:11 110:11
mo="nm"
f="nm"
du="nm"
r="the sx" 110:6 110:7
ln="narrative"
41:
m="meds" 113:4 113:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="asa" 117:17 117:17
do="325" 118:0 118:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="lasix" 117:14 117:14
do="80iiv" 117:15 117:15
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="coreg" 118:2 118:2
do="6.25" 119:0 119:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="inuslin" 119:2 119:2
do="8u." 119:3 119:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="plavix75" 128:0 128:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
47:
m="asa81" 129:0 129:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
48:
m="carnitidine" 130:0 130:0
do="150" 130:4 130:4
mo="nm"
f="bid" 130:5 130:5
du="nm"
r="nm"
ln="list"
49:
m="imdur" 131:0 131:0
do="30" 131:1 131:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
50:
m="digitek" 132:0 132:0
do="0.125" 132:1 132:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
51:
m="lasix" 133:0 133:0
do="80" 133:1 133:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
52:
m="coreg" 134:0 134:0
do="6.25" 134:1 134:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
53:
m="spironolactone" 135:0 135:0
do="50" 135:1 135:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
54:
m="insulin 70/30" 136:0 136:1
do="35" 136:4 136:4
mo="nm"
f="qpm" 136:5 136:5
du="nm"
r="nm"
ln="list"
55:
m="insulin 70/30" 136:0 136:1
do="50qam" 136:2 136:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
56:
m="asa" 164:9 164:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="unstable angina." 164:6 164:7
ln="narrative"
57:
m="carvedilol" 164:11 164:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
58:
m="lipitor" 165:7 165:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="lisinopril" 165:3 165:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
60:
m="lovenox" 165:13 165:13
do="100" 165:14 165:14
mo="sq." 166:0 166:0
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="plavix" 165:9 165:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="lovenox" 166:1 166:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="lipitor" 167:1 167:1
do="80" 167:2 167:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
64:
m="lasix" 171:4 171:4
do="40iv" 171:5 171:5
mo="nm"
f="bid" 171:6 171:6
du="nm"
r="nm"
ln="narrative"
65:
m="lasix" 172:4 172:4
do="40iv" 172:5 172:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
66:
m="spironolactone" 172:8 172:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
67:
m="acei" 173:4 173:4
do="10mg" 173:9 173:9
mo="nm"
f="qd." 173:10 173:10
du="nm"
r="nm"
ln="narrative"
68:
m="acei" 173:4 173:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="imdur." 173:3 173:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
70:
m="lasix" 177:2 177:2
do="80po" 177:3 177:3
mo="nm"
f="daily." 177:4 177:4
du="nm"
r="nm"
ln="narrative"
71:
m="lovenox" 187:3 187:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="ua" 187:5 187:5
ln="narrative"
72:
m="asa" 188:12 188:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
73:
m="plavix" 188:10 188:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
74:
m="plavix" 188:3 188:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="stent." 188:6 188:6
ln="narrative"
75:
m="nph" 189:2 189:2
do="10" 189:11 189:11
mo="nm"
f="nm"
du="nm"
r="tighter glucose control" 190:5 190:7
ln="narrative"
76:
m="nph" 189:2 189:2
do="18" 189:3 189:3
mo="nm"
f="bid" 189:4 189:4
du="nm"
r="tighter glucose control" 190:5 190:7
ln="narrative"
77:
m="nph" 189:2 189:2
do="6u" 189:14 189:14
mo="ac" 189:15 189:15
f="nm"
du="nm"
r="tighter glucose control" 190:5 190:7
ln="narrative"
78:
m="nph" 191:4 191:4
do="an increased dose" 191:0 191:2
mo="nm"
f="nm"
du="nm"
r="his blood sugar" 191:12 192:0
ln="narrative"
79:
m="medications" 200:6 200:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
80:
m="your medications" 200:5 200:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
81:
m="lasix" 202:8 202:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
82:
m="insulin" 205:0 205:0
do="nm"
mo="nm"
f="as needed." 205:1 205:2
du="nm"
r="blood sugar" 204:3 204:4
ln="narrative"
83:
m="medications" 211:4 211:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
84:
m="your medications" 211:3 211:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
85:
m="lasix" 213:8 213:8
do="dose." 213:9 213:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
