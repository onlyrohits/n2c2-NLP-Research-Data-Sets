1:
m="acetylsalicylic acid" 16:0 16:1
do="81 mg" 16:2 16:3
mo="po" 16:4 16:4
f="daily" 16:5 16:5
du="nm"
r="nm"
ln="list"
2:
m="atenolol" 18:0 18:0
do="100 mg" 18:1 18:2
mo="po" 18:3 18:3
f="bid" 18:4 18:4
du="nm"
r="nm"
ln="list"
3:
m="lipitor ( atorvastatin )" 19:0 19:3
do="40 mg" 19:4 19:5
mo="po" 19:6 19:6
f="daily" 19:7 19:7
du="nm"
r="nm"
ln="list"
4:
m="lipitor" 21:4 21:4
do="80mg tablet in half" 21:5 21:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="zetia ( ezetimibe )" 23:0 23:3
do="10 mg" 23:4 23:5
mo="po" 23:6 23:6
f="daily" 23:7 23:7
du="nm"
r="nm"
ln="list"
6:
m="hydrochlorothiazide" 24:0 24:0
do="50 mg" 24:1 24:2
mo="po" 24:3 24:3
f="daily" 24:4 24:4
du="nm"
r="nm"
ln="list"
7:
m="imdur er ( isosorbide mononitrate ( sr ) )" 25:0 25:8
do="120 mg" 25:9 25:10
mo="po" 25:11 25:11
f="daily" 25:12 25:12
du="nm"
r="nm"
ln="list"
8:
m="lisinopril" 29:0 29:0
do="40 mg" 29:1 29:2
mo="po" 29:3 29:3
f="daily" 29:4 29:4
du="nm"
r="nm"
ln="list"
9:
m="lisinopril" 29:0 29:0
do="one 40mg tablet" 30:3 30:5
mo="po" 29:3 29:3
f="daily." 30:6 30:6
du="nm"
r="nm"
ln="list"
10:
m="potassium chloride" 32:3 32:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="lisinopril" 33:0 33:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="potassium chloride" 34:3 34:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="lisinopril" 35:0 35:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="potassium chloride" 36:3 36:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="lisinopril" 37:0 37:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="potassium chloride" 38:3 38:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="lisinopril" 39:0 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="nifedipine ( sustained release ) ( nifedipine ( s... )" 40:0 40:9
do="90 mg" 41:0 41:1
mo="po" 41:2 41:2
f="daily" 41:3 41:3
du="nm"
r="nm"
ln="list"
19:
m="nitroglycerin 1/150 ( 0.4 mg )" 43:0 43:5
do="1 tab" 43:6 43:7
mo="sl" 43:8 43:8
f="q5min x 3 doses prn" 43:9 44:0
du="nm"
r="chest pain" 44:1 44:2
ln="list"
20:
m="nitro spray" 80:3 80:4
do="nm"
mo="nm"
f="x2" 80:5 80:5
du="nm"
r="nm"
ln="narrative"
21:
m="nifedipine sprays" 86:0 86:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="asa" 94:9 94:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="lopressor" 94:2 94:2
do="5mg" 94:3 94:3
mo="iv" 94:4 94:4
f="nm"
du="x1`" 94:5 94:5
r="nm"
ln="narrative"
24:
m="heparin" 96:9 96:9
do="1500u/hr" 97:2 97:2
mo="infusion" 97:3 97:3
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="heparin" 96:9 96:9
do="5000u" 96:10 96:10
mo="bolus" 96:11 96:11
f="x1" 97:0 97:0
du="nm"
r="nm"
ln="narrative"
26:
m="metformin" 101:3 101:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="metformin" 132:8 132:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="gemfibrozil" 133:10 133:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="statins" 134:0 134:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="asa" 140:5 140:5
do="81mg" 140:6 140:6
mo="po" 140:7 140:7
f="qdayatenolol" 140:8 140:8
du="nm"
r="nm"
ln="list"
31:
m="er ( isosorbide )" 141:4 141:7
do="120mg" 141:8 141:8
mo="po" 141:9 141:9
f="qdayLipitor" 141:10 141:10
du="nm"
r="nm"
ln="list"
32:
m="( ezetimibe )" 142:2 142:4
do="10mg" 142:5 142:5
mo="po" 142:6 142:6
f="qdayhctz" 142:7 142:7
du="nm"
r="nm"
ln="list"
33:
m="er" 143:1 143:1
do="90mg" 143:2 143:2
mo="po" 143:3 143:3
f="qdayNitroglycerin" 143:4 143:4
du="nm"
r="nm"
ln="list"
34:
m="asa" 184:9 184:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="hep gtt" 184:11 184:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="statin" 184:14 184:14
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="acei" 185:2 185:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="bb" 185:0 185:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="statin" 185:18 185:18
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="acei" 186:6 186:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="heparin gtt" 187:4 187:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="acei" 188:11 188:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="asa" 188:7 188:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="bb" 188:9 188:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="imdur" 188:13 188:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="lipitor" 188:15 188:15
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="zetia" 188:17 188:17
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="metformin" 189:5 189:5
do="nm"
mo="nm"
f="nm"
du="for 2 days before and 2 days after cardiac catheterization." 189:6 190:2
r="nm"
ln="narrative"
49:
m="acei" 194:12 194:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="htn" 194:5 194:5
ln="narrative"
50:
m="bb" 194:10 194:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="htn" 194:5 194:5
ln="narrative"
51:
m="atenolol" 195:7 195:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="metformin" 197:2 197:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="ssi" 197:7 197:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="nexium/heparin" 199:1 199:1
do="nm"
mo="gtt" 199:2 199:2
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="your medications" 211:10 212:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="metformin" 213:1 213:1
do="nm"
mo="nm"
f="nm"
du="for 2 days before and 2 days after your cardiac catheterization" 213:2 214:0
r="nm"
ln="list"
57:
m="lisinopril" 214:4 214:4
do="40 mg" 214:5 214:6
mo="nm"
f="daily" 214:7 214:7
du="nm"
r="nm"
ln="narrative"
58:
m="lisinopril" 214:4 214:4
do="80 mg" 214:10 214:11
mo="nm"
f="daily" 214:12 214:12
du="nm"
r="nm"
ln="narrative"
59:
m="lipitor" 215:3 215:3
do="40 mg" 215:4 215:5
mo="nm"
f="daily " 215:6 215:6
du="nm"
r="nm"
ln="list"
60:
m="lipitor" 215:3 215:3
do="80 mg" 215:9 215:10
mo="nm"
f="daily." 215:11 215:11
du="nm"
r="nm"
ln="list"
