1:
m="asa ( acetylsalicylic acid )" 16:0 16:4
do="325 mg" 16:5 16:6
mo="po " 16:7 16:7
f="qd " 16:8 16:8
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 19:3 19:3
do="nm"
mo="po" 19:4 19:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 20:3 20:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 20:5 20:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="coumadin" 24:3 24:3
do="nm"
mo="po " 24:4 24:4
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="aspirin" 25:3 25:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="warfarin" 25:5 25:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="atenolol" 27:0 27:0
do="25 mg" 27:1 27:2
mo="po " 27:3 27:3
f="qd " 27:4 27:4
du="nm"
r="nm"
ln="narrative"
9:
m="colace ( docusate sodium )" 30:0 30:4
do="100 mg" 30:5 30:6
mo="po" 30:7 30:7
f="bid" 30:8 30:8
du="nm"
r="nm"
ln="list"
10:
m="lasix ( furosemide )" 31:0 31:3
do="60mg" 32:2 32:2
mo="po" 31:6 31:6
f="qd...per day" 31:7 31:7,32:3 32:4
du="for 3 days" 32:5 32:7
r="nm"
ln="list"
11:
m="zestril ( lisinopril )" 34:0 34:3
do="7.5 mg" 34:4 34:5
mo="po" 34:6 34:6
f="qd" 34:7 34:7
du="nm"
r="nm"
ln="list"
12:
m="kcl immediate rel." 38:3 38:5
do="nm"
mo="po" 38:6 38:6
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="lisinopril" 39:3 39:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="potassium chloride" 39:5 40:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="kcl slow rel." 43:3 43:5
do="nm"
mo="po" 43:6 43:6
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="lisinopril" 44:3 44:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="potassium chloride" 44:5 45:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="coumadin ( warfarin sodium )" 46:0 46:4
do="6 mg" 46:5 46:6
mo="po" 46:7 46:7
f="qd" 46:8 46:8
du="nm"
r="nm"
ln="list"
19:
m="zocor" 51:3 51:3
do="nm"
mo="po " 51:4 51:4
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="simvastatin" 52:5 52:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="warfarin" 52:3 52:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="zocor" 56:3 56:3
do="nm"
mo="po" 56:4 56:4
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="simvastatin" 57:5 57:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="warfarin" 57:3 57:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="aspirin" 61:3 61:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="warfarin" 61:5 61:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="zocor ( simvastatin )" 63:0 63:3
do="20 mg" 63:4 63:5
mo="po" 63:6 63:6
f="qhs" 63:7 63:7
du="nm"
r="nm"
ln="narrative"
28:
m="erythromycin" 68:3 68:3
do="nm"
mo="tp" 68:4 68:4
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="simvastatin" 69:3 69:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="erythromycin" 70:0 70:0
do="nm"
mo="ophthalmic" 70:4 70:4
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="erythromycin" 70:0 70:0
do="nm"
mo="topical" 70:2 70:2
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="coumadin" 73:3 73:3
do="nm"
mo="po " 73:4 73:4
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="simvastatin" 74:3 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="warfarin" 74:5 74:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="simvastatin" 78:5 78:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="warfarin" 78:3 78:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="metformin" 80:0 80:0
do="1 , 000 mg" 80:1 80:4
mo="po" 80:5 80:5
f="bid" 80:6 80:6
du="nm"
r="nm"
ln="list"
38:
m="prilosec ( omeprazole )" 81:0 81:3
do="20 mg" 81:4 81:5
mo="po" 81:6 81:6
f="qd" 81:7 81:7
du="nm"
r="nm"
ln="list"
39:
m="furosemide" 83:3 83:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="omeprazole" 83:5 83:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="valacyclovir" 85:0 85:0
do="1 , 000 mg" 85:1 85:4
mo="po" 85:5 85:5
f="q8h" 85:6 85:6
du="x 7 days" 85:7 85:9
r="nm"
ln="list"
42:
m="lasix" 107:7 107:7
do="40" 107:8 107:8
mo="iv" 107:6 107:6
f="nm"
du="nm"
r="sob" 108:5 108:5
ln="narrative"
43:
m="lasix" 116:0 116:0
do="60 mg" 115:13 115:14
mo="nm"
f="qd " 116:1 116:1
du="nm"
r="nm"
ln="narrative"
44:
m="tylenol." 123:1 123:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 122:12 122:12
ln="narrative"
