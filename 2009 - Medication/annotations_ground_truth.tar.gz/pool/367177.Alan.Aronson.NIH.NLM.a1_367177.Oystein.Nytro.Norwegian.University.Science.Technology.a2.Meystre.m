1:
m="lisinopril" 16:0 16:0
do="5 mg" 16:1 16:2
mo="po" 16:3 16:3
f="qd" 16:4 16:4
du="nm"
r="nm"
ln="list"
2:
m="potassium chloride" 19:3 19:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="lisinopril" 20:0 20:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="metformin" 21:0 21:0
do="1 , 000 mg" 21:1 21:4
mo="po" 21:5 21:5
f="bid" 21:6 21:6
du="nm"
r="nm"
ln="list"
5:
m="levofloxacin" 22:0 22:0
do="250 mg" 22:1 22:2
mo="po" 22:3 22:3
f="qd" 22:4 22:4
du="x 1 doses" 22:5 22:7
r="nm"
ln="list"
6:
m="iron products" 24:1 24:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="ciprofloxacin" 25:4 25:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="levofloxacin" 25:2 25:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="lantus ( insulin glargine )" 28:0 28:4
do="20 units" 28:5 28:6
mo="sc" 28:7 28:7
f="qd" 28:8 28:8
du="nm"
r="nm"
ln="list"
10:
m="lantus" 58:5 58:5
do="20 units" 58:6 58:7
mo="nm"
f="nm"
du="nm"
r="her blood sugar" 57:5 57:7
ln="narrative"
11:
m="novolog" 58:10 58:10
do="6 units." 58:11 58:12
mo="nm"
f="nm"
du="nm"
r="her blood sugar" 57:5 57:7
ln="narrative"
12:
m="regular insulin" 58:0 58:1
do="18 units" 58:2 58:3
mo="nm"
f="nm"
du="nm"
r="her blood sugar" 57:5 57:7
ln="narrative"
13:
m="diabetes medication" 60:0 60:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="insulin" 63:1 63:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="diabetes home medication regimen" 92:2 92:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="lantus" 95:1 95:1
do="25 mg" 95:3 95:4
mo="sc" 95:5 95:5
f="qd." 95:6 95:6
du="nm"
r="blood sugar" 94:0 94:1
ln="narrative"
17:
m="metformin" 95:8 95:8
do="1000 mg" 95:10 95:11
mo="po" 95:12 95:12
f="bid" 95:13 95:13
du="nm"
r="nm"
ln="narrative"
18:
m="lisinopril" 101:1 101:1
do="5 mg" 101:2 101:3
mo="po" 101:4 101:4
f="qd" 101:5 101:5
du="nm"
r="htn:" 101:0 101:0
ln="narrative"
19:
m="levofloxacin" 102:2 102:2
do="250 mg" 102:3 102:4
mo="po" 102:5 102:5
f="qd" 102:6 102:6
du="x 2 doses" 102:7 102:9
r="uti" 102:1 102:1
ln="narrative"
20:
m="colace" 105:8 105:8
do="nm"
mo="nm"
f="prn" 106:0 106:0
du="nm"
r="nm"
ln="narrative"
21:
m="kcl" 105:1 105:1
do="replacement scale" 105:3 105:4
mo="po" 105:2 105:2
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="mgsulfate" 105:5 105:5
do="sliding scale.gi:" 105:6 105:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="mom" 106:2 106:2
do="nm"
mo="nm"
f="prndispo:" 106:3 106:3
du="nm"
r="nm"
ln="narrative"
24:
m="insulin" 113:2 113:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="metformin" 113:4 113:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
