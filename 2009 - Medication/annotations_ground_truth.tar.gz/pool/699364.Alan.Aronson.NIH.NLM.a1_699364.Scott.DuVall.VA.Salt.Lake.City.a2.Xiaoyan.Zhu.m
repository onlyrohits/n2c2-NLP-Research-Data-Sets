1:
m="aspirin" 14:5 14:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="statin." 14:7 14:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="beta-blocker" 15:0 15:0
do="titrated" 15:10 15:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="lopressor" 16:4 16:4
do="12.5 mg" 16:5 16:6
mo="p.o." 16:7 16:7
f="t.i.d." 16:8 16:8
du="nm"
r="nm"
ln="narrative"
5:
m="isordil" 21:5 21:5
do="20 mg" 21:6 21:7
mo="p.o." 21:8 21:8
f="t.i.d." 21:9 21:9
du="nm"
r="nm"
ln="narrative"
6:
m="hydralazine" 22:0 22:0
do="50 mg" 22:1 22:2
mo="p.o." 22:3 22:3
f="t.i.d." 22:4 22:4
du="nm"
r="nm"
ln="narrative"
7:
m="beta-blocker" 23:4 23:4
do="12.5 mg" 23:6 23:7
mo="p.o." 23:8 23:8
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="beta-blocker" 23:4 23:4
do="12.5 mg" 23:6 23:7
mo="p.o." 23:8 23:8
f="t.i.d." 23:9 23:9
du="nm"
r="nm"
ln="narrative"
9:
m="digoxin" 24:2 24:2
do="0.125 mg" 24:4 24:5
mo="p.o." 24:6 24:6
f="q.o.d." 24:7 24:7
du="nm"
r="nm"
ln="narrative"
10:
m="lasix" 25:4 25:4
do="nm"
mo="intravenous" 25:3 25:3
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="zaroxolyn" 25:6 25:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="torsemide" 26:7 26:7
do="nm"
mo="oral" 26:4 26:4
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="beta-blocker" 34:4 34:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="digoxin" 34:6 34:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="amiodarone" 35:6 35:6
do="200 mg" 35:8 35:9
mo="p.o." 36:0 36:0
f="q.d." 36:1 36:1
du="nm"
r="nm"
ln="narrative"
16:
m="coumadin." 38:5 38:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial clot" 36:11 37:0
ln="narrative"
17:
m="heparin" 38:0 38:0
do="nm"
mo="drip" 38:1 38:1
f="nm"
du="nm"
r="atrial clot" 36:11 37:0
ln="narrative"
18:
m="coumadin" 41:2 41:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial clot" 43:8 43:9
ln="narrative"
19:
m="coumadin" 44:8 44:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial clot" 43:8 43:9
ln="narrative"
20:
m="aspirin" 45:6 45:6
do="full doses." 45:10 46:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="plavix" 45:8 45:8
do="full doses." 45:10 46:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="coumadin" 46:4 46:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="lantus" 50:2 50:2
do="5 units" 50:3 50:4
mo="nm"
f="q.p.m." 50:5 50:5
du="nm"
r="nm"
ln="narrative"
24:
m="novolog" 50:8 50:8
do="3 units" 50:9 50:10
mo="nm"
f="q.a.c." 51:0 51:0
du="nm"
r="nm"
ln="narrative"
25:
m="novolog" 51:5 51:5
do="sliding scale." 51:6 51:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="insulin regimen" 52:0 52:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="diabetes medications" 53:1 53:2
do="nm"
mo="oral" 53:0 53:0
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="ace inhibitor" 60:2 60:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="aspirin" 65:2 65:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="plavix." 65:4 65:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="heparin" 66:6 66:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="coumadin" 72:7 72:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="aspirin" 108:1 108:1
do="325 mg" 108:2 108:3
mo="p.o." 108:4 108:4
f="q.d." 108:5 108:5
du="nm"
r="nm"
ln="list"
34:
m="amiodarone" 109:1 109:1
do="200 mg" 109:2 109:3
mo="p.o." 109:4 109:4
f="q.d." 109:5 109:5
du="nm"
r="nm"
ln="list"
35:
m="digoxin" 110:1 110:1
do="0.125 mg" 110:2 110:3
mo="p.o." 110:4 110:4
f="q.o.d." 110:5 110:5
du="nm"
r="nm"
ln="list"
36:
m="colace" 111:1 111:1
do="100 mg" 111:2 111:3
mo="p.o." 111:4 111:4
f="b.i.d." 111:5 111:5
du="nm"
r="nm"
ln="list"
37:
m="folate" 112:1 112:1
do="1 mg" 112:2 112:3
mo="p.o." 112:4 112:4
f="q.d." 112:5 112:5
du="nm"
r="nm"
ln="list"
38:
m="robitussin a-c" 113:1 113:2
do="5 ml" 113:3 113:4
mo="p.o." 113:5 113:5
f="q.4h. p.r.n." 113:6 113:7
du="nm"
r="cough." 113:8 113:8
ln="list"
39:
m="hydralazine" 114:1 114:1
do="50 mg" 114:2 114:3
mo="p.o." 114:4 114:4
f="t.i.d." 114:5 114:5
du="nm"
r="nm"
ln="list"
40:
m="isordil" 115:1 115:1
do="20 mg" 115:2 115:3
mo="p.o." 115:4 115:4
f="t.i.d." 115:5 115:5
du="nm"
r="nm"
ln="list"
41:
m="lopressor" 116:1 116:1
do="12.5 mg" 116:2 116:3
mo="p.o." 116:4 116:4
f="q.6h." 116:5 116:5
du="nm"
r="nm"
ln="list"
42:
m="simethicone" 117:1 117:1
do="80 mg" 117:2 117:3
mo="p.o." 117:4 117:4
f="q.i.d. p.r.n." 117:5 117:6
du="nm"
r="upset stomach." 117:7 117:8
ln="list"
43:
m="multivitamin" 118:1 118:1
do="one tab" 118:2 118:3
mo="p.o." 118:4 118:4
f="q.d." 118:5 118:5
du="nm"
r="nm"
ln="list"
44:
m="compazine" 119:1 119:1
do="5-10 mg" 119:2 119:3
mo="p.o." 119:4 119:4
f="q.6h. p.r.n." 119:5 119:6
du="nm"
r="nausea." 119:7 119:7
ln="list"
45:
m="tessalon" 120:1 120:1
do="100 mg" 120:2 120:3
mo="p.o." 120:4 120:4
f="t.i.d. p.r.n." 120:5 120:6
du="nm"
r="cough." 120:7 120:7
ln="list"
46:
m="torsemide" 121:1 121:1
do="100 mg" 121:2 121:3
mo="p.o." 121:4 121:4
f="q.d." 121:5 121:5
du="nm"
r="nm"
ln="list"
47:
m="lipitor" 122:1 122:1
do="80 mg" 122:2 122:3
mo="p.o." 122:4 122:4
f="q.d." 122:5 122:5
du="nm"
r="nm"
ln="list"
48:
m="plavix" 123:1 123:1
do="75 mg" 123:2 123:3
mo="p.o." 123:4 123:4
f="q.d." 123:5 123:5
du="nm"
r="nm"
ln="list"
49:
m="lantus" 124:1 124:1
do="5 units" 124:2 124:3
mo="subcu" 124:4 124:4
f="q.p.m." 124:5 124:5
du="nm"
r="nm"
ln="list"
50:
m="novolog" 125:1 125:1
do="3 units" 125:2 125:3
mo="subcu" 125:4 125:4
f="a.c." 125:5 125:5
du="nm"
r="nm"
ln="list"
51:
m="novolog" 127:1 127:1
do="sliding scale" 127:2 127:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
