1:
m="lasix" 18:7 18:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="lasix" 29:8 29:8
do="80 mg" 29:9 29:10
mo="nm"
f="nm"
du="x1" 30:0 30:0
r="nm"
ln="narrative"
3:
m="duonebs" 30:5 30:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="solu-medrol" 30:2 30:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="allopurinol." 46:1 46:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="iron." 47:1 47:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="lisinopril." 48:1 48:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="toprol-xl." 49:1 49:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="coumadin" 50:1 50:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="albuterol inhaler" 51:1 51:2
do="nm"
mo="nm"
f="p.r.n." 51:3 51:3
du="nm"
r="nm"
ln="list"
11:
m="aspirin." 52:1 52:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="flomax." 53:1 53:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="hytrin." 54:1 54:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="lasix" 88:1 88:1
do="nm"
mo="nm"
f="nm"
du="for about a week." 88:2 88:5
r="nm"
ln="narrative"
15:
m="lasix" 92:7 92:7
do="40 mg" 93:3 93:4
mo="nm"
f="daily" 93:5 93:5
du="nm"
r="diuresis" 92:8 92:8
ln="narrative"
16:
m="captopril" 95:0 95:0
do="25 mg" 95:7 95:8
mo="nm"
f="t.i.d." 95:9 95:9
du="nm"
r="nm"
ln="narrative"
17:
m="metoprolol" 97:3 97:3
do="25 mg" 97:5 97:6
mo="nm"
f="b.i.d." 97:7 97:7
du="nm"
r="nm"
ln="narrative"
18:
m="antibiotics" 120:5 120:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="regular insulin" 124:3 124:4
do="sliding scale." 124:5 124:6
mo="nm"
f="nm"
du="nm"
r="diabetes" 123:8 123:8
ln="narrative"
20:
m="cefazolin" 127:0 127:0
do="nm"
mo="nm"
f="nm"
du="while in-house" 127:1 127:2
r="nm"
ln="narrative"
21:
m="keflex." 127:6 127:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="keflex" 128:2 128:2
do="nm"
mo="nm"
f="nm"
du="for four days" 128:3 128:5
r="nm"
ln="narrative"
23:
m="albuterol inhaler" 130:1 130:2
do="two puffs" 130:3 130:4
mo="inhaled" 130:5 130:5
f="q.i.d. p.r.n." 130:6 130:7
du="nm"
r="wheezing." 130:8 130:8
ln="list"
24:
m="allopurinol" 131:1 131:1
do="100 mg" 131:2 131:3
mo="p.o." 131:4 131:4
f="daily." 131:5 131:5
du="nm"
r="nm"
ln="list"
25:
m="captopril" 132:1 132:1
do="25 mg" 132:2 132:3
mo="p.o." 132:4 132:4
f="t.i.d." 132:5 132:5
du="nm"
r="nm"
ln="list"
26:
m="colace" 133:1 133:1
do="100 mg" 133:2 133:3
mo="p.o." 133:4 133:4
f="b.i.d." 133:5 133:5
du="nm"
r="nm"
ln="list"
27:
m="ferrous sulfate" 134:1 134:2
do="325 mg" 134:3 134:4
mo="p.o." 134:5 134:5
f="daily." 134:6 134:6
du="nm"
r="nm"
ln="list"
28:
m="lasix" 135:1 135:1
do="40 mg" 135:2 135:3
mo="p.o." 135:4 135:4
f="daily." 135:5 135:5
du="nm"
r="nm"
ln="list"
29:
m="heparin" 136:1 136:1
do="5000 units" 136:2 136:3
mo="subcutaneous" 136:4 136:4
f="t.i.d." 136:5 136:5
du="nm"
r="nm"
ln="list"
30:
m="regular insulin" 137:1 137:2
do="sliding scale" 137:3 137:4
mo="subcutaneous" 137:5 137:5
f="q.a.c." 137:6 137:6
du="nm"
r="nm"
ln="list"
31:
m="lopressor" 138:1 138:1
do="25 mg" 138:2 138:3
mo="p.o." 138:4 138:4
f="b.i.d." 138:5 138:5
du="nm"
r="nm"
ln="list"
32:
m="oxycodone" 139:1 139:1
do="5 mg to 10 mg" 139:2 139:6
mo="p.o." 139:7 139:7
f="q.6h. p.r.n." 139:8 139:9
du="nm"
r="nm"
ln="list"
33:
m="keflex" 140:1 140:1
do="250 mg" 140:2 140:3
mo="p.o." 140:4 140:4
f="q.i.d." 140:5 140:5
du="x12 doses" 140:6 140:7
r="nm"
ln="list"
34:
m="flomax" 141:1 141:1
do="0.4 mg" 141:2 141:3
mo="p.o." 141:4 141:4
f="daily." 141:5 141:5
du="nm"
r="nm"
ln="list"
35:
m="nexium" 142:1 142:1
do="20 mg" 142:2 142:3
mo="p.o." 142:4 142:4
f="daily." 142:5 142:5
du="nm"
r="nm"
ln="list"
