1:
m="acetylsalicylic acid" 16:0 16:1
do="81 mg" 16:2 16:3
mo="po" 16:4 16:4
f="qd" 16:5 16:5
du="nm"
r="nm"
ln="list"
2:
m="vit c ( ascorbic acid )" 17:0 17:5
do="500 mg" 17:6 17:7
mo="po" 17:8 17:8
f="bid" 17:9 17:9
du="nm"
r="nm"
ln="list"
3:
m="atenolol" 18:0 18:0
do="75 mg" 18:1 18:2
mo="po" 18:3 18:3
f="qd" 18:4 18:4
du="nm"
r="nm"
ln="list"
4:
m="digoxin" 19:0 19:0
do="0.125 mg" 19:1 19:2
mo="po" 19:3 19:3
f="qod...sun , tues , thurs" 19:4 19:4,19:6 19:10
du="nm"
r="nm"
ln="list"
5:
m="synthroid" 22:3 22:3
do="nm"
mo="po" 22:4 22:4
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="digoxin" 23:3 23:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="levothyroxine sodium" 23:5 24:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="digoxin" 25:0 25:0
do="0.1875 mg" 25:1 25:2
mo="po" 25:3 25:3
f="qod...on m , w , f , sat" 25:4 25:4,25:6 25:13
du="nm"
r="nm"
ln="list"
9:
m="levothyroxine sodium" 28:3 28:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="digoxin" 29:0 29:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="colace ( docusate sodium )" 30:0 30:4
do="100 mg" 30:5 30:6
mo="po" 30:7 30:7
f="bid prn" 30:8 30:9
du="nm"
r="constipation" 30:10 30:10
ln="list"
12:
m="pepcid (famotidine)" 31:0 31:3
do="20 mg" 31:4 31:5
mo="po" 31:6 31:6
f="qd" 31:7 31:7
du="nm"
r="nm"
ln="list"
13:
m="lasix ( furosemide )" 33:0 33:3
do="20 mg" 33:4 33:5
mo="po" 33:6 33:6
f="qd" 33:7 33:7
du="nm"
r="nm"
ln="list"
14:
m="lasix" 36:3 36:3
do="nm"
mo="po" 36:4 36:4
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="synthroid (levothyroxine sodium)" 39:0 39:4
do="50 mcg" 39:5 39:6
mo="po" 39:7 39:7
f="qd" 39:8 39:8
du="nm"
r="nm"
ln="list"
16:
m="digoxin" 42:3 42:3
do="nm"
mo="po" 42:4 42:4
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="levothyroxine sodium" 43:3 43:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="digoxin" 44:0 44:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="digoxin" 47:3 47:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="levothyroxine sodium" 47:5 48:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="senna tablets" 49:0 49:1
do="2 tab" 49:2 49:3
mo="po" 49:4 49:4
f="bid prn" 49:5 49:6
du="nm"
r="constipation" 49:7 49:7
ln="list"
22:
m="stanozolol" 50:0 50:0
do="4 mg" 50:1 50:2
mo="po" 50:3 50:3
f="qd starting in am" 50:4 50:7
du="nm"
r="nm"
ln="list"
23:
m="vit e ( tocopherol-dl-alpha )" 51:0 51:4
do="400 units" 51:5 51:6
mo="po" 51:7 51:7
f="qd " 51:8 51:8
du="nm"
r="nm"
ln="narrative"
24:
m="keflex ( cephalexin )" 52:0 52:3
do="500 mg" 52:4 52:5
mo="po" 52:6 52:6
f="qid" 52:7 52:7
du="x 28 doses" 52:8 52:10
r="nm"
ln="list"
25:
m="keflex" 56:3 56:3
do="nm"
mo="po" 56:4 56:4
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="rhinocort ( budesonide nasal inhaler )" 59:0 59:5
do="2 spray" 59:6 59:7
mo="na" 59:8 59:8
f="bid" 59:9 59:9
du="nm"
r="nm"
ln="list"
27:
m="allegra ( fexofenadine hcl )" 60:0 60:4
do="60 mg" 60:5 60:6
mo="po" 60:7 60:7
f="bid" 60:8 60:8
du="nm"
r="nm"
ln="list"
28:
m="coum/asa" 77:5 77:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="hereditary angioedema afib" 77:0 77:2
ln="narrative"
29:
m="coum" 78:3 78:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="hereditary angioedema afib" 77:0 77:2
ln="narrative"
30:
m="stanazolol." 90:4 90:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 89:1 89:1
ln="narrative"
31:
m="benadryl" 98:3 98:3
do="nm"
mo="iv" 98:2 98:2
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="stanazolol" 99:5 99:5
do="4 mg" 99:6 99:7
mo="nm"
f="bid" 100:4 100:4
du="nm"
r="nm"
ln="narrative"
33:
m="stanazolol" 99:5 99:5
do="4 mg" 99:6 99:7
mo="nm"
f="q4h" 99:8 99:8
du="overnight" 99:9 99:9
r="nm"
ln="narrative"
34:
m="allegra" 101:7 101:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="rhinocort" 101:5 101:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="dilaudid." 102:5 102:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="the patient's pain" 101:9 102:1
ln="narrative"
37:
m="cardiac meds" 103:4 103:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="synthroid" 104:6 104:6
do="home dose" 104:3 104:4
mo="nm"
f="nm"
du="nm"
r="hypothyroid" 104:8 104:8
ln="narrative"
39:
m="lovenox" 105:8 105:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="stanazolol." 105:6 105:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="zantac" 105:4 105:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
