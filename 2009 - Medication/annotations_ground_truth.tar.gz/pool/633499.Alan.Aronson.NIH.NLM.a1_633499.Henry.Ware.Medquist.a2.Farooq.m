1:
m="ecasa ( aspirin enteric coated )" 19:0 19:5
do="325 mg" 19:6 19:7
mo="po" 19:8 19:8
f="qd" 19:9 19:9
du="nm"
r="nm"
ln="list"
2:
m="enalapril maleate" 20:0 20:1
do="7.5 mg" 20:2 20:3
mo="po" 20:4 20:4
f="bid" 20:5 20:5
du="nm"
r="nm"
ln="list"
3:
m="ace" 35:0 35:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="heart." 35:2 35:2
ln="list"
4:
m="nph humulin insulin ( insulin nph human )" 36:0 36:7
do="2 units" 36:8 36:9
mo="sc" 36:10 36:10
f="qam" 36:11 36:11
du="nm"
r="nm"
ln="list"
5:
m="nph humulin insulin ( insulin nph human )" 37:0 37:7
do="3 units" 37:8 37:9
mo="sc" 37:10 37:10
f="qpm" 37:11 37:11
du="nm"
r="nm"
ln="list"
6:
m="nitroglycerin 1/150 ( 0.4 mg )" 38:0 38:5
do="1 tab" 38:6 38:7
mo="sl" 38:8 38:8
f="q5min x 3 prn" 38:9 39:0
du="nm"
r="chest pain" 39:1 39:2
ln="list"
7:
m="imdur ( isosorbide mononit.( sr ) )" 40:0 40:6
do="30 mg" 40:7 40:8
mo="po" 40:9 40:9
f="qd" 40:10 40:10
du="nm"
r="nm"
ln="list"
8:
m="nephrocaps ( nephro-vit rx )" 45:0 45:4
do="1 tab" 45:5 45:6
mo="po " 45:7 45:7
f="qd " 45:8 45:8
du="nm"
r="nm"
ln="narrative"
9:
m="nexium ( esomeprazole )" 46:0 46:3
do="20 mg" 46:4 46:5
mo="po" 46:6 46:6
f="qd" 46:7 46:7
du="nm"
r="nm"
ln="list"
10:
m="toprol xl ( metoprolol ( sust. rel. ) )" 47:0 47:8
do="200 mg" 47:9 47:10
mo="po" 47:11 47:11
f="qd" 47:12 47:12
du="nm"
r="nm"
ln="list"
11:
m="asa" 81:1 81:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="lopressor" 81:3 81:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="ace-inh." 82:5 82:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="nitrates" 82:2 82:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="lopressor" 85:6 85:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="toprol xl" 90:5 90:6
do="200" 90:7 90:7
mo="nm"
f="qd" 90:8 90:8
du="nm"
r="minimal ischemia" 88:6 88:7
ln="narrative"
17:
m="calcitonin" 95:10 95:10
do="50mg" 95:8 95:8
mo="sc." 96:0 96:0
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="kayexelate" 98:0 98:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="hyperkalemia" 97:3 97:3
ln="narrative"
19:
m="lactulose" 98:3 98:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="hyperkalemia" 97:3 97:3
ln="narrative"
20:
m="o2." 101:7 101:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="vit d" 107:2 107:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="nph" 108:7 108:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="d50x1" 109:6 109:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="nph" 109:8 109:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
