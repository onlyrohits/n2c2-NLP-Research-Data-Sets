1:
m="acetylsalicylic acid" 16:0 16:1
do="81 mg" 16:2 16:3
mo="po" 16:4 16:4
f="qd" 16:5 16:5
du="nm"
r="nm"
ln="list"
2:
m="aspirin" 19:5 19:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="warfarin" 19:3 19:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="insulin nph human" 21:0 21:2
do="10 units" 21:3 21:4
mo="sc" 21:5 21:5
f="bid" 21:6 21:6
du="nm"
r="nm"
ln="list"
5:
m="lisinopril" 22:0 22:0
do="10 mg" 22:1 22:2
mo="po" 22:3 22:3
f="qd" 22:4 22:4
du="nm"
r="nm"
ln="list"
6:
m="oxycodone" 23:0 23:0
do="5-10 mg" 23:1 23:2
mo="po" 23:3 23:3
f="q6h prn" 23:4 23:5
du="nm"
r="pain" 23:6 23:6
ln="list"
7:
m="coumadin ( warfarin sodium )" 24:0 24:4
do="5 mg" 24:5 24:6
mo="po" 24:7 24:7
f="qpm" 24:8 24:8
du="nm"
r="nm"
ln="list"
8:
m="tricor" 30:3 30:3
do="nm"
mo="po" 30:4 30:4
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="fenofibrate , micronized" 31:5 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="warfarin" 31:3 31:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="acetylsalicylic acid" 35:3 35:4
do="nm"
mo="po" 35:5 35:5
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="aspirin" 36:5 36:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="warfarin" 36:3 36:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="keflex ( cephalexin )" 38:0 38:3
do="250 mg" 38:4 38:5
mo="po" 38:6 38:6
f="qid" 38:7 38:7
du="number of doses required ( approximate ): 20" 40:0 40:7
r="nm"
ln="list"
15:
m="keflex ( cephalexin )" 38:0 38:3
do="250 mg" 38:4 38:5
mo="po" 38:6 38:6
f="qid" 38:7 38:7
du="x 12 doses" 38:8 38:10
r="nm"
ln="list"
16:
m="antibiotics" 39:3 39:3
do="nm"
mo="iv" 39:2 39:2
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="toprol xl ( metoprolol succinate extended release )" 41:0 41:7
do="25 mg" 42:0 42:1
mo="po" 42:2 42:2
f="qd" 42:3 42:3
du="number of doses required ( approximate ): 2" 44:0 44:7
r="nm"
ln="list"
18:
m="tricor ( fenofibrate )" 45:0 45:3
do="145 mg" 45:4 45:5
mo="po" 45:6 45:6
f="qd" 45:7 45:7
du="number of doses required ( approximate ): 2" 50:0 50:7
r="nm"
ln="list"
19:
m="fenofibrate , micronized" 48:5 49:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="warfarin" 48:3 48:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="prilosec ( omeprazole )" 51:0 51:3
do="20 mg" 51:4 51:5
mo="po" 51:6 51:6
f="qd" 51:7 51:7
du="nm"
r="nm"
ln="list"
22:
m="baby asa." 76:4 76:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="coumadin" 76:2 76:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="coumadin" 78:3 78:3
do="5mg" 78:4 78:4
mo="nm"
f="each night." 78:5 78:6
du="nm"
r="nm"
ln="narrative"
