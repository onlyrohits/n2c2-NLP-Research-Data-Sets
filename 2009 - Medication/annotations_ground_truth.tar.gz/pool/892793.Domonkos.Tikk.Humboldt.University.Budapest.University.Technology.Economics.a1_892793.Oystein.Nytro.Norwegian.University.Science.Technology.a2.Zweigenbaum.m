1:
m="adenosine." 41:7 41:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="supraventricular tachycardia" 40:3 40:4
ln="narrative"
2:
m="beta blockade" 41:4 41:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="supraventricular tachycardia" 40:3 40:4
ln="narrative"
3:
m="adenosine" 43:5 43:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="arrhythmia" 43:8 43:8
ln="narrative"
4:
m="beta blockade" 43:2 43:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="arrhythmia" 43:8 43:8
ln="narrative"
5:
m="magnesium" 44:5 44:5
do="1.5" 44:7 44:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="ampicillin" 49:8 49:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="levofloxacin" 49:10 49:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="zantac" 49:3 49:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="flagyl" 50:0 50:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="lopressor" 55:8 55:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="supraventricular tachycardia" 53:7 54:0
ln="narrative"
11:
m="diltiazem" 56:9 56:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="diltiazem drip" 57:2 57:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="lopressor" 57:10 57:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="diltiazem" 58:3 58:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="lopressor" 59:0 59:0
do="50" 59:1 59:1
mo="p.o." 58:10 58:10
f="t.i.d." 59:2 59:2
du="nm"
r="nm"
ln="narrative"
16:
m="oxygen" 62:7 62:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="ampicillin" 65:8 65:8
do="nm"
mo="nm"
f="nm"
du="5-day course" 65:5 65:6
r="nm"
ln="narrative"
18:
m="levofloxacin" 65:10 65:10
do="nm"
mo="nm"
f="nm"
du="5-day course" 65:5 65:6
r="nm"
ln="narrative"
19:
m="flagyl." 66:1 66:1
do="nm"
mo="nm"
f="nm"
du="5-day course" 65:5 65:6
r="nm"
ln="narrative"
20:
m="analgesics." 67:7 67:7
do="minimal amounts" 67:3 67:4
mo="oral" 67:6 67:6
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="lopressor" 70:2 70:2
do="50 mg" 70:3 70:4
mo="p.o." 70:5 70:5
f="t.i.d." 70:6 70:6
du="nm"
r="nm"
ln="list"
22:
m="percocet" 70:8 70:8
do="1-2 tabs" 70:9 71:0
mo="p.o." 71:1 71:1
f="q 3-4 hours p.r.n." 71:2 71:5
du="nm"
r="pain" 71:6 71:6
ln="list"
23:
m="colace" 71:8 71:8
do="100 mg" 71:9 72:0
mo="nm"
f="b.i.d." 72:1 72:1
du="while on percocet" 72:2 72:4
r="nm"
ln="list"
24:
m="percocet" 72:4 72:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
