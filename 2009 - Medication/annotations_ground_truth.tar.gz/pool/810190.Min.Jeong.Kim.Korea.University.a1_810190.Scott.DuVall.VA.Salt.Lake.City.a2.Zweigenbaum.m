1:
m="tylenol ( acetaminophen )" 19:0 19:3
do="650 mg" 19:4 19:5
mo="po" 19:6 19:6
f="q6h prn" 19:7 20:0
du="nm"
r="Other:transfusion premedication" 20:7 21:0
ln="list"
2:
m="tylenol ( acetaminophen )" 19:0 19:3
do="650 mg" 19:4 19:5
mo="po" 19:6 19:6
f="q6h prn" 19:7 20:0
du="nm"
r="pain" 20:1 20:1
ln="list"
3:
m="tylenol ( acetaminophen )" 19:0 19:3
do="650 mg" 19:4 19:5
mo="po" 19:6 19:6
f="q6h prn" 19:7 20:0
du="nm"
r="temperature" 20:3 20:3
ln="list"
4:
m="albuterol nebulizer" 22:0 22:1
do="2.5 mg" 22:2 22:3
mo="inh" 22:4 22:4
f="q4h prn" 22:5 22:6
du="nm"
r="wheezing" 22:7 22:7
ln="list"
5:
m="tessalon perles ( benzonatate )" 23:0 23:4
do="100 mg" 23:5 23:6
mo="po" 23:7 23:7
f="tid prn" 23:8 24:0
du="nm"
r="other:congestion" 24:1 24:1
ln="list"
6:
m="caltrate 600 + d ( calcium carbonate 1 , 500 mg ( ... )" 25:0 25:13
do="2 tab" 26:0 26:1
mo="po" 26:2 26:2
f="bid" 26:3 26:3
du="nm"
r="nm"
ln="list"
7:
m="peridex mouthwash ( chlorhexidine mouthwash 0.12% )" 27:0 27:6
do="15 milliliters" 28:0 28:1
mo="mo" 28:2 28:2
f="bid" 28:3 28:3
du="nm"
r="nm"
ln="list"
8:
m="nystatin" 29:5 29:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="benadryl ( diphenhydramine )" 30:0 30:3
do="12.5 mg" 30:4 30:5
mo="po" 30:6 30:6
f="x1 prn" 30:7 31:0
du="nm"
r="other:pre-transfusion" 31:1 31:1
ln="list"
10:
m="colace ( docusate sodium )" 32:0 32:4
do="100 mg" 32:5 32:6
mo="po" 32:7 32:7
f="bid prn" 32:8 32:9
du="nm"
r="constipation" 32:10 32:10
ln="list"
11:
m="enoxaparin" 33:0 33:0
do="40 mg" 33:1 33:2
mo="sc" 33:3 33:3
f="daily" 33:4 33:4
du="nm"
r="nm"
ln="list"
12:
m="nexium ( esomeprazole )" 34:0 34:3
do="40 mg" 34:4 34:5
mo="po" 34:6 34:6
f="daily" 34:7 34:7
du="nm"
r="nm"
ln="list"
13:
m="flovent hfa ( fluticasone propionate )" 35:0 35:5
do="110 mcg" 35:6 35:7
mo="inh" 35:8 35:8
f="bid" 35:9 35:9
du="nm"
r="nm"
ln="list"
14:
m="insulin aspart" 36:0 36:1
do="0 units" 38:9 38:10
mo="subcutaneously" 38:11 38:11
f="nm"
du="nm"
r="bs is less than 125" 38:1 38:5
ln="list"
15:
m="insulin aspart" 36:0 36:1
do="10 units" 44:7 44:8
mo="subcutaneously" 44:9 44:9
f="nm"
du="nm"
r="bs is 351-400" 44:1 44:3
ln="list"
16:
m="insulin aspart" 36:0 36:1
do="2 units" 39:7 39:8
mo="subcutaneously" 39:9 39:9
f="nm"
du="nm"
r="bs is 125-150" 39:1 39:3
ln="list"
17:
m="insulin aspart" 36:0 36:1
do="3 units" 40:7 40:8
mo="subcutaneously" 39:9 39:9
f="nm"
du="nm"
r="bs is 151-200" 40:1 40:3
ln="list"
18:
m="insulin aspart" 36:0 36:1
do="4 units" 41:7 41:8
mo="subcutaneously" 41:9 41:9
f="nm"
du="nm"
r="bs is 201-250" 41:1 41:3
ln="list"
19:
m="insulin aspart" 36:0 36:1
do="6 units" 42:7 42:8
mo="subcutaneously" 42:9 42:9
f="nm"
du="nm"
r="bs is 251-300" 42:1 42:3
ln="list"
20:
m="insulin aspart" 36:0 36:1
do="8 units" 43:7 43:8
mo="subcutaneously" 43:9 43:9
f="nm"
du="nm"
r="bs is 301-350" 43:1 43:3
ln="list"
21:
m="insulin nph human" 46:0 46:2
do="10 units" 46:3 46:4
mo="sc" 46:5 46:5
f="qam" 46:6 46:6
du="nm"
r="nm"
ln="list"
22:
m="atrovent nebulizer ( ipratropium nebulizer )" 47:0 47:5
do="0.5 mg" 48:0 48:1
mo="inh" 48:2 48:2
f="qid" 48:3 48:3
du="nm"
r="nm"
ln="list"
23:
m="potassium chloride immed. rel. ( kcl immediate... )" 49:0 49:7
do="nm"
mo="oral po" 50:6 50:7
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="kcl immediate release" 50:1 50:3
do="nm"
mo="oral po" 50:6 50:7
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="kcl immediate release" 52:2 52:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="potassium chloride" 56:4 56:5
do="20 meq" 56:8 56:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="kcl" 66:8 66:8
do="40 meq" 66:9 66:10
mo="orally" 66:11 66:11
f="nm"
du="nm"
r="k+ level" 66:1 66:2
ln="list"
28:
m="kcl" 66:8 66:8
do="40 meq" 66:9 66:10
mo="orally" 66:11 66:11
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="kcl" 70:8 70:8
do="40 meq" 70:9 70:10
mo="orally" 70:11 70:11
f="nm"
du="nm"
r="k+ level" 70:1 70:2
ln="narrative"
30:
m="kcl" 72:8 72:8
do="20 meq" 72:9 72:10
mo="orally" 72:11 72:11
f="nm"
du="nm"
r="k+ level" 72:1 72:2
ln="narrative"
31:
m="potassium chloride slow rel. ( kcl slow release )" 79:0 79:8
do="40 meq" 80:0 80:1
mo="po" 80:2 80:2
f="daily" 80:3 80:3
du="nm"
r="nm"
ln="list"
32:
m="potassium chloride" 80:7 80:8
do="20 meq" 81:1 81:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="lactulose" 82:0 82:0
do="30 milliliters" 82:1 82:2
mo="po" 82:3 82:3
f="daily prn" 82:4 82:5
du="nm"
r="constipation" 82:6 82:6
ln="list"
34:
m="ativan ( lorazepam )" 83:0 83:3
do="0.5-1 mg" 83:4 83:5
mo="iv" 83:6 83:6
f="q8h prn" 83:7 83:8
du="nm"
r="nausea" 83:9 83:9
ln="list"
35:
m="maalox-tablets quick dissolve/chewable" 85:0 85:2
do="1-2 tab" 85:3 85:4
mo="po" 85:5 85:5
f="q6h prn" 85:6 86:0
du="nm"
r="upset stomach" 86:1 86:2
ln="list"
36:
m="magnesium gluconate" 87:0 87:1
do="sliding scale" 87:2 87:3
mo="po ( orally )" 87:4 87:7
f="daily" 87:8 87:8
du="nm"
r="nm"
ln="list"
37:
m="mg gluconate" 94:12 94:13
do="3 gm" 94:10 94:11
mo="orally" 95:0 95:0
f="nm"
du="nm"
r="mg level" 94:1 94:2
ln="list"
38:
m="mg gluconate" 96:10 96:11
do="2 gm" 96:8 96:9
mo="orally" 96:12 96:12
f="nm"
du="nm"
r="mg level" 96:1 96:2
ln="list"
39:
m="mg gluconate" 97:10 97:11
do="1 gm" 97:8 97:9
mo="orally" 97:12 97:12
f="nm"
du="nm"
r="mg level" 97:1 97:2
ln="list"
40:
m="magnesium sulfate" 100:0 100:1
do="sliding scale" 100:2 100:3
mo="iv ( intravenously )" 100:4 100:7
f="daily" 100:8 100:8
du="nm"
r="nm"
ln="list"
41:
m="mg sulfate" 111:13 112:0
do="5 gm" 111:11 111:12
mo="intravenously" 112:1 112:1
f="nm"
du="nm"
r="serum mg level" 111:1 111:3
ln="list"
42:
m="mg sulfate" 113:13 114:0
do="4 gm" 113:11 113:12
mo="intravenously" 114:1 114:1
f="nm"
du="nm"
r="serum mg level" 113:1 113:3
ln="list"
43:
m="mg sulfate" 115:13 116:0
do="3 gm" 115:11 115:12
mo="intravenously" 116:1 116:1
f="nm"
du="nm"
r="serum mg level" 115:1 115:3
ln="list"
44:
m="mg sulfate" 117:13 118:0
do="2 gm" 117:11 117:12
mo="intravenously" 118:1 118:1
f="nm"
du="nm"
r="serum mg level" 117:1 117:3
ln="list"
45:
m="ms contin ( morphine controlled release )" 120:0 120:6
do="15 mg" 120:7 120:8
mo="po" 120:9 120:9
f="bid" 120:10 120:10
du="nm"
r="nm"
ln="list"
46:
m="nystatin suspension" 122:0 122:1
do="10 milliliters" 122:2 122:3
mo="po" 122:4 122:4
f="qid" 122:5 122:5
du="nm"
r="nm"
ln="list"
47:
m="chlorhexidine" 123:4 123:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
48:
m="zofran ( post-op n/v ) ( ondansetron hcl ( post-... )" 124:0 124:10
do="1 mg" 125:0 125:1
mo="iv" 125:2 125:2
f="q6h...prn" 125:3 125:3,125:7 125:7
du="x 2 doses" 125:4 125:6
r="nausea" 125:8 125:8
ln="narrative"
49:
m="oxycodone" 126:0 126:0
do="5 mg" 126:1 126:2
mo="po" 126:3 126:3
f="q6h prn" 126:4 126:5
du="nm"
r="pain" 126:6 126:6
ln="list"
50:
m="kcl ( potassium chloride )" 127:0 127:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
51:
m="kcl" 128:1 128:1
do="10 meq/hr" 128:4 128:5 128:2 128:5
mo="iv" 128:6 128:6
f="nm"
du="nm"
r="nm"
ln="list"
52:
m="kcl" 129:3 129:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="kcl" 132:1 132:1
do="10 meq/100ml/hr" 132:2 132:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="kcl" 142:8 142:8
do="10 meq" 142:9 142:10
mo="nm"
f="nm"
du="x5" 142:11 142:11
r="k+ level" 142:1 142:2
ln="list"
55:
m="kcl" 144:8 144:8
do="10 meq" 144:9 144:10
mo="nm"
f="nm"
du="x4" 144:11 144:11
r="k+ level" 144:1 144:2
ln="list"
56:
m="kcl" 146:8 146:8
do="10 meq" 146:9 146:10
mo="nm"
f="nm"
du="x3" 146:11 146:11
r="k+ level" 146:1 146:2
ln="list"
57:
m="kcl" 148:8 148:8
do="10 meq" 148:9 148:10
mo="nm"
f="nm"
du="x2" 148:11 148:11
r="k+ level" 148:1 148:2
ln="list"
58:
m="senna tablets ( sennosides )" 155:0 155:4
do="2 tab" 155:5 155:6
mo="po" 155:7 155:7
f="bid prn" 155:8 155:9
du="nm"
r="constipation" 155:10 155:10
ln="list"
59:
m="zoloft ( sertraline )" 156:0 156:3
do="25 mg" 156:4 156:5
mo="po" 156:6 156:6
f="bedtime" 156:7 156:7
du="nm"
r="nm"
ln="list"
60:
m="geodon" 160:3 160:3
do="nm"
mo="po" 160:4 160:4
f="nm"
du="nm"
r="nm"
ln="list"
61:
m="sertraline hcl" 161:2 161:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
62:
m="ziprasidone hcl" 161:5 161:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
63:
m="multivitamin therapeutic ( therapeutic multivi... )" 163:0 163:5
do="5 milliliters" 164:0 164:1
mo="po" 164:2 164:2
f="daily" 164:3 164:3
du="nm"
r="nm"
ln="list"
64:
m="vancomycin hcl" 165:0 165:1
do="1 gm" 165:2 165:3
mo="iv" 165:4 165:4
f="q12h" 165:5 165:5
du="14 days" 166:2 166:3
r="nm"
ln="list"
65:
m="compazine ( prochlorperazine )" 167:0 167:3
do="5-10 mg" 167:4 167:5
mo="po" 167:6 167:6
f="q6h prn" 167:7 167:8
du="nm"
r="nausea" 167:9 167:9
ln="list"
66:
m="ipratropium bromide" 169:3 169:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
67:
m="prochlorperazine" 170:0 170:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
68:
m="enoxaprin" 201:4 201:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="levaquin" 206:10 206:10
do="500 mg" 206:11 206:12
mo="p.o" 207:0 207:0
f="nm"
du="nm"
r="the pneumonia" 205:5 205:6
ln="narrative"
70:
m="normal saline" 208:4 208:5
do="3 liters" 208:1 208:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
71:
m="levofloxacin" 209:4 209:4
do="500 mg" 209:5 209:6
mo="iv." 209:7 209:7
f="nm"
du="nm"
r="nm"
ln="narrative"
72:
m="norepinephrine" 214:11 214:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood pressure" 213:9 213:10
ln="narrative"
73:
m="taxol." 235:4 235:4
do="nm"
mo="nm"
f="weekly" 235:3 235:3
du="nm"
r="osseous metastatic disease" 233:1 233:3
ln="narrative"
74:
m="navelbine" 238:4 238:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="bony metastatic disease." 237:2 237:4
ln="narrative"
75:
m="navelbine" 238:4 238:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
76:
m="vanco" 276:3 276:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
77:
m="vanco" 277:8 277:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
78:
m="asa" 280:3 280:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
79:
m="statin" 280:5 280:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
80:
m="ceftazidime" 289:9 289:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
81:
m="levofloxacin" 289:0 289:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
82:
m="w/vancomycin" 291:3 291:3
do="nm"
mo="nm"
f="nm"
du="x14days" 291:4 291:4
r="nm"
ln="narrative"
83:
m="ivf." 296:7 296:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
84:
m="1uprbc" 297:5 297:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
85:
m="enoxaprin" 302:5 302:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
86:
m="warfarin" 303:1 303:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
87:
m="vitamin k." 304:6 305:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="liver disease.administered" 304:4 304:5
ln="narrative"
88:
m="vitamin k." 304:6 305:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
89:
m="zoloft" 305:4 305:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
90:
m="geodon" 306:0 306:0
do="nm"
mo="nm"
f="prn." 306:1 306:1
du="nm"
r="nm"
ln="narrative"
