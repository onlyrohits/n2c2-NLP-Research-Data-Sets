1:
m="ecasa ( aspirin enteric coated )" 19:0 19:5
do="81 mg" 19:6 19:7
mo="po" 19:8 19:8
f="qd" 19:9 19:9
du="nm"
r="nm"
ln="list"
2:
m="ferrous sulfate" 21:0 21:1
do="325 mg" 21:2 21:3
mo="po" 21:4 21:4
f="tid" 21:5 21:5
du="nm"
r="nm"
ln="list"
3:
m="lasix (furosemide)" 23:0 23:3
do="60 mg" 23:4 23:5
mo="po" 23:6 23:6
f="bid" 23:7 23:7
du="nm"
r="nm"
ln="list"
4:
m="hydralazine hcl" 24:0 24:1
do="90 mg" 24:2 24:3
mo="po" 24:4 24:4
f="tid" 24:5 24:5
du="nm"
r="nm"
ln="list"
5:
m="labetalol hcl" 27:0 27:1
do="600 mg" 27:2 27:3
mo="po" 27:4 27:4
f="tid" 27:5 27:5
du="nm"
r="nm"
ln="list"
6:
m="nitroglycerin 1/150 (0.4 mg)" 30:0 30:5
do="1 tab" 30:6 30:7
mo="sl" 30:8 30:8
f="q5min x 3 prn" 30:9 31:0
du="nm"
r="chest pain" 31:1 31:2
ln="list"
7:
m="claritin (loratadine)" 32:0 32:3
do="10 mg" 32:4 32:5
mo="po" 32:6 32:6
f="qd" 32:7 32:7
du="nm"
r="nm"
ln="list"
8:
m="cozaar (losartan)" 37:0 37:3
do="100 mg" 37:4 37:5
mo="po" 37:6 37:6
f="qd" 37:7 37:7
du="number of doses required (approximate): 3" 38:0 38:7
r="nm"
ln="list"
9:
m="metformin" 39:0 39:0
do="850 mg" 39:1 39:2
mo="po" 39:3 39:3
f="bid" 39:4 39:4
du="nm"
r="nm"
ln="list"
10:
m="vytorin 10/40 ( ezetimibe 10 mg - simvastatin ...)" 40:0 40:9
do="1 tab" 41:0 41:1
mo="po" 41:2 41:2
f="qd" 41:3 41:3
du="nm"
r="nm"
ln="list"
11:
m="adenosine" 61:0 61:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="ntg" 69:11 69:11
do="nm"
mo="drip" 69:12 69:12
f="nm"
du="nm"
r="continued pain" 69:8 69:9
ln="narrative"
13:
m="heparin" 71:1 71:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="asa" 92:11 92:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="bb ( labetalol )" 92:13 93:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="heparin" 92:9 92:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="arb ( angioedema w/ace )" 93:6 93:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="ntg" 93:12 93:12
do="nm"
mo="drip" 93:13 93:13
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="O2" 93:15 93:15
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="statin" 93:4 93:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="hydralazine" 94:11 94:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="ntg" 94:7 94:7
do="nm"
mo="drip" 94:8 94:8
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="labetalol" 95:0 95:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="antihypertensives" 98:0 98:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="metformin" 101:2 101:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="novolog ssi" 101:7 101:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="bs control" 101:11 101:12
ln="narrative"
27:
m="nph" 101:5 101:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="heparin" 105:15 105:15
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="norvasc" 114:9 114:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="enalapril" 115:0 115:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="norvasc.consider" 120:4 120:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
