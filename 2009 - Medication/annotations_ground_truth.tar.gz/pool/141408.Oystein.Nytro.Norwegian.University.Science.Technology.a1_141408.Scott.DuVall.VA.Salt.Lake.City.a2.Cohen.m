1:
m="coumadin" 17:7 17:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="toprol" 30:1 30:1
do="25" 30:2 30:2
mo="p.o." 30:3 30:3
f="daily" 30:4 30:4
du="nm"
r="nm"
ln="list"
3:
m="valsartan" 31:1 31:1
do="40 mg" 31:2 31:3
mo="p.o." 31:4 31:4
f="daily" 31:5 31:5
du="nm"
r="nm"
ln="list"
4:
m="aspirin" 32:1 32:1
do="81 mg" 32:2 32:3
mo="p.o." 32:4 32:4
f="daily." 32:5 32:5
du="nm"
r="nm"
ln="list"
5:
m="plavix" 33:1 33:1
do="75 mg" 33:2 33:3
mo="p.o." 33:4 33:4
f="daily" 33:5 33:5
du="nm"
r="nm"
ln="list"
6:
m="coumadin" 34:1 34:1
do="variable dose" 34:2 34:3
mo="nm"
f="daily" 34:4 34:4
du="nm"
r="nm"
ln="list"
7:
m="lasix" 35:1 35:1
do="40 mg" 35:2 35:3
mo="p.o." 35:4 35:4
f="b.i.d." 35:5 35:5
du="nm"
r="nm"
ln="list"
8:
m="spironolactone" 36:1 36:1
do="25 mg" 36:2 36:3
mo="p.o." 36:4 36:4
f="daily." 36:5 36:5
du="nm"
r="nm"
ln="list"
9:
m="simvastatin" 37:1 37:1
do="20 mg" 37:2 37:3
mo="p.o." 37:4 37:4
f="daily" 37:5 37:5
du="nm"
r="nm"
ln="list"
10:
m="nortriptyline" 38:1 38:1
do="50 mg" 38:2 38:3
mo="p.o." 38:4 38:4
f="daily" 38:5 38:5
du="nm"
r="nm"
ln="list"
11:
m="fluoxetine" 39:1 39:1
do="20 mg" 39:2 39:3
mo="p.o." 39:4 39:4
f="daily" 39:5 39:5
du="nm"
r="nm"
ln="list"
12:
m="synthroid" 40:1 40:1
do="88 mcg" 40:2 40:3
mo="p.o." 40:4 40:4
f="daily" 40:5 40:5
du="nm"
r="nm"
ln="list"
13:
m="diuril" 60:10 60:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="lasix" 60:7 60:7
do="nm"
mo="drip" 60:8 60:8
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="antibiotics" 61:8 61:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="possible lower extremity cellulitis" 62:2 62:5
ln="narrative"
16:
m="advair" 64:3 64:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="her copd." 65:2 65:3
ln="narrative"
17:
m="steroid" 64:5 64:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="her copd." 65:2 65:3
ln="narrative"
18:
m="flagyl" 66:3 66:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia" 65:9 65:9
ln="narrative"
19:
m="levofloxacin" 66:1 66:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia" 65:9 65:9
ln="narrative"
20:
m="lasix" 67:0 67:0
do="nm"
mo="drip" 67:1 67:1
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="cardiac meds" 68:4 68:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 69:2 69:3
ln="narrative"
22:
m="coumadin" 69:0 69:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 69:2 69:3
ln="narrative"
23:
m="antibiotics" 77:6 77:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="lower extremity cellulitis" 78:0 78:2
ln="narrative"
24:
m="antibiotics" 77:6 77:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia" 78:4 78:4
ln="narrative"
25:
m="enteric-coated aspirin" 81:1 81:2
do="81 mg" 81:3 81:4
mo="p.o." 81:5 81:5
f="daily" 81:6 81:6
du="nm"
r="nm"
ln="list"
26:
m="zetia" 82:1 82:1
do="10 mg" 82:2 82:3
mo="p.o." 82:4 82:4
f="daily" 82:5 82:5
du="nm"
r="nm"
ln="list"
27:
m="fluoxetine" 83:1 83:1
do="20 mg" 83:2 83:3
mo="p.o." 83:4 83:4
f="daily" 83:5 83:5
du="nm"
r="nm"
ln="list"
28:
m="advair diskus" 84:1 84:2
do="one puff" 84:3 84:4
mo="nebulized" 84:5 84:5
f="b.i.d" 84:6 84:6
du="nm"
r="nm"
ln="list"
29:
m="lasix" 85:1 85:1
do="60 mg" 85:2 85:3
mo="p.o." 85:4 85:4
f="b.i.d." 85:5 85:5
du="nm"
r="nm"
ln="list"
30:
m="nph insulin" 86:1 86:2
do="30 units" 86:3 86:4
mo="subcutaneously" 86:5 86:5
f="q.p.m" 86:6 86:6
du="nm"
r="nm"
ln="list"
31:
m="nph insulin" 87:1 87:2
do="20 units" 87:3 87:4
mo="subcutaneously" 87:5 87:5
f="q.a.m" 87:6 87:6
du="nm"
r="nm"
ln="list"
32:
m="potassium slow release" 88:1 88:3
do="30 meq" 88:4 88:5
mo="p.o." 88:6 88:6
f="daily" 88:7 88:7
du="nm"
r="nm"
ln="list"
33:
m="levofloxacin" 89:1 89:1
do="500 mg" 89:2 89:3
mo="p.o." 89:4 89:4
f="q.24 h." 89:5 89:6
du="x4 doses" 89:7 89:8
r="nm"
ln="list"
34:
m="levothyroxine" 90:1 90:1
do="88 mcg" 90:2 90:3
mo="p.o." 90:4 90:4
f="daily" 90:5 90:5
du="nm"
r="nm"
ln="list"
35:
m="toprol-xl" 91:1 91:1
do="100 mg" 91:2 91:3
mo="p.o." 91:4 91:4
f="daily" 91:5 91:5
du="nm"
r="nm"
ln="list"
36:
m="nortriptyline" 92:1 92:1
do="50 mg" 92:2 92:3
mo="p.o." 92:4 92:4
f="nightly" 92:5 92:5
du="nm"
r="nm"
ln="list"
37:
m="prednisone taper" 93:1 93:2
do="10 mg" 94:4 94:5
mo="nm"
f="q.24 h" 94:6 94:7
du="x3 doses" 94:8 94:9
r="nm"
ln="list"
38:
m="prednisone taper" 93:1 93:2
do="20 mg" 93:10 93:11
mo="nm"
f="q.24 h." 93:12 93:13
du="x3 doses" 93:14 94:0
r="nm"
ln="list"
39:
m="prednisone taper" 93:1 93:2
do="30 mg" 93:3 93:4
mo="nm"
f="q.24 h." 93:5 93:6
du="x3 doses" 93:7 93:8
r="nm"
ln="list"
40:
m="prednisone taper" 93:1 93:2
do="5 mg" 94:12 94:13
mo="nm"
f="q.24 h." 94:14 94:15
du="x3 doses." 94:16 95:0
r="nm"
ln="list"
41:
m="prednisone taper" 93:1 93:2
do="5 mg" 94:12 94:13
mo="nm"
f="q.24 h." 94:14 94:15
du="x3 doses" 94:16 95:0
r="nm"
ln="list"
42:
m="simvastatin" 96:1 96:1
do="40 mg" 96:2 96:3
mo="p.o." 96:4 96:4
f="nightly" 96:5 96:5
du="nm"
r="nm"
ln="list"
43:
m="diovan" 97:1 97:1
do="20 mg" 97:2 97:3
mo="p.o." 97:4 97:4
f="daily" 97:5 97:5
du="nm"
r="nm"
ln="list"
44:
m="coumadin" 98:1 98:1
do="nm"
mo="nm"
f="as directed" 98:5 98:6
du="nm"
r="atrial fibrillation" 99:1 99:2
ln="list"
45:
m="coumadin" 98:1 98:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation." 99:1 99:2
ln="list"
46:
m="coumadin" 103:11 103:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
