1:
m="nitroglycerin." 19:8 19:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="chest pain" 19:2 19:3
ln="narrative"
2:
m="aspirin" 44:2 44:2
do="81 mg" 44:3 44:4
mo="p.o." 44:5 44:5
f="q. day." 44:6 44:7
du="nm"
r="nm"
ln="list"
3:
m="prilosec" 44:9 44:9
do="20 mg" 44:10 44:11
mo="p.o." 45:0 45:0
f="q. day." 45:1 45:2
du="nm"
r="nm"
ln="list"
4:
m="cyclosporine" 45:11 45:11
do="100 mg" 46:7 46:8
mo="p.o." 46:9 46:9
f="in the afternoon" 46:10 46:12
du="nm"
r="nm"
ln="list"
5:
m="cyclosporine" 45:11 45:11
do="125 mg" 46:0 46:1
mo="p.o." 46:2 46:2
f="in the morning" 46:3 46:5
du="nm"
r="nm"
ln="list"
6:
m="simvastatin" 45:4 45:4
do="40 mg" 45:5 45:6
mo="p.o." 45:7 45:7
f="q. day." 45:8 45:9
du="nm"
r="nm"
ln="list"
7:
m="atenolol" 47:11 47:11
do="75 mg" 48:0 48:1
mo="p.o." 48:2 48:2
f="q. day." 48:3 48:4
du="nm"
r="nm"
ln="list"
8:
m="insulin" 47:0 47:0
do="sliding scale." 47:1 47:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="lasix" 47:4 47:4
do="60 mg" 47:5 47:6
mo="p.o." 47:7 47:7
f="q. day." 47:8 47:9
du="nm"
r="nm"
ln="list"
10:
m="prednisone" 48:6 48:6
do="10 mg" 48:14 48:15
mo="p.o." 48:9 48:9
f="on odd days" 49:1 49:3
du="nm"
r="nm"
ln="list"
11:
m="prednisone" 48:6 48:6
do="5 mg" 48:7 48:8
mo="p.o." 48:9 48:9
f="on even days" 48:10 48:12
du="nm"
r="nm"
ln="list"
12:
m="cellcept" 49:5 49:5
do="1 , 000 mg" 49:6 49:9
mo="p.o." 49:10 49:10
f="b.i.d." 49:11 49:11
du="nm"
r="nm"
ln="list"
13:
m="prempro" 49:13 49:13
do="0.625 mg" 50:0 50:1
mo="p.o." 50:2 50:2
f="q. day." 50:3 50:4
du="nm"
r="nm"
ln="list"
14:
m="blood" 91:4 91:4
do="two units" 91:1 91:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="lopressor" 102:9 102:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="verapamil." 103:0 103:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="atenolol" 104:2 104:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="beta blockade" 104:4 104:5
ln="narrative"
18:
m="verapamil" 104:7 104:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="fluid bolus" 107:9 107:10
do="250 cc" 107:7 107:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="gemfibrozil." 113:4 113:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="simvastatin" 113:0 113:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="aspirin" 114:3 114:3
do="81 mg" 114:4 114:5
mo="p.o." 114:6 114:6
f="q. day." 114:7 114:8
du="nm"
r="nm"
ln="list"
23:
m="vitamin c" 114:10 115:0
do="100 mg" 115:1 115:2
mo="p.o." 115:3 115:3
f="q. day" 115:4 115:5
du="x14 days" 115:6 115:7
r="nm"
ln="list"
24:
m="epogen" 115:9 115:9
do="2 , 000" 116:0 116:2
mo="subcu" 116:3 116:3
f="q. week." 116:4 116:5
du="nm"
r="nm"
ln="list"
25:
m="gemfibrozil" 116:14 116:14
do="300 mg" 117:0 117:1
mo="p.o." 117:2 117:2
f="b.i.d." 117:3 117:3
du="nm"
r="nm"
ln="list"
26:
m="lasix" 116:7 116:7
do="60 mg" 116:8 116:9
mo="p.o." 116:10 116:10
f="q. day." 116:11 116:12
du="nm"
r="nm"
ln="list"
27:
m="lisinopril" 117:5 117:5
do="5 mg" 117:6 117:7
mo="p.o." 117:8 117:8
f="q. day." 117:9 117:10
du="nm"
r="nm"
ln="list"
28:
m="prilosec" 117:12 117:12
do="20 mg" 118:0 118:1
mo="p.o." 118:2 118:2
f="q. day." 118:3 118:4
du="nm"
r="nm"
ln="list"
29:
m="prednisone" 118:6 118:6
do="10 mg" 118:14 118:15
mo="p.o." 119:0 119:0
f="on odd days." 119:1 119:3
du="nm"
r="nm"
ln="list"
30:
m="prednisone" 118:6 118:6
do="5 mg" 118:7 118:8
mo="p.o." 118:9 118:9
f="on even days" 118:10 118:12
du="nm"
r="nm"
ln="list"
31:
m="mvi with minerals" 119:5 119:7
do="one tablet" 119:8 119:9
mo="p.o." 119:10 119:10
f="q. day." 119:11 119:12
du="nm"
r="nm"
ln="list"
32:
m="bicitra" 120:7 120:7
do="15 ml" 120:8 120:9
mo="p.o." 120:10 120:10
f="b.i.d." 120:11 120:11
du="nm"
r="nm"
ln="list"
33:
m="thiamine" 120:1 120:1
do="50 mg" 120:2 120:3
mo="p.o." 120:4 120:4
f="b.i.d." 120:5 120:5
du="nm"
r="nm"
ln="list"
34:
m="cyclosporine micromeral" 121:1 121:2
do="100 mg" 121:9 121:10
mo="p.o." 121:11 121:11
f="q. p.m." 121:12 122:0
du="nm"
r="nm"
ln="list"
35:
m="cyclosporine micromeral" 121:1 121:2
do="125 mg" 121:3 121:4
mo="p.o." 121:5 121:5
f="q. a.m." 121:6 121:7
du="nm"
r="nm"
ln="list"
36:
m="cellcept" 122:2 122:2
do="1 , 000 mg" 122:3 122:6
mo="p.o." 122:7 122:7
f="b.i.d." 122:8 122:8
du="nm"
r="nm"
ln="list"
37:
m="prempro" 122:10 122:10
do="0.625/0.25 mg" 122:11 123:0
mo="p.o." 123:1 123:1
f="q. day." 123:2 123:3
du="nm"
r="nm"
ln="list"
38:
m="nephrocaps" 123:5 123:5
do="one tablet" 123:6 123:7
mo="p.o." 123:8 123:8
f="q. day." 123:9 123:10
du="nm"
r="nm"
ln="list"
