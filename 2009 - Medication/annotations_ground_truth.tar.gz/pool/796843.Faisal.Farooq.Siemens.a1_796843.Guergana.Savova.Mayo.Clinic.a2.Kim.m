1:
m="adriamycin" 9:1 9:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="increased shortness of breath" 9:9 10:1
ln="narrative"
2:
m="adriamycin" 9:1 9:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="left pleural effusion." 10:3 10:5
ln="narrative"
3:
m="adriamycin" 17:3 17:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="captopril" 18:4 18:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="coumadin" 18:6 18:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="digoxin" 18:0 18:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="lasix" 18:2 18:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="lasix" 24:8 24:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="left-sided heart failure." 24:0 24:2
ln="narrative"
9:
m="lasix" 24:8 24:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="mild cough" 22:8 22:9
ln="narrative"
10:
m="amoxicillin" 25:6 25:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="digoxin" 25:0 25:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="left-sided heart failure." 24:0 24:2
ln="narrative"
12:
m="ancef" 31:7 31:7
do="nm"
mo="nm"
f="nm"
du="for approximately 7 days" 31:8 32:2
r="transudative effusion" 30:2 30:3
ln="narrative"
13:
m="capoten" 47:13 47:13
do="50 mg" 47:14 48:0
mo="nm"
f="t.i.d." 48:1 48:1
du="nm"
r="nm"
ln="list"
14:
m="digoxin" 47:1 47:1
do="0.25 mg" 47:2 47:3
mo="nm"
f="q day " 47:4 47:5
du="nm"
r="nm"
ln="list"
15:
m="lasix" 47:7 47:7
do="80 mg" 47:8 47:9
mo="nm"
f="q day " 47:10 47:11
du="nm"
r="nm"
ln="list"
16:
m="aspirin" 48:3 48:3
do="one" 48:4 48:4
mo="nm"
f="per day" 48:5 48:6
du="nm"
r="nm"
ln="list"
17:
m="synthroid" 48:8 48:8
do="2 gr." 48:9 48:10
mo="nm"
f="per day" 48:11 48:12
du="nm"
r="nm"
ln="list"
18:
m="tamoxifen" 48:14 48:14
do="10 mg" 49:0 49:1
mo="nm"
f="b.i.d." 49:2 49:2
du="nm"
r="nm"
ln="list"
19:
m="elavil" 49:4 49:4
do="75 mg" 49:5 49:6
mo="nm"
f="q day " 49:7 49:8
du="nm"
r="nm"
ln="list"
20:
m="k-dur" 49:10 49:10
do="1" 49:11 49:11
mo="nm"
f="q day." 49:12 49:13
du="nm"
r="nm"
ln="list"
21:
m="antibiotics" 80:7 80:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="cefotaxime" 81:0 81:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="clarithromycin" 81:2 81:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="heparin" 96:10 96:10
do="nm"
mo="iv" 96:9 96:9
f="nm"
du="nm"
r="pulmonary embolus." 96:2 96:3
ln="narrative"
25:
m="coumadin" 97:9 97:9
do="nm"
mo="oral" 97:8 97:8
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="captopril" 111:6 111:6
do="50 mg" 111:7 111:8
mo="p.o." 111:9 111:9
f="t.i.d.;" 111:10 111:10
du="nm"
r="nm"
ln="list"
27:
m="elavil" 111:0 111:0
do="75 mg" 111:1 111:2
mo="p.o." 111:3 111:3
f="q h.s.;" 111:4 111:5
du="nm"
r="nm"
ln="list"
28:
m="biaxin" 112:0 112:0
do="500 mg" 112:1 112:2
mo="p.o." 112:3 112:3
f="b.i.d.;" 112:4 112:4
du="nm"
r="nm"
ln="list"
29:
m="digoxin" 112:5 112:5
do="0.125 mg" 112:6 112:7
mo="alternating with 0.25 mg" 112:8 113:0
f="q day;" 113:1 113:2
du="nm"
r="nm"
ln="list"
30:
m="digoxin" 112:5 112:5
do="0.125 mg alternating with 0.25 mg" 112:6 113:0
mo="nm"
f="q day" 113:1 113:2
du="nm"
r="nm"
ln="list"
31:
m="lasix" 113:3 113:3
do="80 mg" 113:4 113:5
mo="p.o." 113:6 113:6
f="b.i.d.;" 113:7 113:7
du="nm"
r="nm"
ln="list"
32:
m="tamoxifen" 113:8 113:8
do="10 mg" 113:9 113:10
mo="p.o." 113:11 113:11
f="b.i.d.;" 113:12 113:12
du="nm"
r="nm"
ln="list"
33:
m="coumadin" 114:6 114:6
do="5 mg" 114:7 114:8
mo="p.o." 114:9 114:9
f="q day;" 114:10 114:11
du="nm"
r="nm"
ln="list"
34:
m="k-dur" 114:12 114:12
do="20 mg" 114:13 114:14
mo="p.o." 115:0 115:0
f="b.i.d.;" 115:1 115:1
du="nm"
r="nm"
ln="list"
35:
m="thyroid" 114:0 114:0
do="2 grains" 114:1 114:2
mo="p.o." 114:3 114:3
f="q day;" 114:4 114:5
du="nm"
r="nm"
ln="list"
36:
m="ambien" 115:2 115:2
do="10 mg" 115:3 115:4
mo="p.o." 115:5 115:5
f="q h.s." 115:6 115:7
du="nm"
r="nm"
ln="list"
