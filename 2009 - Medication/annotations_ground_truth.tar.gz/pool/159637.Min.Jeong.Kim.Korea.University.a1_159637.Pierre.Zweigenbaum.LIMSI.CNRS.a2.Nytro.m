1:
m="ecasa ( aspirin enteric coated )" 19:0 19:5
do="325 mg" 19:6 19:7
mo="po" 19:8 19:8
f="qd" 19:9 19:9
du="nm"
r="nm"
ln="list"
2:
m="folic acid" 21:0 21:1
do="1 mg" 21:2 21:3
mo="po" 21:4 21:4
f="qd" 21:5 21:5
du="nm"
r="nm"
ln="list"
3:
m="ativan ( lorazepam )" 22:0 22:3
do="1 mg" 22:4 22:5
mo="po" 22:6 22:6
f="qhs" 22:7 22:7
du="nm"
r="nm"
ln="list"
4:
m="nitroglycerin 1/150 ( 0.4 mg )" 23:0 23:5
do="1 tab" 23:6 23:7
mo="sl" 23:8 23:8
f="q5min x 3 prn" 23:9 24:0
du="nm"
r="chest pain" 24:1 24:2
ln="list"
5:
m="darvocet n 100 ( propoxyphene nap./acetaminophen )" 25:0 25:6
do="1 tab" 26:0 26:1
mo="po" 26:2 26:2
f="q4h prn" 26:3 26:4
du="nm"
r="pain" 26:5 26:5
ln="list"
6:
m="zocor ( simvastatin )" 27:0 27:3
do="80 mg" 27:4 27:5
mo="po" 27:6 27:6
f="qhs" 27:7 27:7
du="nm"
r="nm"
ln="list"
7:
m="norvasc ( amlodipine )" 30:0 30:3
do="2.5 mg" 30:4 30:5
mo="po" 30:6 30:6
f="bid" 30:7 30:7
du="nm"
r="nm"
ln="list"
8:
m="toprol xl ( metoprolol ( sust. rel. ) )" 33:0 33:8
do="50 mg" 33:9 33:10
mo="po" 33:11 33:11
f="qd" 33:12 33:12
du="number of doses required (approximate): 3" 36:0 36:7
r="nm"
ln="list"
9:
m="altace ( ramipril )" 37:0 37:3
do="2.5 mg" 37:4 37:5
mo="po" 37:6 37:6
f="qd" 37:7 37:7
du="nm"
r="nm"
ln="list"
10:
m="potassium chloride" 39:3 39:4
do="nm"
mo="iv" 39:5 39:5
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="potassium chloride" 40:5 41:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="ramipril" 40:3 40:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="potassium chloride immed. rel." 44:3 44:6
do="nm"
mo="po" 44:7 44:7
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="potassium chloride" 46:5 47:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="ramipril" 46:3 46:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="potassium chloride" 50:3 50:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="ramipril" 51:0 51:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="potassium chloride" 52:3 52:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="ramipril" 53:0 53:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="clopidogrel" 54:0 54:0
do="75 mg" 54:1 54:2
mo="po" 54:3 54:3
f="qd" 54:4 54:4
du="nm"
r="nm"
ln="list"
21:
m="vioxx ( rofecoxib )" 55:0 55:3
do="25 mg" 55:4 55:5
mo="po" 55:6 55:6
f="bid" 55:7 55:7
du="nm"
r="nm"
ln="list"
22:
m="protonix ( pantoprazole )" 57:0 57:3
do="40 mg" 57:4 57:5
mo="po" 57:6 57:6
f="qd" 57:7 57:7
du="nm"
r="nm"
ln="list"
23:
m="tng" 95:6 95:6
do="1" 95:5 95:5
mo="sl" 95:7 95:7
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="asa" 97:9 97:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="heparin" 97:5 97:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="mso4" 97:7 97:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="tng" 97:3 97:3
do="nm"
mo="iv" 97:2 97:2
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="asa" 104:5 104:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="heparin" 104:9 104:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="plavix" 104:11 104:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="toprol" 104:7 104:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="zocor." 104:13 104:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="ccb" 119:3 119:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="htn meds" 121:3 121:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypotensive" 121:9 121:9
ln="narrative"
