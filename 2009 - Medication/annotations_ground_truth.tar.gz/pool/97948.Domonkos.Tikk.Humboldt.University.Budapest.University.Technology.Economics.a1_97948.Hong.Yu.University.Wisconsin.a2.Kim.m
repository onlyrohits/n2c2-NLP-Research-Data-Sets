1:
m="ventolin nebulizer ( albuterol nebulizer )" 19:0 19:5
do="2.5 mg" 19:6 19:7
mo="neb" 19:8 19:8
f="q4h prn" 19:9 20:0
du="nm"
r="shortness of breath" 20:1 20:3
ln="list"
2:
m="atenolol" 21:0 21:0
do="12.5 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qd" 21:4 21:4
du="nm"
r="nm"
ln="list"
3:
m="nph humulin insulin ( insulin nph human )" 22:0 22:7
do="60 units" 23:0 23:1
mo="nm"
f="qam" 23:2 23:2
du="nm"
r="nm"
ln="list"
4:
m="nph humulin insulin ( insulin nph human )" 22:0 22:7
do="60 units" 23:7 23:8
mo="sc" 23:6 23:6
f="qam" 23:9 23:9
du="nm"
r="nm"
ln="list"
5:
m="nph humulin insulin ( insulin nph human )" 22:0 22:7
do="70 units" 23:10 23:11
mo="nm"
f="qpm" 23:12 23:12
du="nm"
r="nm"
ln="list"
6:
m="nph humulin insulin ( insulin nph human )" 22:0 22:7
do="70 units" 23:3 23:4
mo="nm"
f="qpm" 23:5 23:5
du="nm"
r="nm"
ln="list"
7:
m="lisinopril" 24:0 24:0
do="5 mg" 24:1 24:2
mo="po" 24:3 24:3
f="qd" 24:4 24:4
du="nm"
r="nm"
ln="list"
8:
m="potassium chloride" 27:3 27:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="lisinopril" 28:0 28:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="zocor ( simvastatin )" 29:0 29:3
do="20 mg" 29:4 29:5
mo="po" 29:6 29:6
f="qhs" 29:7 29:7
du="nm"
r="nm"
ln="list"
11:
m="flovent ( fluticasone propionate )" 32:0 32:4
do="44 mcg" 32:5 32:6
mo="inh" 32:7 32:7
f="bid" 32:8 32:8
du="nm"
r="nm"
ln="list"
12:
m="combivent ( ipratropium and albuterol sulfate )" 33:0 33:6
do="2 puff" 34:0 34:1
mo="inh" 34:2 34:2
f="qid" 34:3 34:3
du="nm"
r="nm"
ln="list"
13:
m="-beta blocker" 72:0 72:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="-statin" 75:0 75:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="-aspirin" 76:0 76:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="lisinopril" 78:5 78:5
do="low-dose" 78:4 78:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="insulin" 82:4 82:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="nph insulin" 84:7 84:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="his sugars" 85:3 85:4
ln="narrative"
19:
m="lisinopril" 90:7 90:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="your medications" 92:9 93:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="ace inhibitor ( lisinopril )." 102:8 102:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="beta blocker ( atenolol )" 102:2 102:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="statin" 102:0 102:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
