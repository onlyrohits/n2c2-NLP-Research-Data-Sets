1:
m="normal saline" 43:3 43:4
do="500 ccs" 43:0 43:1
mo="nm"
f="nm"
du="nm"
r="blood pressure" 42:1 42:2
ln="narrative"
2:
m="stelazine." 52:1 52:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="movement disorder" 51:8 51:9
ln="narrative"
3:
m="calcium carbonate" 58:7 59:0
do="1250 mg" 59:2 59:3
mo="po" 59:4 59:4
f="tid;" 59:5 59:5
du="nm"
r="nm"
ln="narrative"
4:
m="dht" 59:11 59:11
do="0.2 mg" 59:13 59:14
mo="po" 59:15 59:15
f="qd;" 59:16 59:16
du="nm"
r="nm"
ln="narrative"
5:
m="nephrocaps" 59:6 59:6
do="1" 59:8 59:8
mo="po" 59:9 59:9
f="qd;" 59:10 59:10
du="nm"
r="nm"
ln="narrative"
6:
m="stelazine" 60:0 60:0
do="2 mg" 60:2 60:3
mo="po" 60:4 60:4
f="tid." 60:5 60:5
du="nm"
r="nm"
ln="narrative"
7:
m="nephrocaps" 112:6 112:6
do="1" 112:8 112:8
mo="po" 112:9 112:9
f="qd." 113:0 113:0
du="nm"
r="nm"
ln="narrative"
8:
m="calcium carbonate" 113:3 113:4
do="1250 mg" 113:6 113:7
mo="po" 113:8 113:8
f="tid." 113:9 113:9
du="nm"
r="nm"
ln="narrative"
9:
m="dht" 113:12 113:12
do="0.2 mg" 113:14 113:15
mo="po" 113:16 113:16
f="qd." 113:17 113:17
du="nm"
r="nm"
ln="narrative"
10:
m="stelazine" 114:2 114:2
do="2 mg" 114:4 114:5
mo="po" 114:6 114:6
f="tid." 114:7 114:7
du="nm"
r="nm"
ln="narrative"
