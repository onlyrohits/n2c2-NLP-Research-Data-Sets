1:
m="levatol" 27:6 27:6
do="30 mg" 27:7 27:8
mo="p.o." 27:9 27:9
f="q.d." 28:0 28:0
du="nm"
r="nm"
ln="list"
2:
m="colchicine" 28:9 28:9
do="0.6 mg" 28:10 28:11
mo="p.o." 28:12 28:12
f="q.d." 28:13 28:13
du="nm"
r="nm"
ln="list"
3:
m="procardia xl" 28:2 28:3
do="30 mg" 28:4 28:5
mo="p.o." 28:6 28:6
f="q.d." 28:7 28:7
du="nm"
r="nm"
ln="list"
4:
m="aspirin" 29:7 29:7
do="one tablet" 29:8 29:9
mo="p.o." 29:10 29:10
f="q.d." 29:11 29:11
du="nm"
r="nm"
ln="list"
5:
m="pepcid" 29:0 29:0
do="40 mg" 29:1 29:2
mo="p.o." 29:3 29:3
f="q.6h." 29:4 29:4
du="nm"
r="nm"
ln="list"
6:
m="pepcid" 45:3 45:3
do="20 mg" 45:4 45:5
mo="p.o." 45:6 45:6
f="b.i.d." 45:7 45:7
du="nm"
r="nm"
ln="list"
7:
m="levatol" 46:7 46:7
do="10 mg" 46:8 46:9
mo="p.o." 46:10 46:10
f="q.d." 47:0 47:0
du="nm"
r="nm"
ln="list"
8:
m="procardia xl" 46:0 46:1
do="30 mg" 46:2 46:3
mo="p.o." 46:4 46:4
f="q.d." 46:5 46:5
du="nm"
r="nm"
ln="list"
9:
m="ciprofloxacin." 47:5 47:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="colchicine" 47:2 47:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
