1:
m="adalat" 29:1 29:1
do="200 mg" 29:2 29:3
mo="p.o." 29:4 29:4
f="b.i.d." 29:5 29:5
du="nm"
r="nm"
ln="list"
2:
m="zantac" 29:7 29:7
do="150 mg" 29:8 29:9
mo="p.o." 29:10 29:10
f="b.i.d." 29:11 29:11
du="nm"
r="nm"
ln="list"
3:
m="magnesium oxide" 30:0 30:1
do="40 mg" 30:2 30:3
mo="nm"
f="t.i.d." 30:4 30:4
du="nm"
r="nm"
ln="list"
4:
m="ultram" 30:6 30:6
do="300 mg" 30:7 30:8
mo="nm"
f="q.d." 30:9 30:9
du="nm"
r="nm"
ln="list"
5:
m="aspirin" 31:10 31:10
do="81 mg" 31:11 31:12
mo="nm"
f="q.d." 31:13 31:13
du="nm"
r="nm"
ln="list"
6:
m="azmacort" 31:5 31:5
do="80 mg" 31:6 31:7
mo="nm"
f="p.r.n." 31:8 31:8
du="nm"
r="nm"
ln="list"
7:
m="trazodone" 31:0 31:0
do="100 mg" 31:1 31:2
mo="nm"
f="q.h.s." 31:3 31:3
du="nm"
r="nm"
ln="list"
8:
m="calcium chloride pills" 32:9 32:11
do="nm"
mo="nm"
f="q.d." 32:12 32:12
du="nm"
r="nm"
ln="list"
9:
m="dyazide" 32:0 32:0
do="25 mg" 32:1 32:2
mo="nm"
f="q.d." 32:3 32:3
du="nm"
r="nm"
ln="list"
10:
m="nose spray" 32:5 32:6
do="nm"
mo="nm"
f="b.i.d." 32:7 32:7
du="nm"
r="nm"
ln="list"
11:
m="colchicine" 33:0 33:0
do="600 mg" 33:1 33:2
mo="nm"
f="q.d." 33:3 33:3
du="nm"
r="nm"
ln="list"
12:
m="cyproheptadine hydrochloride" 33:5 33:6
do="4 mg" 33:7 33:8
mo="nm"
f="b.i.d. q.h.s." 33:9 34:0
du="nm"
r="nm"
ln="list"
13:
m="anticholesterol med." 34:2 34:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="diltiazem" 59:1 59:1
do="nm"
mo="iv" 59:2 59:2
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="diltiazem" 59:8 59:8
do="nm"
mo="p.o." 59:7 59:7
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="lasix" 62:1 62:1
do="40" 62:2 62:2
mo="nm"
f="q.d." 62:3 62:3
du="nm"
r="nm"
ln="narrative"
17:
m="pain medications" 63:3 63:4
do="nm"
mo="p.o." 63:2 63:2
f="nm"
du="nm"
r="patient's pain" 62:7 62:8
ln="narrative"
18:
m="percocet" 63:6 63:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="the patient's pain" 62:6 62:8
ln="narrative"
19:
m="albuterol nebulizers" 72:2 72:3
do="250 mg" 72:4 72:5
mo="nm"
f="q.4h." 72:6 72:6
du="nm"
r="nm"
ln="list"
20:
m="allopurinol" 73:0 73:0
do="300 mg" 73:1 73:2
mo="nm"
f="q.d." 73:3 73:3
du="nm"
r="nm"
ln="list"
21:
m="colchicine" 73:5 73:5
do="0.6 mg" 73:6 73:7
mo="nm"
f="q.d." 74:0 74:0
du="nm"
r="nm"
ln="list"
22:
m="cyproheptadine hydrochloride" 74:2 74:3
do="400 mg" 74:6 74:7
mo="by mouth" 74:4 74:5
f="q.d." 74:8 74:8
du="nm"
r="nm"
ln="list"
23:
m="digoxin" 74:10 74:10
do="0.125 mg" 75:0 75:1
mo="nm"
f="q.d." 75:2 75:2
du="nm"
r="nm"
ln="list"
24:
m="colace" 75:9 75:9
do="100 mg" 75:10 75:11
mo="nm"
f="t.i.d." 75:12 75:12
du="nm"
r="nm"
ln="list"
25:
m="diltiazem" 75:4 75:4
do="30 mg" 75:5 75:6
mo="nm"
f="t.i.d." 75:7 75:7
du="nm"
r="nm"
ln="list"
26:
m="lasix" 75:14 75:14
do="40 mg" 76:0 76:1
mo="p.o." 76:2 76:2
f="q.d." 76:3 76:3
du="nm"
r="nm"
ln="list"
27:
m="dilantin" 76:12 76:12
do="200 mg" 77:0 77:1
mo="p.o." 77:2 77:2
f="b.i.d." 77:3 77:3
du="nm"
r="nm"
ln="list"
28:
m="percocet" 76:5 76:5
do="1-2 tablets" 76:6 76:7
mo="p.o." 76:8 76:8
f="q.4h. p.r.n." 76:9 76:10
du="nm"
r="nm"
ln="list"
29:
m="trazodone" 77:5 77:5
do="100 mg" 77:6 77:7
mo="p.o." 77:8 77:8
f="q.h.s." 77:9 77:9
du="nm"
r="nm"
ln="list"
