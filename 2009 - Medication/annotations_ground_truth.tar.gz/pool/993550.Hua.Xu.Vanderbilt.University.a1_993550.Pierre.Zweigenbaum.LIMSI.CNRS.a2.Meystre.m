1:
m="acetylsalicylic acid" 19:0 19:1
do="325 mg" 19:2 19:3
mo="po" 19:4 19:4
f="daily" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 22:3 22:3
do="nm"
mo="po" 22:4 22:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 23:3 23:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 23:5 23:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="allopurinol" 25:0 25:0
do="100 mg" 25:1 25:2
mo="po" 25:3 25:3
f="daily" 25:4 25:4
du="nm"
r="nm"
ln="list"
6:
m="allopurinol" 28:4 28:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="warfarin" 28:2 28:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="tessalon perles ( benzonatate )" 30:0 30:4
do="100 mg" 30:5 30:6
mo="po" 30:7 30:7
f="tid prn" 30:8 31:0
du="nm"
r="other:cough" 31:1 31:1
ln="list"
9:
m="colace ( docusate sodium )" 32:0 32:4
do="100 mg" 32:5 32:6
mo="po" 32:7 32:7
f="bid" 32:8 32:8
du="nm"
r="nm"
ln="list"
10:
m="nexium ( esomeprazole )" 33:0 33:3
do="20 mg" 33:4 33:5
mo="po" 33:6 33:6
f="daily" 33:7 33:7
du="nm"
r="nm"
ln="list"
11:
m="ferrous sulfate" 34:0 34:1
do="325 mg" 34:2 34:3
mo="po" 34:4 34:4
f="tid" 34:5 34:5
du="nm"
r="nm"
ln="list"
12:
m="glipizide" 36:0 36:0
do="5 mg" 36:1 36:2
mo="po" 36:3 36:3
f="bid" 36:4 36:4
du="nm"
r="nm"
ln="list"
13:
m="guiatuss ( guaifenesin )" 37:0 37:3
do="10 milliliters" 37:4 37:5
mo="po" 37:6 37:6
f="q4h prn" 37:7 38:0
du="nm"
r="other:cough" 38:1 38:1
ln="list"
14:
m="kcl slow release" 39:0 39:2
do="20 meq" 39:3 39:4
mo="po" 39:5 39:5
f="bid" 39:6 39:6
du="nm"
r="nm"
ln="list"
15:
m="levoxyl ( levothyroxine sodium )" 42:0 42:4
do="100 mcg" 42:5 42:6
mo="po" 42:7 42:7
f="daily" 42:8 42:8
du="nm"
r="nm"
ln="list"
16:
m="coumadin" 45:3 45:3
do="nm"
mo="po" 45:4 45:4
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="levothyroxine sodium" 46:2 46:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="warfarin" 46:5 46:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="loperamide hcl" 48:0 48:1
do="2 mg" 48:2 48:3
mo="po" 48:4 48:4
f="q6h prn" 48:5 48:6
du="nm"
r="diarrhea" 48:7 48:7
ln="list"
20:
m="ativan ( lorazepam )" 49:0 49:3
do="0.5 mg" 49:4 49:5
mo="po" 49:6 49:6
f="daily prn" 49:7 49:8
du="nm"
r="anxiety" 49:9 49:9
ln="list"
21:
m="metolazone" 50:0 50:0
do="2.5 mg" 50:1 50:2
mo="po" 50:3 50:3
f="daily...prn" 50:4 50:4,51:0 51:0
du="nm"
r="other:weight gain" 51:1 51:2
ln="list"
22:
m="toprol xl ( metoprolol succinate extended release )" 52:0 52:7
do="100 mg" 53:0 53:1
mo="po" 53:2 53:2
f="daily" 53:3 53:3
du="nm"
r="nm"
ln="list"
23:
m="pravachol ( pravastatin )" 55:0 55:3
do="40 mg" 55:4 55:5
mo="po" 55:6 55:6
f="bedtime" 55:7 55:7
du="nm"
r="nm"
ln="list"
24:
m="simvastatin" 56:5 56:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="niacin" 62:3 62:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="vit. b-3" 62:5 62:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="pravastatin sodium" 63:0 63:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="multivitamin therapeutic ( therapeutic multivi... )" 64:0 64:5
do="1 tab" 65:0 65:1
mo="po" 65:2 65:2
f="daily" 65:3 65:3
du="nm"
r="nm"
ln="list"
29:
m="pravachol" 68:3 68:3
do="nm"
mo="po" 68:4 68:4
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="niacin" 69:3 69:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="vit. b-3" 69:5 69:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="pravastatin sodium" 70:0 70:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="simvastatin" 73:3 73:3
do="nm"
mo="po" 73:4 73:4
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="niacin" 74:3 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="vit. b-3" 74:5 74:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="simvastatin" 75:0 75:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="torsemide" 76:0 76:0
do="20 mg" 76:1 76:2
mo="po" 76:3 76:3
f="bid" 76:4 76:4
du="nm"
r="nm"
ln="list"
38:
m="coumadin ( warfarin sodium )" 77:0 77:4
do="1 mg" 77:5 77:6
mo="po" 77:7 77:7
f="qpm" 77:8 77:8
du="nm"
r="nm"
ln="list"
39:
m="aspirin" 82:3 82:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="warfarin" 82:5 82:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="allopurinol" 83:2 83:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="warfarin" 83:4 83:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
43:
m="levothyroxine sodium" 84:2 84:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
44:
m="warfarin" 84:5 84:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
45:
m="pravastatin sodium" 85:3 85:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
46:
m="warfarin" 86:0 86:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
47:
m="levofloxacin" 87:3 87:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
48:
m="warfarin" 87:5 87:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
49:
m="levofloxacin" 88:3 88:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
50:
m="warfarin" 88:5 88:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
51:
m="medications" 115:5 115:5
do="nm"
mo="iv" 115:4 115:4
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="metolazone" 128:4 128:4
do="2.5mg" 128:5 128:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="torsamide" 128:7 128:7
do="40mg" 128:8 128:8
mo="nm"
f="x1" 128:9 128:9
du="nm"
r="nm"
ln="narrative"
54:
m="lasix" 136:5 136:5
do="o2 and 40" 136:2 136:4
mo="iv" 136:6 136:6
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="asa ( acetylsalicylic acid )" 139:1 139:5
do="325mg" 139:8 139:8
mo="po" 139:6 139:6
f="qd" 139:7 139:7
du="nm"
r="nm"
ln="list"
56:
m="allopurinol" 140:1 140:1
do="100 mg" 140:3 140:4
mo="po" 140:2 140:2
f="qd" 140:5 140:5
du="nm"
r="nm"
ln="list"
57:
m="docusate sodium ( colace )" 141:1 141:5
do="100 mg" 141:7 141:8
mo="po" 141:6 141:6
f="bid" 141:9 141:9
du="nm"
r="nm"
ln="list"
58:
m="esomeprazole ( nexium )" 142:1 142:4
do="20 mg" 142:6 142:7
mo="po" 142:5 142:5
f="qd" 142:8 142:8
du="nm"
r="nm"
ln="list"
59:
m="ferrous sulfate" 143:1 143:2
do="325 mg" 143:4 143:5
mo="po" 143:3 143:3
f="tid" 143:6 143:6
du="nm"
r="nm"
ln="list"
60:
m="glipizide" 144:1 144:1
do="5 mg" 144:3 144:4
mo="po" 144:2 144:2
f="bid" 144:5 144:5
du="nm"
r="nm"
ln="list"
61:
m="kcl slow release ( potassium chloride slow rel. )" 145:1 145:9
do="20 meq" 145:10 145:11
mo="nm"
f="qd" 145:12 145:12
du="nm"
r="nm"
ln="list"
62:
m="levoxyl ( levothyroxine sodium )" 146:1 146:5
do="100 mcg" 146:7 146:8
mo="po" 146:6 146:6
f="qd" 146:9 146:9
du="nm"
r="nm"
ln="list"
63:
m="lorazepam ( ativan )" 147:1 147:4
do="0.5 mg" 147:6 147:7
mo="po" 147:5 147:5
f="qd prn" 147:8 147:9
du="nm"
r="anxiety" 147:12 147:12
ln="list"
64:
m="lorazepam ( ativan )" 147:1 147:4
do="0.5 mg" 147:6 147:7
mo="po" 147:5 147:5
f="qd prn" 147:8 147:9
du="nm"
r="insomnia" 147:10 147:10
ln="list"
65:
m="metolazone" 148:1 148:1
do="2.5 mg" 148:3 148:4
mo="po" 148:2 148:2
f="qam" 148:5 148:5
du="nm"
r="nm"
ln="list"
66:
m="metoprolol succinate extended release ( toprol xl )" 149:1 149:8
do="100 mg" 149:10 149:11
mo="po" 149:9 149:9
f="qd" 149:12 149:12
du="nm"
r="nm"
ln="list"
67:
m="multivitamins ( ocuvite )" 150:1 150:4
do="1 tab" 150:6 150:7
mo="po" 150:5 150:5
f="bid" 150:8 150:8
du="nm"
r="nm"
ln="list"
68:
m="pravastatin" 151:1 151:1
do="40 mg" 151:3 151:4
mo="po" 151:2 151:2
f="qhs" 151:5 151:5
du="nm"
r="nm"
ln="list"
69:
m="torsemide" 152:1 152:1
do="20 mg" 152:3 152:4
mo="po" 152:2 152:2
f="bid" 152:5 152:5
du="nm"
r="nm"
ln="list"
70:
m="warfarin sodium ( coumadin )" 153:1 153:5
do="2 mg" 153:7 153:8
mo="po" 153:6 153:6
f="qd" 153:9 153:9
du="nm"
r="nm"
ln="list"
71:
m="asa" 178:4 178:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
72:
m="betablocker" 178:2 178:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
73:
m="statin" 178:6 178:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
74:
m="lasix" 181:0 181:0
do="nm"
mo="iv" 180:13 180:13
f="nm"
du="nm"
r="nm"
ln="narrative"
75:
m="metolazone" 181:11 181:11
do="2.5mg" 181:9 181:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
76:
m="metolazone" 182:11 182:11
do="5mg" 182:9 182:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
77:
m="torsemide." 182:3 182:3
do="60mg" 182:1 182:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
78:
m="torsemide." 183:4 183:4
do="120mg" 183:2 183:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
79:
m="metolazone" 185:9 185:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
80:
m="torsemide" 185:7 185:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
81:
m="diuretics." 186:9 186:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
82:
m="torsemide" 188:6 188:6
do="20mg" 188:7 188:7
mo="po" 188:8 188:8
f="bid." 188:9 188:9
du="nm"
r="nm"
ln="narrative"
83:
m="bblocker." 194:2 194:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="rate control" 193:11 193:12
ln="narrative"
84:
m="coumadin" 195:13 195:13
do="nm"
mo="nm"
f="nm"
du="throughout her admission" 196:2 196:4
r="nm"
ln="narrative"
85:
m="coumadin" 198:8 198:8
do="1/2" 198:5 198:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
86:
m="coumadin" 199:4 199:4
do="1mg" 199:5 199:5
mo="nm"
f="qpm." 199:6 199:6
du="nm"
r="nm"
ln="narrative"
87:
m="azithromycin" 203:6 203:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="pna." 203:0 203:0
ln="narrative"
88:
m="ceftaz" 205:4 205:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="presumed hospital aquired pna" 206:10 207:0
ln="narrative"
89:
m="levo" 205:12 205:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="presumed hospital aquired pna" 206:10 207:0
ln="narrative"
90:
m="levo" 205:6 205:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="presumed hospital aquired pna" 206:10 207:0
ln="narrative"
91:
m="levo" 206:7 206:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="presumed hospital aquired pna" 206:10 207:0
ln="narrative"
92:
m="levofloxacin" 208:7 208:7
do="500mg" 208:8 208:8
mo="nm"
f="q48h" 208:9 208:9
du="x 7 days" 208:10 208:12
r="nm"
ln="narrative"
93:
m="cefpodoxime" 209:4 209:4
do="200mg" 209:5 209:5
mo="po" 209:6 209:6
f="qd" 209:7 209:7
du="x 7 days." 209:8 209:10
r="nm"
ln="narrative"
94:
m="ceftaz" 209:1 209:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
95:
m="azithromycin" 211:6 211:6
do="nm"
mo="nm"
f="nm"
du="x 1 day." 211:7 211:9
r="nm"
ln="narrative"
96:
m="loperamide" 213:4 213:4
do="nm"
mo="nm"
f="prn" 214:0 214:0
du="nm"
r="diarrhea." 214:1 214:1
ln="narrative"
97:
m="dm rx" 215:6 215:7
do="nm"
mo="po" 215:5 215:5
f="nm"
du="nm"
r="nm"
ln="narrative"
98:
m="insulin asp" 216:4 216:5
do="ss." 216:6 216:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
99:
m="lantus" 216:2 216:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
100:
m="home...rx" 217:1 217:1,217:3 217:3
do="nm"
mo="po" 217:2 217:2
f="nm"
du="nm"
r="nm"
ln="narrative"
101:
m="levoxyl;" 218:9 218:9
do="home dose" 218:6 218:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
102:
m="allopurinol" 219:7 219:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
103:
m="antibiotics" 227:2 227:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
104:
m="levofloxacin" 228:0 228:0
do="500mg" 228:1 228:1
mo="by mouth" 228:2 228:3
f="every 48 hours" 228:4 228:6
du="for 7 days" 228:7 228:9
r="nm"
ln="list"
105:
m="cefpodoxime" 229:0 229:0
do="200mg" 229:1 229:1
mo="by moouth" 229:2 229:3
f="once daily" 229:4 229:5
du="for 7 days" 229:6 229:8
r="nm"
ln="list"
106:
m="tessalon perels" 232:0 232:1
do="100mg" 232:2 232:2
mo="by mouth" 232:3 232:4
f="three times daily as needed" 232:5 232:9
du="nm"
r="cough" 232:11 232:11
ln="list"
107:
m="guiatuss" 233:0 233:0
do="10ml" 233:1 233:1
mo="by mouth" 233:2 233:3
f="every 4 hours as needed" 233:4 233:8
du="nm"
r="cough" 233:10 233:10
ln="list"
108:
m="loperamide" 234:0 234:0
do="2mg" 234:1 234:1
mo="by mouth" 234:2 234:3
f="every 6 hours as needed" 234:4 234:8
du="nm"
r="diarrhea" 234:10 234:10
ln="list"
109:
m="coumadin:" 237:0 237:0
do="1mg" 237:12 237:12
mo="by mouth" 237:4 237:5
f="in the pm" 237:6 237:8
du="nm"
r="nm"
ln="list"
110:
m="coumadin:" 237:0 237:0
do="2mg" 237:3 237:3
mo="by mouth" 237:4 237:5
f="in the pm" 237:6 237:8
du="nm"
r="nm"
ln="list"
111:
m="coumadin." 252:5 252:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
