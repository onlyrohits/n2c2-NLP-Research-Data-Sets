1:
m="acetylsalicylic acid" 16:0 16:1
do="325 mg" 16:2 16:3
mo="po" 16:4 16:4
f="qd" 16:5 16:5
du="nm"
r="your heart" 17:2 17:3
ln="list"
2:
m="acetylsalicylic acid" 19:3 19:4
do="nm"
mo="po" 19:5 19:5
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="ciprofloxacin" 22:0 22:0
do="250 mg" 22:1 22:2
mo="po" 22:3 22:3
f="q12h" 22:4 22:4
du="x 5 days" 22:5 22:7
r="nm"
ln="list"
4:
m="antibiotics" 24:2 24:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="your urinary tract infection" 24:5 25:1
ln="list"
5:
m="iron products" 26:1 26:2
do="nm"
mo="nm"
f="a minimum of 2 hours before or after a levofloxacin or ciprofloxacin dose dose if on tube feeds , please cycle ( hold 1 hr before to 2 hr after ) take 2 hours before or 2 hours after dairy products" 26:3 29:11
du="nm"
r="nm"
ln="list"
6:
m="ciprofloxacin" 27:4 27:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="levofloxacin" 27:2 27:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="colace ( docusate sodium )" 30:0 30:4
do="100 mg" 30:5 30:6
mo="po" 30:7 30:7
f="bid" 30:8 30:8
du="nm"
r="stool softner" 31:6 31:7
ln="list"
9:
m="folate ( folic acid )" 32:0 32:4
do="1 mg" 32:5 32:6
mo="po" 32:7 32:7
f="qd" 32:8 32:8
du="nm"
r="nm"
ln="list"
10:
m="glipizide" 33:0 33:0
do="5 mg" 33:1 33:2
mo="po" 33:3 33:3
f="q12h" 33:4 33:4
du="nm"
r="your diabetes" 35:2 35:3
ln="list"
11:
m="lisinopril" 36:0 36:0
do="20 mg" 36:1 36:2
mo="po" 36:3 36:3
f="q12h" 36:4 36:4
du="nm"
r="nm"
ln="list"
12:
m="kcl immediate release" 39:3 39:5
do="nm"
mo="po" 39:6 39:6
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="lisinopril" 41:3 41:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="potassium chloride" 41:5 42:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="kcl" 45:3 45:3
do="nm"
mo="iv" 45:4 45:4
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="lisinopril" 46:3 46:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="potassium chloride" 46:5 47:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="kcl slow release" 50:3 50:5
do="nm"
mo="po" 50:6 50:6
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="lisinopril" 51:3 51:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="potassium chloride" 51:5 52:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="k-lor" 55:3 55:3
do="nm"
mo="po" 55:4 55:4
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="lisinopril" 56:3 56:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="potassium chloride" 56:5 57:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="potassium chloride" 60:3 60:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="lisinopril" 61:0 61:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="niferex-150" 62:0 62:0
do="150 mg" 62:1 62:2
mo="po" 62:3 62:3
f="bid" 62:4 62:4
du="nm"
r="nm"
ln="list"
27:
m="mvi therapeutic ( therapeutic multivitamins )" 63:0 63:5
do="1 tab" 63:6 63:7
mo="po" 63:8 63:8
f="qd" 63:9 63:9
du="nm"
r="nm"
ln="list"
28:
m="atorvastatin calcium" 65:3 65:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="niacin" 66:0 66:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="vit. b-3" 66:2 66:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="toprol xl ( metoprolol succinate extended release )" 67:0 67:7
do="100 mg" 68:0 68:1
mo="po" 68:2 68:2
f="q24h" 68:3 68:3
du="nm"
r="nm"
ln="list"
32:
m="ambien ( zolpidem tartrate )" 71:0 71:4
do="10 mg" 71:5 71:6
mo="po" 71:7 71:7
f="qhs prn" 71:8 71:9
du="nm"
r="insomnia" 71:10 71:10
ln="list"
33:
m="kcl slow release" 75:0 75:2
do="20 meq" 75:3 75:4
mo="po" 75:5 75:5
f="qd" 75:6 75:6
du="nm"
r="nm"
ln="list"
34:
m="potassium chloride" 76:3 76:4
do="20 meq" 77:1 77:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="lisinopril" 78:16 78:16
do="nm"
mo="po" 78:17 78:17
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="potassium chloride" 79:3 79:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="lisinopril" 80:0 80:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="lipitor ( atorvastatin )" 81:0 81:3
do="40 mg" 81:4 81:5
mo="po" 81:6 81:6
f="qhs" 81:7 81:7
du="nm"
r="your cholesterol" 82:7 82:8
ln="list"
39:
m="mvi therapeutic" 84:3 84:4
do="nm"
mo="po" 84:5 84:5
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="atorvastatin calcium" 85:3 85:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="niacin" 86:0 86:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="vit. b-3" 86:2 86:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
43:
m="plavix ( clopidogrel )" 87:0 87:3
do="75 mg" 87:4 87:5
mo="po" 87:6 87:6
f="qd" 87:7 87:7
du="nm"
r="blood clots" 88:3 88:4
ln="list"
44:
m="candesartan" 89:0 89:0
do="16 mg" 89:1 89:2
mo="po" 89:3 89:3
f="qd" 89:4 89:4
du="nm"
r="your blood pressure" 90:2 90:4
ln="list"
45:
m="advair diskus 250/50 ( fluticasone propionate/... )" 91:0 91:6
do="1 puff" 92:0 92:1
mo="inh" 92:2 92:2
f="bid" 92:3 92:3
du="nm"
r="your breathing" 93:2 93:3
ln="list"
46:
m="lasix ( furosemide )" 94:0 94:3
do="40 mg" 94:4 94:5
mo="po" 94:6 94:6
f="bid" 94:7 94:7
du="nm"
r="leg swelling" 95:2 95:3
ln="list"
47:
m="oxycontin ( oxycodone controlled release )" 96:0 96:5
do="45 mg" 96:6 96:7
mo="po" 96:8 96:8
f="q12h" 96:9 96:9
du="nm"
r="pain" 98:2 98:2
ln="list"
48:
m="percocet" 99:0 99:0
do="1 tab" 99:1 99:2
mo="po" 99:3 99:3
f="q4-6 hours prn" 99:4 99:6
du="nm"
r="breakthrough pain" 100:2 100:3
ln="list"
49:
m="percocet" 99:0 99:0
do="1 tab" 99:1 99:2
mo="po" 99:3 99:3
f="q4-6 hours prn" 99:4 99:6
du="nm"
r="pain" 99:7 99:7
ln="list"
50:
m="oxycontin" 101:0 101:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
51:
m="albuterol inhaler" 102:0 102:1
do="2 puff" 102:2 102:3
mo="inh" 102:4 102:4
f="qid prn" 102:5 102:6
du="nm"
r="wheezing" 102:7 102:7
ln="list"
52:
m="albuterol nebulizer" 104:0 104:1
do="2.5 mg" 104:2 104:3
mo="neb" 104:4 104:4
f="q4h prn" 104:5 104:6
du="nm"
r="wheezing" 104:7 104:7
ln="list"
53:
m="metamucil sugar free ( psyllium ( metamucil ) su... )" 106:0 106:9
do="1-2 packet" 107:0 107:1
mo="po" 107:2 107:2
f="qd prn" 107:3 107:4
du="nm"
r="constipation" 107:5 107:5
ln="list"
54:
m="nitroglycerin 1/150 ( 0.4 mg )" 108:0 108:5
do="1 tab" 108:6 108:7
mo="sl" 108:8 108:8
f="q5min x 3 doses prn" 108:9 109:0
du="nm"
r="chest pain" 109:1 109:2
ln="list"
55:
m="nitro" 110:7 110:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 110:2 110:2
ln="list"
56:
m="morphine" 135:2 135:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic pain syndrome...oa" 134:6 134:8,135:6 135:6
ln="narrative"
57:
m="percocet" 135:0 135:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic pain syndrome" 134:6 134:8
ln="narrative"
58:
m="asa" 139:3 139:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="mscontin" 140:2 140:2
do="nm"
mo="nm"
f="tid." 140:3 140:3
du="nm"
r="nm"
ln="narrative"
60:
m="dilaudid" 142:7 142:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="morphine." 143:0 143:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="oxycodone" 144:11 144:11
do="25 mg" 144:9 144:10
mo="nm"
f="nm"
du="overnight" 145:0 145:0
r="nm"
ln="narrative"
63:
m="lasix" 151:3 151:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="filtration" 151:6 151:6
ln="narrative"
64:
m="lasix" 151:3 151:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="uop" 151:8 151:8
ln="narrative"
65:
m="ivf" 152:1 152:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="euvolemic state." 152:6 152:7
ln="narrative"
66:
m="acei." 153:11 153:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
67:
m="asa" 153:5 153:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
68:
m="bb" 153:9 153:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="statin" 153:7 153:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
70:
m="ivf" 154:2 154:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="uop" 154:0 154:0
ln="narrative"
71:
m="lasix." 154:4 154:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="uop" 154:0 154:0
ln="narrative"
72:
m="cipro" 155:10 155:10
do="250 mg" 155:11 155:12
mo="po" 155:13 155:13
f="nm"
du="x 7 days." 155:14 156:0
r="inflammation" 155:1 155:1
ln="narrative"
73:
m="mscontin" 158:3 158:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain control" 157:11 157:12
ln="narrative"
74:
m="ms contin" 159:10 159:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
75:
m="oxycodone." 159:0 159:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain control" 157:11 157:12
ln="narrative"
76:
m="oxycontin" 159:5 159:5
do="45 mg" 159:3 159:4
mo="po" 159:6 159:6
f="q12h" 159:7 159:7
du="nm"
r="pain control" 157:11 157:12
ln="narrative"
77:
m="aspirin" 165:9 165:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="your stent" 166:1 166:2
ln="narrative"
78:
m="plavix" 165:11 165:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="your stent" 166:1 166:2
ln="narrative"
79:
m="your medications" 165:5 165:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
80:
m="ciprrfloxacin" 166:5 166:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="your uti" 166:7 166:8
ln="narrative"
