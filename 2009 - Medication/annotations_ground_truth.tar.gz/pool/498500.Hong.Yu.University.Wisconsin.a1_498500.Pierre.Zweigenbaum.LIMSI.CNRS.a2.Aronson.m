1:
m="acetylsalicylic acid" 19:0 19:1
do="81 mg" 19:2 19:3
mo="po" 19:4 19:4
f="qd" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="amitriptyline hcl" 20:0 20:1
do="30 mg" 20:2 20:3
mo="po" 20:4 20:4
f="qhs" 20:5 20:5
du="nm"
r="nm"
ln="list"
3:
m="premarin ( conjugated estrogens )" 21:0 21:4
do="0.625 mg" 21:5 21:6
mo="po" 21:7 21:7
f="qd" 21:8 21:8
du="nm"
r="nm"
ln="list"
4:
m="flexeril ( cyclobenzaprine hcl )" 22:0 22:4
do="10 mg" 22:5 22:6
mo="po" 22:7 22:7
f="tid prn" 22:8 22:9
du="nm"
r="pain" 22:10 22:10
ln="list"
5:
m="flexeril" 25:3 25:3
do="10 mg" 25:5 25:6
mo="po" 25:4 25:4
f="tid" 25:7 25:7
du="nm"
r="nm"
ln="list"
6:
m="colace ( docusate sodium )" 29:0 29:4
do="100 mg" 29:5 29:6
mo="po" 29:7 29:7
f="bid" 29:8 29:8
du="nm"
r="nm"
ln="list"
7:
m="fluoxetine ( fluoxetine hcl )" 30:0 30:4
do="40 mg" 30:5 30:6
mo="po" 30:7 30:7
f="qd" 30:8 30:8
du="nm"
r="nm"
ln="list"
8:
m="gemfibrozil" 31:0 31:0
do="600 mg" 31:1 31:2
mo="po" 31:3 31:3
f="bid" 31:4 31:4
du="nm"
r="nm"
ln="list"
9:
m="gemfibrozil" 34:4 34:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="simvastatin" 34:2 34:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="gemfibrozil" 35:5 35:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="simvastatin" 35:3 35:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="nph humulin insulin ( insulin nph human )" 37:0 37:7
do="10 units" 37:8 37:9
mo="sc" 37:10 37:10
f="qam" 37:11 37:11
du="nm"
r="nm"
ln="list"
14:
m="nph humulin insulin ( insulin nph human )" 39:0 39:7
do="50 units" 39:8 39:9
mo="sc" 39:10 39:10
f="qhs" 39:11 39:11
du="nm"
r="nm"
ln="list"
15:
m="lorazepam" 40:0 40:0
do="1 mg" 40:1 40:2
mo="po" 40:3 40:3
f="qd" 40:4 40:4
du="nm"
r="nm"
ln="list"
16:
m="amlodipine" 41:0 41:0
do="10 mg" 41:1 41:2
mo="po" 41:3 41:3
f="qd" 41:4 41:4
du="nm"
r="nm"
ln="list"
17:
m="toprol xl ( metoprolol ( sust. rel. ) )" 43:0 43:8
do="100 mg" 43:9 43:10
mo="po" 43:11 43:11
f="qd" 43:12 43:12
du="nm"
r="nm"
ln="list"
18:
m="irbesartan" 47:0 47:0
do="300 mg" 47:1 47:2
mo="po" 47:3 47:3
f="qd" 47:4 47:4
du="number of doses required ( approximate ): 5" 48:0 48:7
r="nm"
ln="list"
19:
m="lasix ( furosemide )" 49:0 49:3
do="40 mg" 49:4 49:5
mo="po" 49:6 49:6
f="qd" 49:7 49:7
du="nm"
r="nm"
ln="list"
20:
m="lipitor ( atorvastatin )" 53:0 53:3
do="80 mg" 53:4 53:5
mo="po" 53:6 53:6
f="qd" 53:7 53:7
du="nm"
r="nm"
ln="list"
21:
m="atorvastatin calcium" 55:4 55:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="gemfibrozil" 55:2 55:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="gemfibrozil" 56:3 56:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="atorvastatin calcium" 57:0 57:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="analgesics.she" 83:1 83:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 82:4 82:4
ln="narrative"
26:
m="lasix" 86:0 86:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="ivf." 98:10 98:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="gemfibrozil." 104:3 104:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="triglycerides" 103:1 103:1
ln="narrative"
29:
m="arb" 105:8 105:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="beta blocker" 105:3 105:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="statin" 105:6 105:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="atenolol" 107:5 107:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="gemfibrozil." 107:2 107:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="toprol xl" 107:7 107:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="amlodipine." 108:1 108:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="nph" 110:0 110:0
do="nm"
mo="nm"
f="qhs" 110:1 110:1
du="nm"
r="poor glucose control" 109:3 109:5
ln="narrative"
37:
m="nph" 110:5 110:5
do="nm"
mo="nm"
f="am" 110:4 110:4
du="nm"
r="poor glucose control" 109:3 109:5
ln="narrative"
38:
m="amitryptilline" 113:1 113:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="fluoxetine." 113:3 113:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="insulin" 116:3 116:3
do="nm"
mo="nm"
f="in the morning as well as the night" 116:4 116:11
du="nm"
r="nm"
ln="narrative"
41:
m="insulin regimen." 118:11 118:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
