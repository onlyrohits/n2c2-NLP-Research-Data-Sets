1:
m="insulin nph human" 16:0 16:2
do="40 units" 16:3 16:4
mo="sc" 16:5 16:5
f="qam" 16:6 16:6
du="nm"
r="nm"
ln="list"
2:
m="insulin nph human" 17:0 17:2
do="40 units" 17:3 17:4
mo="sc" 17:5 17:5
f="qpm" 17:6 17:6
du="nm"
r="nm"
ln="list"
3:
m="insulin regular human" 18:0 18:2
do="15 units" 18:3 18:4
mo="sc" 18:5 18:5
f="qam" 18:6 18:6
du="nm"
r="nm"
ln="list"
4:
m="nph" 20:7 20:7
do="nm"
mo="nm"
f="am" 20:4 20:4
du="nm"
r="nm"
ln="list"
5:
m="insulin regular human" 22:0 22:2
do="20 units" 22:3 22:4
mo="sc" 22:5 22:5
f="qpm" 22:6 22:6
du="nm"
r="nm"
ln="list"
6:
m="insulin regular human" 23:0 23:2
do="10 units" 23:3 23:4
mo="sc" 23:5 23:5
f="ac" 23:6 23:6
du="nm"
r="nm"
ln="list"
7:
m="metformin" 25:0 25:0
do="500 mg" 25:1 25:2
mo="po" 25:3 25:3
f="bid" 25:4 25:4
du="nm"
r="nm"
ln="list"
8:
m="pepcid ac" 58:0 58:1
do="nm"
mo="nm"
f="qhs" 58:2 58:2
du="nm"
r="nm"
ln="list"
9:
m="insulin" 91:6 91:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="acidosis" 91:4 91:4
ln="narrative"
10:
m="insulin" 91:6 91:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="hyperglycemia" 91:2 91:2
ln="narrative"
11:
m="kcl" 94:5 94:5
do="20meq" 94:3 94:3
mo="nm"
f="nm"
du="until gap normalized and potassium became stable at 4." 94:13 95:6
r="nm"
ln="narrative"
12:
m="nph" 97:6 97:6
do="high levels" 97:3 97:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="regular" 97:8 97:8
do="high levels" 97:3 97:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="metformin" 98:6 98:6
do="500mg" 98:7 98:7
mo="nm"
f="bid;" 98:8 98:8
du="nm"
r="nm"
ln="narrative"
15:
m="nph" 98:11 98:11
do="40u" 98:12 98:12
mo="nm"
f="am" 98:9 98:9
du="nm"
r="nm"
ln="narrative"
16:
m="reg" 98:14 98:14
do="15u;" 98:15 98:15
mo="nm"
f="am" 98:9 98:9
du="nm"
r="nm"
ln="narrative"
17:
m="nph" 99:7 99:7
do="40u" 99:8 99:8
mo="nm"
f="pm" 99:6 99:6
du="nm"
r="nm"
ln="narrative"
18:
m="reg" 99:10 99:10
do="20u." 99:11 99:11
mo="nm"
f="pm" 99:6 99:6
du="nm"
r="nm"
ln="narrative"
19:
m="reg" 99:2 99:2
do="10u" 99:3 99:3
mo="nm"
f="lunch" 99:0 99:0
du="nm"
r="nm"
ln="narrative"
20:
m="insulin" 104:0 104:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="insulin" 111:2 111:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="metformin" 112:1 112:1
do="nm"
mo="nm"
f="once a day." 112:2 112:4
du="nm"
r="nm"
ln="narrative"
23:
m="insulin" 119:1 119:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="nph" 120:2 120:2
do="40u" 120:1 120:1
mo="nm"
f="qam:" 120:0 120:0
du="nm"
r="nm"
ln="narrative"
25:
m="reg" 120:5 120:5
do="15u" 120:4 120:4
mo="nm"
f="qam:" 120:0 120:0
du="nm"
r="nm"
ln="narrative"
26:
m="reg" 121:2 121:2
do="10u" 121:1 121:1
mo="nm"
f="@noon:" 121:0 121:0
du="nm"
r="nm"
ln="narrative"
27:
m="nph" 122:2 122:2
do="40u" 122:1 122:1
mo="nm"
f="qpm:" 122:0 122:0
du="nm"
r="nm"
ln="narrative"
28:
m="reg" 122:5 122:5
do="20u" 122:4 122:4
mo="nm"
f="qpm:" 122:0 122:0
du="nm"
r="nm"
ln="narrative"
29:
m="metformin" 123:0 123:0
do="500mg" 123:1 123:1
mo="nm"
f="bid." 123:2 123:2
du="nm"
r="nm"
ln="narrative"
30:
m="insulin" 125:1 125:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
