1:
m="lantus" 34:1 34:1
do="100 mg" 34:2 34:3
mo="nm"
f="q.p.m." 34:4 34:4
du="nm"
r="nm"
ln="list"
2:
m="humalog" 35:1 35:1
do="20 units" 35:2 35:3
mo="nm"
f="q.p.m." 35:4 35:4
du="nm"
r="nm"
ln="list"
3:
m="humalog" 36:1 36:1
do="sliding scale." 36:2 36:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="neurontin" 37:1 37:1
do="300 mg" 37:2 37:3
mo="nm"
f="t.i.d." 37:4 37:4
du="nm"
r="nm"
ln="list"
5:
m="lisinopril" 38:1 38:1
do="40 mg" 38:2 38:3
mo="nm"
f="q.d." 38:4 38:4
du="nm"
r="nm"
ln="list"
6:
m="allopurinol" 39:1 39:1
do="300 mg" 39:2 39:3
mo="nm"
f="q.d." 39:4 39:4
du="nm"
r="nm"
ln="list"
7:
m="hydrochlorothiazide" 40:1 40:1
do="25 mg" 40:2 40:3
mo="nm"
f="q.d." 40:4 40:4
du="nm"
r="nm"
ln="list"
8:
m="zocor" 41:1 41:1
do="20 mg" 41:2 41:3
mo="nm"
f="q.d." 41:4 41:4
du="nm"
r="nm"
ln="list"
9:
m="tricor" 42:1 42:1
do="50 mg" 42:2 42:3
mo="nm"
f="b.i.d." 42:4 42:4
du="nm"
r="nm"
ln="list"
10:
m="atenolol" 43:1 43:1
do="25 mg" 43:2 43:3
mo="nm"
f="q.d." 43:4 43:4
du="nm"
r="nm"
ln="list"
11:
m="atropine." 44:4 44:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="prednisolone" 44:2 44:2
do="nm"
mo="eyedrops" 44:1 44:1
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="iron supplementation." 45:5 45:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="levofloxacin" 63:8 63:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="vancomycin" 63:6 63:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="flagyl." 64:0 64:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="contrast dye" 76:5 76:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="gadolinium" 77:0 77:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="vancomycin" 93:4 93:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="resuscitation" 102:4 102:4
do="nm"
mo="iv" 102:3 102:3
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="lasix." 103:4 103:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="lantus" 108:7 108:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="kayexalate" 129:2 129:2
do="nm"
mo="nm"
f="b.i.d." 131:0 131:0
du="nm"
r="potassium" 127:4 127:4
ln="narrative"
24:
m="lisinopril" 131:6 131:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="neurontin" 131:8 131:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="vancomycin" 132:0 132:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="ferrlecit" 139:8 139:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="phoslo" 139:6 139:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="epogen 10" 140:2 140:3
do="10 , 000 units" 140:3 140:6
mo="nm"
f="q. week" 140:7 140:8
du="duration of the patient's stay" 141:7 142:1
r="nm"
ln="narrative"
30:
m="blood pressure medications" 144:9 145:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="postoperative complications" 143:5 143:6
ln="narrative"
31:
m="atenolol" 147:7 147:7
do="150 mg" 148:0 148:1
mo="nm"
f="q.d." 148:2 148:2
du="nm"
r="blood pressure control." 146:10 147:1
ln="narrative"
32:
m="lopressor" 149:2 149:2
do="100 mg" 149:3 149:4
mo="nm"
f="b.i.d." 149:5 149:5
du="nm"
r="the patient's blood pressure" 150:0 150:3
ln="narrative"
33:
m="levofloxacin" 162:6 162:6
do="nm"
mo="nm"
f="nm"
du="for a one week course" 162:7 163:0
r="nm"
ln="narrative"
34:
m="tylenol" 175:0 175:0
do="650 to 1000 mg" 175:1 175:4
mo="p.o." 175:5 175:5
f="q.4h. p.r.n." 175:6 175:7
du="nm"
r="temperature" 175:9 175:9
ln="list"
35:
m="allopurinol" 176:3 176:3
do="100 mg" 176:4 176:5
mo="p.o." 176:6 176:6
f="q.d." 176:7 176:7
du="nm"
r="nm"
ln="list"
36:
m="enteric-coated aspirin" 176:9 176:10
do="81 mg" 176:11 177:0
mo="p.o." 177:1 177:1
f="q.d." 177:2 177:2
du="nm"
r="nm"
ln="list"
37:
m="lopressor" 177:4 177:4
do="100 mg" 177:5 177:6
mo="p.o." 177:7 177:7
f="b.i.d." 177:8 177:8
du="nm"
r="nm"
ln="list"
38:
m="phoslo" 177:10 177:10
do="1334 mg" 177:11 177:12
mo="p.o." 177:13 177:13
f="q.a.c....with meals" 178:0 178:0,178:4 178:5
du="nm"
r="nm"
ln="list"
39:
m="colace" 178:7 178:7
do="100 mg" 178:8 178:9
mo="p.o." 178:10 178:10
f="b.i.d." 178:11 178:11
du="nm"
r="nm"
ln="list"
40:
m="epogen" 178:13 178:13
do="10 , 000 units" 179:0 179:3
mo="subcuticularly" 179:5 179:5
f="q. week starting on monday" 179:6 179:10
du="nm"
r="nm"
ln="list"
41:
m="iron" 181:6 181:6
do="325 mg" 181:7 181:8
mo="p.o." 181:9 181:9
f="t.i.d." 181:10 181:10
du="nm"
r="nm"
ln="list"
42:
m="percocet" 181:12 181:12
do="1 to 2 tablets" 181:13 182:2
mo="p.o." 182:3 182:3
f="q.4h. p.r.n." 182:4 182:5
du="nm"
r="pain" 182:6 182:6
ln="list"
43:
m="prednisolone 1%" 182:8 182:9
do="one drop" 182:10 182:11
mo="in the effected eye" 182:12 183:2
f="b.i.d." 183:3 183:3
du="nm"
r="nm"
ln="list"
44:
m="neurontin" 183:11 183:11
do="300 mg" 183:12 184:0
mo="p.o." 184:1 184:1
f="b.i.d." 184:2 184:2
du="nm"
r="nm"
ln="list"
45:
m="zocor" 183:5 183:5
do="20 mg" 183:6 183:7
mo="p.o." 183:8 183:8
f="q.h.s." 183:9 183:9
du="nm"
r="nm"
ln="list"
46:
m="atropine" 184:4 184:4
do="1 mg one drop" 184:5 184:8
mo="in the affected eye" 184:9 184:12
f="nm"
du="nm"
r="nm"
ln="list"
47:
m="levofloxacin" 185:0 185:0
do="250 mg" 185:1 185:2
mo="p.o." 185:3 185:3
f="every morning" 185:4 185:5
du="for one week" 186:2 186:4
r="nm"
ln="list"
48:
m="lispro" 186:6 186:6
do="6 units" 186:7 186:8
mo="subcuticularly" 186:9 186:9
f="q.a.c." 187:0 187:0
du="nm"
r="nm"
ln="list"
49:
m="lispro" 189:3 189:3
do="3 units" 191:9 191:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="lispro" 189:3 189:3
do="sliding scale" 189:4 189:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
51:
m="lispro" 189:3 189:3
do="two units" 190:6 190:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="tricor" 194:12 194:12
do="54 mg" 194:13 195:0
mo="p.o." 195:1 195:1
f="q.d." 195:2 195:2
du="nm"
r="nm"
ln="list"
53:
m="duoneb" 195:11 195:11
do="3/0.5 mg" 195:12 196:0
mo="nebulizer" 196:1 196:1
f="q.6h. p.r.n." 196:2 196:3
du="nm"
r="wheezing." 196:4 196:4
ln="list"
54:
m="lantus" 195:4 195:4
do="25 units" 195:5 195:6
mo="subcutaneous" 195:7 195:7
f="q.d." 195:8 195:8
du="nm"
r="nm"
ln="list"
