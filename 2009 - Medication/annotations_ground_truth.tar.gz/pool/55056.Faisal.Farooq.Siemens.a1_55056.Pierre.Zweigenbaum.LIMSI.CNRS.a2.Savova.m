1:
m="lovenox/integrilin" 4:21 4:21
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="ecasa ( aspirin enteric coated )" 17:0 17:5
do="325 mg" 17:6 17:7
mo="po " 17:8 17:8
f="qd " 17:9 17:9
du="nm"
r="nm"
ln="list"
3:
m="micronase ( glyburide )" 18:0 18:3
do="5 mg" 18:4 18:5
mo="po" 18:6 18:6
f="qd" 18:7 18:7
du="nm"
r="nm"
ln="list"
4:
m="hctz ( hydrochlorothiazide )" 19:0 19:3
do="25 mg" 19:4 19:5
mo="po" 19:6 19:6
f="qd" 19:7 19:7
du="nm"
r="nm"
ln="list"
5:
m="nitroglycerin 1/150 ( 0.4 mg )" 20:0 20:5
do="1 tab" 20:6 20:7
mo="sl" 20:8 20:8
f="q5min x 3 prn" 20:9 21:0
du="nm"
r="chest pain" 21:1 21:2
ln="list"
6:
m="zocor ( simvastatin )" 22:0 22:3
do="20 mg" 22:4 22:5
mo="po" 22:6 22:6
f="qhs" 22:7 22:7
du="nm"
r="nm"
ln="list"
7:
m="levofloxacin" 25:0 25:0
do="250 mg" 25:1 25:2
mo="po" 25:3 25:3
f="qd" 25:4 25:4
du="x 4 days" 25:5 25:7
r="nm"
ln="list"
8:
m="zestril ( lisinopril )" 29:0 29:3
do="20 mg" 29:4 29:5
mo="po" 29:6 29:6
f="qd" 29:7 29:7
du="nm"
r="nm"
ln="list"
9:
m="potassium chloride" 31:3 31:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="lisinopril" 32:0 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="potassium chloride" 33:3 33:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="lisinopril" 34:0 34:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="atenolol" 35:0 35:0
do="50 mg" 35:1 35:2
mo="po" 35:3 35:3
f="qd...with meals" 35:4 35:4,36:2 36:3
du="nm"
r="nm"
ln="list"
14:
m="prilosec ( omeprazole )" 37:0 37:3
do="20 mg" 37:4 37:5
mo="po" 37:6 37:6
f="qd" 37:7 37:7
du="nm"
r="nm"
ln="list"
15:
m="hydrochlorothiazide" 39:3 39:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="omeprazole" 40:0 40:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="hydrochlorothiazide" 41:3 41:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="omeprazole" 42:0 42:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="lovenox/integrilin" 51:8 51:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="lovenox/integrilin" 57:5 57:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="ntp." 72:4 72:4
do="2" 72:3 72:3
mo="nm"
f="nm"
du="nm"
r="pain" 71:7 71:7
ln="narrative"
22:
m="slng" 72:0 72:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 71:7 71:7
ln="narrative"
23:
m="heparin" 74:1 74:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nste mi" 74:5 74:6
ln="narrative"
24:
m="integrelin" 74:3 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nste mi" 74:5 74:6
ln="narrative"
25:
m="acei" 75:4 75:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="asa" 75:0 75:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="bb" 75:2 75:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="statin." 75:6 75:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="asa" 84:5 84:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="aceinh" 85:2 85:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="bb" 85:0 85:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="heparin" 85:6 85:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="integrilin." 85:8 85:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="statin" 85:4 85:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="heparin" 88:3 88:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="lovenox/integrilin" 88:5 88:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="integ/hep" 89:8 89:8
do="nm"
mo="nm"
f="nm"
du="for total of 72 hr course" 89:2 89:7
r="nm"
ln="narrative"
38:
m="bp meds" 90:9 90:10
do="titrating" 90:8 90:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="hctz" 91:11 91:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="bp control" 91:13 92:0
ln="narrative"
40:
m="ii--czi" 99:3 99:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="dm" 99:2 99:2
ln="list"
41:
m="micronase." 99:7 99:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="colace" 100:4 100:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="nexium " 100:2 100:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="levoflox" 101:5 101:5
do="nm"
mo="nm"
f="nm"
du="x 7 days." 101:6 101:8
r="uti--rx." 101:4 101:4
ln="narrative"
45:
m="lovenox." 102:4 102:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="dvt proph:" 102:1 102:2
ln="narrative"
46:
m="lovenox/integrilin" 105:0 105:0
do="nm"
mo="nm"
f="nm"
du="72 hr course" 104:8 104:10
r="rx. nste mi." 105:3 105:5
ln="narrative"
47:
m="hctz" 106:6 106:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="nexium" 106:8 106:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="lgib history" 106:10 106:11
ln="narrative"
49:
m="slng" 106:14 106:14
do="nm"
mo="nm"
f="prn" 106:15 106:15
du="nm"
r="nm"
ln="list"
50:
m="levoflox" 107:0 107:0
do="nm"
mo="nm"
f="nm"
du="x 4 more days." 107:1 107:4
r="nm"
ln="narrative"
51:
m="antibiotic" 113:6 113:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="a urinary tract infection" 113:11 114:1
ln="narrative"
52:
m="hctz" 113:1 113:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="levofloxacin" 113:8 113:8
do="nm"
mo="nm"
f="nm"
du="for 4 more days" 114:6 114:9
r="a urinary tract infection" 113:11 114:1
ln="narrative"
