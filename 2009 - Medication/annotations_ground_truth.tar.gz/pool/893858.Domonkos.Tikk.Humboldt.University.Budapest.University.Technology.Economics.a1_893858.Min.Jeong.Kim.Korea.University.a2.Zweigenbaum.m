1:
m="digoxin" 12:9 12:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="lasix" 12:7 12:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="ace inhibitor" 13:2 13:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="digoxin" 34:6 34:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="enalapril" 34:4 34:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="lasix" 34:2 34:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="anti-ischemic regimen." 65:3 65:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 64:3 64:3
ln="narrative"
8:
m="anti-inflammatory regimen" 68:4 68:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="her pericarditis." 68:8 69:0
ln="narrative"
9:
m="indocin" 69:5 69:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="the chest pain" 69:9 69:11
ln="narrative"
10:
m="aspirin" 72:8 72:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="bactrim" 72:10 72:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="enalapril" 72:12 72:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="indocin" 72:0 72:0
do="50 milligrams" 72:1 72:2
mo="nm"
f="3 times a day" 72:3 72:6
du="nm"
r="nm"
ln="narrative"
14:
m="carafate" 73:1 73:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="aspirin" 79:2 79:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="indocin" 79:4 79:4
do="50 milligrams" 79:5 79:6
mo="by mouth" 79:7 80:0
f="3 times a day" 80:1 80:4
du="nm"
r="nm"
ln="list"
17:
m="enalapril" 80:6 80:6
do="10 milligrams" 80:7 80:8
mo="by mouth" 80:9 80:10
f="each day" 80:11 80:12
du="nm"
r="nm"
ln="narrative"
18:
m="carafate" 81:0 81:0
do="1 gram" 81:1 81:2
mo="by mouth" 81:3 81:4
f="4 times a day." 81:5 81:8
du="nm"
r="nm"
ln="narrative"
