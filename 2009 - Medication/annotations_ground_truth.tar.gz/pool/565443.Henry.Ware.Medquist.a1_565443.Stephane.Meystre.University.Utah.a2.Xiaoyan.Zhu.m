1:
m="acetylsalicylic acid" 14:0 14:1
do="325 mg" 14:2 14:3
mo="po" 14:4 14:4
f="qd" 14:5 14:5
du="nm"
r="nm"
ln="list"
2:
m="atenolol" 15:0 15:0
do="50 mg" 15:1 15:2
mo="po" 15:3 15:3
f="qd" 15:4 15:4
du="nm"
r="nm"
ln="list"
3:
m="atorvastatin" 17:0 17:0
do="40 mg" 17:1 17:2
mo="po" 17:3 17:3
f="qd" 17:4 17:4
du="nm"
r="nm"
ln="list"
4:
m="hydrochlorothiazide" 18:0 18:0
do="25 mg" 18:1 18:2
mo="po" 18:3 18:3
f="qd" 18:4 18:4
du="nm"
r="nm"
ln="list"
5:
m="amlodipine" 19:0 19:0
do="10 mg" 19:1 19:2
mo="po" 19:3 19:3
f="qd" 19:4 19:4
du="nm"
r="nm"
ln="list"
6:
m="folate ( folic acid )" 21:0 21:4
do="1 mg" 21:5 21:6
mo="po" 21:7 21:7
f="qd" 21:8 21:8
du="nm"
r="nm"
ln="list"
7:
m="amlodipine" 53:6 53:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="amlodipine" 67:8 67:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="asa" 67:1 67:1
do="81" 67:2 67:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="atenolol" 67:6 67:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="atorvastatin" 67:10 67:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="hctz" 67:4 67:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="loratadine" 67:12 67:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="albuterol" 68:0 68:0
do="nm"
mo="nm"
f="prn" 67:14 67:14
du="nm"
r="nm"
ln="narrative"
15:
m="atenolol" 103:5 103:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="aspirin" 104:1 104:1
do="325 mg" 104:2 104:3
mo="nm"
f="qd" 104:4 104:4
du="nm"
r="heart prophylaxis." 104:8 104:9
ln="narrative"
17:
m="aspirin" 104:1 104:1
do="325 mg" 104:2 104:3
mo="nm"
f="qd" 104:4 104:4
du="nm"
r="stroke" 104:6 104:6
ln="narrative"
18:
m="atorvastatin" 111:9 111:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="folic acid" 112:4 112:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="aspirin" 117:8 117:8
do="325 mg" 117:10 117:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="folate supplementation." 118:0 118:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="atorvastatin ( lipitor )" 119:0 119:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="cholesterol" 119:10 119:10
ln="narrative"
23:
m="atorvastatin ( lipitor )" 119:0 119:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="ldl" 119:12 119:12
ln="narrative"
