1:
m="darvocet" 20:4 20:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="his pain" 20:1 20:2
ln="narrative"
2:
m="tordal" 20:9 20:9
do="15 to 30 mg" 21:0 21:3
mo="intramuscular" 20:8 20:8
f="four times a day." 21:4 21:7
du="nm"
r="his pain" 20:1 20:2
ln="narrative"
3:
m="nph humulin" 24:6 24:7
do="32 units" 24:3 24:4
mo="nm"
f="nm"
du="nm"
r="insulin dependent diabetes" 23:4 23:6
ln="narrative"
4:
m="nph insulin" 33:7 33:8
do="32 units" 34:0 34:1
mo="nm"
f="every morning" 34:2 34:3
du="nm"
r="nm"
ln="list"
5:
m="lotensin" 34:11 34:11
do="40 mg" 34:12 34:13
mo="p.o." 35:0 35:0
f="q.d." 35:1 35:1
du="nm"
r="nm"
ln="list"
6:
m="procardia xl" 34:5 34:6
do="90 mg" 34:7 34:8
mo="nm"
f="q.a.m." 34:9 34:9
du="nm"
r="nm"
ln="list"
7:
m="lasix" 35:3 35:3
do="40 mg" 35:4 35:5
mo="p.o." 35:6 35:6
f="q.d." 35:7 35:7
du="nm"
r="nm"
ln="list"
8:
m="potassium supplement" 35:9 35:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="darvocet n-100" 36:7 36:8
do="one to four tablets" 36:9 37:2
mo="nm"
f="q.d." 37:3 37:3
du="nm"
r="nm"
ln="list"
10:
m="ketorolac" 36:0 36:0
do="15-30 mg" 36:1 36:2
mo="intramuscularly" 36:3 36:3
f="q.i.d." 36:4 36:4
du="nm"
r="nm"
ln="list"
11:
m="crystalloid" 84:0 84:0
do="2500 cc" 83:10 83:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="vicodan" 103:10 103:10
do="one to two" 104:0 104:2
mo="p.o." 104:3 104:3
f="q.3-4h. p.r.n." 104:4 104:5
du="nm"
r="nm"
ln="list"
13:
m="naprosyn" 104:7 104:7
do="500 mg" 104:8 104:9
mo="p.o." 104:10 104:10
f="b.i.d." 104:11 104:11
du="nm"
r="nm"
ln="list"
14:
m="halcion" 105:6 105:6
do="0.125 to 0.25 mg" 105:7 105:10
mo="p.o." 105:11 105:11
f="q.h.s. p.r.n." 105:12 106:0
du="nm"
r="nm"
ln="list"
15:
m="tordal" 105:3 105:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
