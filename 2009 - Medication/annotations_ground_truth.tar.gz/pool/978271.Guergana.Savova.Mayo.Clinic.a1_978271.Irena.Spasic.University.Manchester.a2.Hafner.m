1:
m="ecasa ( aspirin enteric coated )" 19:0 19:5
do="325 mg" 19:6 19:7
mo="po" 19:8 19:8
f="qd" 19:9 19:9
du="nm"
r="nm"
ln="list"
2:
m="zestril ( lisinopril )" 20:0 20:3
do="2.5 mg" 20:4 20:5
mo="po" 20:6 20:6
f="qd" 20:7 20:7
du="nm"
r="nm"
ln="list"
3:
m="zoloft ( sertraline )" 21:0 21:3
do="50 mg" 21:4 21:5
mo="po" 21:6 21:6
f="qd" 21:7 21:7
du="nm"
r="nm"
ln="list"
4:
m="keflex ( cephalexin )" 22:0 22:3
do="250 mg" 22:4 22:5
mo="po" 22:6 22:6
f="qid" 22:7 22:7
du="x 12 doses" 22:8 22:10
r="nm"
ln="list"
5:
m="antibiotics" 23:3 23:3
do="nm"
mo="iv" 23:2 23:2
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="aricept ( donepezil hcl )" 25:0 25:4
do="10 mg" 25:5 25:6
mo="po" 25:7 25:7
f="qpm" 25:8 25:8
du="number of doses required (approximate): 1" 26:0 26:7
r="nm"
ln="list"
7:
m="plavix ( clopidogrel )" 27:0 27:3
do="75 mg" 27:4 27:5
mo="po" 27:6 27:6
f="qd" 27:7 27:7
du="nm"
r="nm"
ln="list"
8:
m="toprol xl ( metoprolol ( sust. rel. ) )" 28:0 28:8
do="50 mg" 28:9 28:10
mo="po" 28:11 28:11
f="qd" 28:12 28:12
du="nm"
r="nm"
ln="list"
9:
m="lipitor ( atorvastatin )" 31:0 31:3
do="80 mg" 31:4 31:5
mo="po" 31:6 31:6
f="qd" 31:7 31:7
du="nm"
r="nm"
ln="list"
10:
m="glucophage ( metformin )" 32:0 32:3
do="500 mg" 32:4 32:5
mo="po" 32:6 32:6
f="qd" 32:7 32:7
du="nm"
r="nm"
ln="list"
11:
m="glyburide" 33:0 33:0
do="1.25 mg" 33:1 33:2
mo="po" 33:3 33:3
f="qd" 33:4 33:4
du="nm"
r="nm"
ln="list"
12:
m="asa" 64:13 64:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="plavix" 64:11 64:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="acei" 65:5 65:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="bb" 65:3 65:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="statin" 65:1 65:1
do="highdose" 65:0 65:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="hypoglycemics" 66:5 66:5
do="nm"
mo="oral" 66:4 66:4
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="riss." 66:11 66:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
