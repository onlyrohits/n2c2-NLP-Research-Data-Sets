1:
m="famotidine" 19:0 19:0
do="20 mg" 19:1 19:2
mo="po" 19:3 19:3
f="bid" 19:4 19:4
du="nm"
r="nm"
ln="list"
2:
m="lasix (furosemide)" 20:0 20:3
do="80 mg" 20:4 20:5
mo="po" 20:6 20:6
f="qd" 20:7 20:7
du="nm"
r="nm"
ln="list"
3:
m="motrin (ibuprofen)" 22:0 22:3
do="300 mg" 22:4 22:5
mo="po" 22:6 22:6
f="q6h" 22:7 22:7
du="nm"
r="nm"
ln="list"
4:
m="zocor (simvastatin)" 25:0 25:3
do="20 mg" 25:4 25:5
mo="po" 25:6 25:6
f="qhs" 25:7 25:7
du="nm"
r="nm"
ln="list"
5:
m="maalox-tablets quick dissolve/chewable" 28:0 28:2
do="1-2 tab" 28:3 28:4
mo="po" 28:5 28:5
f="q6h prn" 28:6 29:0
du="nm"
r="upset stomach" 29:1 29:2
ln="list"
6:
m="ecasa (aspirin enteric coated)" 30:0 30:5
do="325 mg" 30:6 30:7
mo="po" 30:8 30:8
f="qd" 30:9 30:9
du="nm"
r="nm"
ln="list"
7:
m="asa" 79:1 79:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="ntg" 79:3 79:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="bp" 79:10 79:10
ln="narrative"
9:
m="heparin bolus" 80:0 80:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="motrin" 85:8 85:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="muscular pain" 86:0 86:1
ln="narrative"
11:
m="asa" 87:0 87:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="statin" 87:2 87:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="lasix" 88:11 88:11
do="nm"
mo="nm"
f="80 qd." 88:12 88:13
du="nm"
r="nm"
ln="narrative"
14:
m="motrin" 90:2 90:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic throat pain" 90:4 90:6
ln="list"
15:
m="motrin" 90:2 90:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="l chest pain" 91:0 92:0
ln="list"
16:
m="motrin" 90:2 90:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="oa" 90:8 90:8
ln="list"
17:
m="famotidine" 92:2 92:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="colace" 93:0 93:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="nsaids" 96:7 96:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 95:10 95:10
ln="narrative"
20:
m="your medications" 100:7 100:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
