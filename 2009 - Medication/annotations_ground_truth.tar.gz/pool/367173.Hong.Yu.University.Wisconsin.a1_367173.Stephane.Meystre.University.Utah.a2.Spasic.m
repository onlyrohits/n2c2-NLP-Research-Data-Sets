1:
m="bicarb" 12:6 12:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="epi" 12:11 12:11
do="nm"
mo="drip" 12:12 12:12
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="lasix" 13:0 13:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="amio" 16:9 16:9
do="1" 16:10 16:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="dopamine" 16:6 16:6
do="16" 16:7 16:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="propofol" 16:12 16:12
do="1" 16:13 16:13
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="integrilin" 17:0 17:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="global hypokinesis" 15:0 15:1
ln="narrative"
8:
m="dobutamine." 20:9 20:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="his maps" 19:6 19:7
ln="narrative"
9:
m="dopamine" 20:2 20:2
do="max" 20:1 20:1
mo="nm"
f="nm"
du="nm"
r="his maps" 19:6 19:7
ln="narrative"
10:
m="epinephrine" 20:7 20:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="his maps" 19:6 19:7
ln="narrative"
11:
m="levophed" 20:5 20:5
do="max" 20:4 20:4
mo="nm"
f="nm"
du="nm"
r="his maps" 19:6 19:7
ln="narrative"
