1:
m="tylenol (acetaminophen)" 19:0 19:3
do="650 mg" 19:4 19:5
mo="po" 19:6 19:6
f="q6h" 19:7 19:7
du="nm"
r="nm"
ln="list"
2:
m="calcium carbonate (500 mg elemental ca++)" 20:0 20:7
do="500 mg" 20:8 20:9
mo="po" 20:10 20:10
f="tid" 20:11 20:11
du="nm"
r="nm"
ln="list"
3:
m="hydrochlorothiazide" 21:0 21:0
do="25 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qd" 21:4 21:4
du="nm"
r="nm"
ln="list"
4:
m="lisinopril" 22:0 22:0
do="20 mg" 22:1 22:2
mo="po" 22:3 22:3
f="qd" 22:4 22:4
du="nm"
r="nm"
ln="list"
5:
m="multivitamin therapeutic(therapeutic multivi...)" 23:0 23:5
do="1 tab" 24:0 24:1
mo="po" 24:2 24:2
f="qd" 24:3 24:3
du="nm"
r="nm"
ln="list"
6:
m="lipitor (atorvastatin)" 25:0 25:3
do="10 mg" 25:4 25:5
mo="po" 25:6 25:6
f="qd" 25:7 25:7
du="nm"
r="nm"
ln="list"
7:
m="niacin" 27:3 27:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="vit. b-3" 27:5 27:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="atorvastatin calcium" 28:0 28:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="ibuprofen" 44:2 44:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="tylenol" 44:0 44:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="asa" 52:4 52:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="hctz" 58:10 58:10
do="25" 58:11 58:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="lipitor" 58:13 58:13
do="10"  59:0 59:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="lisinopril" 58:7 58:7
do="20" 58:8 58:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="fosomax" 59:4 59:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="mvi" 59:2 59:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="tylenol" 71:0 71:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="ibuprofen" 81:10 81:10
do="nm"
mo="nm"
f="prn" 81:9 81:9
du="nm"
r="her pains" 80:13 80:14
ln="narrative"
20:
m="tylenol" 81:3 81:3
do="650mg" 81:4 81:4
mo="po" 81:5 81:5
f="q6hr" 81:6 81:6
du="nm"
r="her pains" 80:13 80:14
ln="narrative"
21:
m="cardiovascular medications" 84:0 84:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="bp meds" 86:3 86:4
do="titrated" 86:5 86:5
mo="nm"
f="as needed" 86:6 86:7
du="nm"
r="nm"
ln="narrative"
23:
m="tylenol" 89:4 89:4
do="nm"
mo="nm"
f="at least twice daily" 89:5 89:8
du="nm"
r="leg pain" 89:13 89:14
ln="narrative"
24:
m="tylenol" 96:1 96:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 96:3 96:3
ln="list"
25:
m="ibuprofen" 97:1 97:1
do="nm"
mo="nm"
f="as needed" 97:2 97:3
du="nm"
r="nm"
ln="narrative"
