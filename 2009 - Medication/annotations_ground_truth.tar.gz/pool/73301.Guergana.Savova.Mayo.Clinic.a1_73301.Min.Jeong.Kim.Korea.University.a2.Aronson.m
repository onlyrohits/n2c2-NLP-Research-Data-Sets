1:
m="etomidate" 34:6 34:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="levophed" 36:3 36:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="fluid" 37:13 37:13
do="1 liter" 37:9 37:10
mo="iv" 37:12 37:12
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="levophed" 37:6 37:6
do="7 to 10" 37:2 37:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="flagyl" 46:9 46:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="gentamicin" 46:7 46:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="vancomycin" 46:5 46:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="steroids" 47:2 47:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="coumadin" 52:3 52:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="right dvt" 51:10 52:0
ln="narrative"
10:
m="nph" 55:10 55:10
do="54 units" 55:11 56:0
mo="nm"
f="in the morning" 56:1 56:3
du="nm"
r="nm"
ln="list"
11:
m="nph" 55:10 55:10
do="68 units" 56:5 56:6
mo="nm"
f="in the night" 56:7 56:9
du="nm"
r="nm"
ln="list"
12:
m="regular insulin" 55:1 55:2
do="sliding scale" 55:3 55:4
mo="nm"
f="a.c." 55:5 55:5
du="nm"
r="nm"
ln="list"
13:
m="regular insulin" 55:1 55:2
do="sliding scale" 55:3 55:4
mo="nm"
f="bedtime" 55:8 55:8
du="nm"
r="nm"
ln="list"
14:
m="baclofen" 56:11 56:11
do="10 mg" 56:12 56:13
mo="nm"
f="t.i.d." 57:0 57:0
du="nm"
r="nm"
ln="list"
15:
m="amitriptyline" 57:2 57:2
do="25 mg" 57:3 57:4
mo="nm"
f="at bedtime" 57:5 57:6
du="nm"
r="nm"
ln="list"
16:
m="oxybutynin" 57:8 57:8
do="5 mg" 57:9 57:10
mo="nm"
f="t.i.d." 57:11 57:11
du="nm"
r="nm"
ln="list"
17:
m="gabapentin" 58:0 58:0
do="300 mg" 58:1 58:2
mo="nm"
f="t.i.d." 58:3 58:3
du="nm"
r="nm"
ln="list"
18:
m="iron sulfate" 58:5 58:6
do="325 mg" 58:7 58:8
mo="nm"
f="t.i.d." 58:9 58:9
du="nm"
r="nm"
ln="list"
19:
m="vitamin c" 58:11 58:12
do="500 mg" 59:0 59:1
mo="nm"
f="daily" 59:2 59:2
du="nm"
r="nm"
ln="list"
20:
m="coumadin" 59:9 59:9
do="5 mg" 59:10 59:11
mo="nm"
f="daily" 59:12 59:12
du="nm"
r="nm"
ln="list"
21:
m="magnesium" 59:4 59:4
do="420 mg" 59:5 59:6
mo="nm"
f="t.i.d." 59:7 59:7
du="nm"
r="nm"
ln="list"
22:
m="calcium" 60:6 60:6
do="950 mg" 60:7 60:8
mo="nm"
f="daily" 60:9 60:9
du="nm"
r="nm"
ln="list"
23:
m="ranitidine" 60:0 60:0
do="150 mg" 60:1 60:2
mo="nm"
f="b.i.d." 60:3 60:3
du="nm"
r="nm"
ln="list"
24:
m="ceftazidime" 104:3 104:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia" 104:1 104:1
ln="narrative"
25:
m="levofloxacin" 104:5 104:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia" 104:1 104:1
ln="narrative"
26:
m="vancomycin" 104:8 104:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia" 104:1 104:1
ln="narrative"
27:
m="vancomycin" 105:1 105:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="ceftazidime" 106:0 106:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="levofloxacin" 106:6 106:6
do="500 mg" 107:2 107:3
mo="nm"
f="per day" 107:4 107:5
du="for a total 10-day course" 107:6 107:10
r="pneumonia" 108:10 108:10
ln="narrative"
30:
m="levofloxacin" 106:6 106:6
do="500 mg" 107:2 107:3
mo="nm"
f="per day" 107:4 107:5
du="for a total 10-day course" 107:6 107:10
r="uti" 108:8 108:8
ln="narrative"
31:
m="coumadin" 116:12 116:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="levofloxacin" 125:8 125:8
do="nm"
mo="nm"
f="nm"
du="a 10-day course." 127:5 127:7
r="the presumed pneumonia" 126:6 126:8
ln="narrative"
33:
m="metoprolol" 137:1 137:1
do="12.5" 136:12 136:12
mo="nm"
f="b.i.d." 137:0 137:0
du="nm"
r="nm"
ln="narrative"
34:
m="captopril" 139:10 139:10
do="low dose" 139:7 139:8
mo="nm"
f="nm"
du="nm"
r="blood pressures" 140:8 140:9
ln="narrative"
35:
m="nph" 145:6 145:6
do="20" 145:7 145:7
mo="nm"
f="b.i.d." 145:8 145:8
du="through his hospitalization" 145:9 146:0
r="nm"
ln="narrative"
36:
m="regular insulin" 146:2 146:3
do="sliding scale" 146:4 146:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="nph" 148:1 148:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="panafil" 152:0 152:0
do="nm"
mo="nm"
f="t.i.d." 152:1 152:1
du="nm"
r="nm"
ln="narrative"
39:
m="panafil" 152:7 152:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="fluids" 155:1 155:1
do="nm"
mo="iv" 155:0 155:0
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="levofloxacin" 160:10 160:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="coumadin" 161:11 161:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="levofloxacin" 162:4 162:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="coumadin" 166:9 166:9
do="5 mg" 166:10 166:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="fluids" 168:8 168:8
do="nm"
mo="iv" 168:7 168:7
f="nm"
du="until cleared to eat by speech and swallow." 168:9 169:4
r="nm"
ln="narrative"
46:
m="gabapentin" 177:4 177:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="oxybutynin" 177:6 177:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="amitriptyline" 178:0 178:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="coumadin" 179:7 179:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis:" 179:1 179:1
ln="narrative"
50:
m="nexium" 179:5 179:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis:" 179:1 179:1
ln="narrative"
51:
m="amitriptyline" 198:0 198:0
do="25 mg" 198:1 198:2
mo="p.o." 198:3 198:3
f="at bedtime" 198:4 198:5
du="nm"
r="nm"
ln="list"
52:
m="vitamin c" 198:7 198:8
do="500 mg" 198:9 198:10
mo="p.o." 198:11 198:11
f="daily" 198:12 198:12
du="nm"
r="nm"
ln="list"
53:
m="baclofen" 199:0 199:0
do="10 mg" 199:1 199:2
mo="p.o." 199:3 199:3
f="t.i.d." 199:4 199:4
du="nm"
r="nm"
ln="list"
54:
m="caltrate 600 plus d" 199:6 199:9
do="one tablet" 199:10 199:11
mo="p.o." 199:12 199:12
f="b.i.d." 200:0 200:0
du="nm"
r="nm"
ln="list"
55:
m="ferrous sulfate" 200:2 200:3
do="325 mg" 200:4 200:5
mo="p.o." 200:6 200:6
f="t.i.d." 200:7 200:7
du="nm"
r="nm"
ln="list"
56:
m="gabapentin" 200:9 200:9
do="300 mg" 200:10 200:11
mo="p.o." 201:0 201:0
f="t.i.d." 201:1 201:1
du="nm"
r="nm"
ln="list"
57:
m="nph human insulin" 201:3 201:5
do="54 units" 201:6 201:7
mo="nm"
f="in the morning" 201:8 201:10
du="nm"
r="nm"
ln="list"
58:
m="nph human insulin" 201:3 201:5
do="68 units" 201:12 201:13
mo="nm"
f="in the evening" 202:0 202:2
du="nm"
r="nm"
ln="list"
59:
m="levofloxacin" 202:9 202:9
do="500 mg" 202:10 203:0
mo="p.o." 203:1 203:1
f="daily" 203:2 203:2
du="for a total course of 10 days" 203:8 204:0
r="nm"
ln="list"
60:
m="regular insulin" 202:4 202:5
do="sliding scale" 202:6 202:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
61:
m="magnesium oxide" 204:2 204:3
do="420 mg" 204:4 204:5
mo="p.o." 204:6 204:6
f="t.i.d." 204:7 204:7
du="nm"
r="nm"
ln="list"
62:
m="metoprolol" 204:9 204:9
do="12.5 mg" 204:10 204:11
mo="p.o." 204:12 204:12
f="b.i.d." 205:0 205:0
du="nm"
r="nm"
ln="list"
63:
m="oxybutynin" 205:2 205:2
do="5 mg" 205:3 205:4
mo="p.o." 205:5 205:5
f="t.i.d." 205:6 205:6
du="nm"
r="nm"
ln="list"
64:
m="panafil ointment" 205:8 205:9
do="nm"
mo="nm"
f="t.i.d." 205:10 205:10
du="nm"
r="nm"
ln="list"
65:
m="coumadin" 206:7 206:7
do="5 mg" 206:8 206:9
mo="p.o." 206:10 206:10
f="daily" 206:11 206:11
du="nm"
r="nm"
ln="list"
66:
m="ranitidine" 206:0 206:0
do="500 mg" 206:1 206:2
mo="p.o." 206:3 206:3
f="b.i.d." 206:4 206:4
du="nm"
r="nm"
ln="list"
67:
m="ace inhibitor" 217:6 217:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
68:
m="beta-blocker" 217:3 217:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
