1:
m="aspirin" 30:1 30:1
do="81 mg" 30:2 30:3
mo="po" 30:4 30:4
f="qd" 30:5 30:5
du="nm"
r="nm"
ln="list"
2:
m="digoxin" 31:1 31:1
do="0.325 mg" 31:2 31:3
mo="po" 31:4 31:4
f="qd" 31:5 31:5
du="nm"
r="nm"
ln="list"
3:
m="azmacort" 32:1 32:1
do="6 puffs" 32:2 32:3
mo="inhaled" 32:4 32:4
f="bid" 32:5 32:5
du="nm"
r="nm"
ln="list"
4:
m="heparin" 33:1 33:1
do="5000 units" 33:2 33:3
mo="subcu" 33:4 33:4
f="bid" 33:5 33:5
du="nm"
r="nm"
ln="list"
5:
m="zantac" 34:1 34:1
do="150 mg" 34:2 34:3
mo="po" 34:4 34:4
f="bid" 34:5 34:5
du="nm"
r="nm"
ln="list"
6:
m="lasix" 35:1 35:1
do="40 mg" 35:2 35:3
mo="po" 35:4 35:4
f="qd" 35:5 35:5
du="nm"
r="nm"
ln="list"
7:
m="capoten" 36:1 36:1
do="25 mg" 36:2 36:3
mo="nm"
f="q 8" 36:4 36:5
du="nm"
r="nm"
ln="list"
8:
m="albuterol nebulizers" 37:1 37:2
do="0.5 cc" 37:3 37:4
mo="nm"
f="qid" 37:10 37:10
du="nm"
r="nm"
ln="list"
9:
m="normal saline" 37:8 37:9
do="nm"
mo="nm"
f="qid" 37:10 37:10
du="nm"
r="nm"
ln="list"
10:
m="nph insulin" 38:1 38:2
do="38 units" 38:3 38:4
mo="subcu" 38:5 38:5
f="bid" 38:6 38:6
du="nm"
r="nm"
ln="list"
11:
m="nystatin" 39:1 39:1
do="5 cc" 39:5 39:6
mo="swish and swallow...po" 39:2 39:4,39:7 39:7
f="qid" 39:8 39:8
du="nm"
r="nm"
ln="list"
12:
m="bactrim ds" 40:1 40:2
do="one tab" 40:3 40:4
mo="po" 40:5 40:5
f="bid" 40:6 40:6
du="nm"
r="nm"
ln="list"
13:
m="antibiotic-containing solution" 76:3 76:4
do="nm"
mo="irrigated" 75:8 75:8
f="nm"
du="nm"
r="wound" 75:6 75:6
ln="narrative"
14:
m="ampicillin" 81:2 81:2
do="nm"
mo="nm"
f="nm"
du="until culture results returned" 81:8 82:2
r="nm"
ln="narrative"
15:
m="flagyl" 81:6 81:6
do="nm"
mo="nm"
f="nm"
du="until culture results returned" 81:8 82:2
r="nm"
ln="narrative"
16:
m="gentamicin" 81:4 81:4
do="nm"
mo="nm"
f="nm"
du="until culture results returned" 81:8 82:2
r="nm"
ln="narrative"
17:
m="klonopin" 100:3 100:3
do="1 mg" 100:4 100:5
mo="po" 100:6 100:6
f="tid" 100:7 100:7
du="nm"
r="anxiety" 99:8 99:8
ln="narrative"
18:
m="percocet" 101:9 101:9
do="nm"
mo="po" 101:8 101:8
f="nm"
du="nm"
r="his pain" 101:3 101:4
ln="narrative"
19:
m="insulin nph" 131:10 132:0
do="38 units" 132:1 132:2
mo="subcutaneous" 131:7 131:7
f="in the morning" 132:3 132:5
du="nm"
r="nm"
ln="narrative"
20:
m="insulin nph" 131:10 132:0
do="38 units" 132:7 132:8
mo="subcutaneous" 131:7 131:7
f="at night" 132:9 132:10
du="nm"
r="nm"
ln="narrative"
21:
m="insulin drip" 133:7 133:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="his blood sugars" 134:2 134:4
ln="narrative"
22:
m="lasix" 145:6 145:6
do="40 mg" 145:7 145:8
mo="nm"
f="a day" 145:9 145:10
du="nm"
r="nm"
ln="narrative"
23:
m="capoten" 151:4 151:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="heparin" 153:4 153:4
do="nm"
mo="subcutaneous" 153:3 153:3
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="ampicillin" 154:7 154:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="flagyl" 155:2 155:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="gentamicin" 155:0 155:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="ampicillin" 158:1 158:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="enterococcus" 157:6 157:6
ln="narrative"
29:
m="ofloxacin" 158:3 158:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="enterococcus" 157:6 157:6
ln="narrative"
30:
m="gentamicin" 159:0 159:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="enterobacter cloacae" 158:5 158:6
ln="narrative"
31:
m="ofloxacin" 159:2 159:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="enterobacter cloacae" 158:5 158:6
ln="narrative"
32:
m="gentamicin" 160:0 160:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="ofloxacin" 160:2 160:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="ofloxacin" 165:9 165:9
do="nm"
mo="po" 165:8 165:8
f="nm"
du="7 more days" 165:4 165:6
r="nm"
ln="narrative"
35:
m="ampicillin" 167:11 167:11
do="nm"
mo="iv" 167:10 167:10
f="nm"
du="a total of 7 days" 167:4 167:8
r="nm"
ln="narrative"
36:
m="flagyl" 168:2 168:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="ofloxacin" 168:0 168:0
do="nm"
mo="iv" 167:10 167:10
f="nm"
du="a total of 7 days" 167:4 167:8
r="nm"
ln="narrative"
38:
m="antibiotic" 172:9 172:9
do="nm"
mo="oral" 172:8 172:8
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="tylenol" 176:4 176:4
do="650 mg" 176:5 176:6
mo="p.o." 176:7 176:7
f="q4h p.r.n." 176:8 177:0
du="nm"
r="headache" 177:1 177:1
ln="list"
40:
m="albuterol nebulizer" 177:11 177:12
do="0.5 cc" 178:0 178:1
mo="nm"
f="q.i.d" 178:8 178:8
du="nm"
r="nm"
ln="list"
41:
m="aspirin" 177:4 177:4
do="81 mg" 177:5 177:6
mo="p.o." 177:7 177:7
f="qd" 177:8 177:8
du="nm"
r="nm"
ln="list"
42:
m="capoten" 178:11 178:11
do="25 mg" 178:12 178:13
mo="p.o." 178:14 178:14
f="qh" 178:15 178:15
du="nm"
r="nm"
ln="list"
43:
m="normal saline" 178:6 178:7
do="2.5 cc" 178:3 178:4
mo="nm"
f="q.i.d." 178:8 178:8
du="nm"
r="nm"
ln="list"
44:
m="chloral hydrate" 179:2 179:3
do="500 mg" 179:4 179:5
mo="p.o." 179:6 179:6
f="q.h.s. p.r.n." 179:7 179:8
du="nm"
r="insomnia" 179:9 179:9
ln="list"
45:
m="clonopin" 179:12 179:12
do="1 mg" 180:0 180:1
mo="p.o." 180:2 180:2
f="t.i.d." 180:3 180:3
du="nm"
r="nm"
ln="list"
46:
m="colace" 180:13 180:13
do="100 mg" 180:14 180:15
mo="p.o." 180:16 180:16
f="b.i.d." 181:0 181:0
du="nm"
r="nm"
ln="list"
47:
m="digoxin" 180:6 180:6
do="0.375 mg" 180:7 180:8
mo="p.o." 180:9 180:9
f="qd" 180:10 180:10
du="nm"
r="nm"
ln="list"
48:
m="heparin" 181:11 181:11
do="5000 units" 181:12 181:13
mo="subcu" 181:14 181:14
f="b.i.d." 181:15 181:15
du="nm"
r="nm"
ln="list"
49:
m="lasix" 181:3 181:3
do="40 mg" 181:4 181:5
mo="p.o." 181:6 181:6
f="q d." 181:7 181:8
du="nm"
r="nm"
ln="list"
50:
m="insulin nph" 182:2 182:3
do="38 units" 182:4 182:5
mo="subcu" 182:6 182:6
f="b.i.d." 182:7 182:7
du="nm"
r="nm"
ln="list"
51:
m="milk of magnesia" 182:10 182:12
do="30 cc" 182:13 182:14
mo="p.o." 183:0 183:0
f="qd p.r.n." 183:1 183:2
du="nm"
r="constipation" 183:3 183:3
ln="list"
52:
m="multivitamins" 183:6 183:6
do="one capsule" 183:7 183:8
mo="p.o." 183:9 183:9
f="qd" 183:10 183:10
du="nm"
r="nm"
ln="list"
53:
m="mycostatin" 184:2 184:2
do="5 cc" 184:3 184:4
mo="p.o." 184:5 184:5
f="q.i.d." 184:6 184:6
du="nm"
r="nm"
ln="list"
54:
m="percocet" 184:9 184:9
do="one or two tabs" 184:10 184:13
mo="p.o." 184:14 184:14
f="q3-4h p.r.n." 185:0 185:1
du="nm"
r="pain" 185:2 185:2
ln="list"
55:
m="azmacort" 185:12 185:12
do="six puffs" 186:0 186:1
mo="inhaled" 186:2 186:2
f="b.i.d." 186:3 186:3
du="nm"
r="nm"
ln="list"
56:
m="metamucil" 185:5 185:5
do="one packet" 185:6 185:7
mo="p.o." 185:8 185:8
f="qd" 185:9 185:9
du="nm"
r="nm"
ln="list"
57:
m="axid" 186:6 186:6
do="150 mg" 186:7 186:8
mo="p.o." 186:9 186:9
f="b.i.d." 186:10 186:10
du="nm"
r="nm"
ln="list"
58:
m="ofloxacin" 186:13 186:13
do="200 mg" 187:0 187:1
mo="p.o." 187:2 187:2
f="b.i.d." 187:3 187:3
du="x 7 days" 187:4 187:6
r="nm"
ln="list"
