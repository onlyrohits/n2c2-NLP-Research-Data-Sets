1:
m="acetylsalicylic acid" 19:1 19:2
do="325 mg" 19:3 19:4
mo="po" 19:5 19:5
f="qd" 19:6 19:6
du="nm"
r="nm"
ln="list"
2:
m="atenolol" 20:1 20:1
do="25 mg" 20:2 20:3
mo="po" 20:4 20:4
f="qd" 20:5 20:5
du="nm"
r="nm"
ln="list"
3:
m="atorvastatin" 21:1 21:1
do="80 mg" 21:2 21:3
mo="po" 21:4 21:4
f="qd" 21:5 21:5
du="nm"
r="nm"
ln="list"
4:
m="docusate sodium" 22:1 22:2
do="100 mg" 22:3 22:4
mo="po" 22:5 22:5
f="bid" 22:6 22:6
du="nm"
r="nm"
ln="list"
5:
m="losartan" 23:1 23:1
do="50 mg" 23:2 23:3
mo="po" 23:4 23:4
f="qd" 23:5 23:5
du="nm"
r="nm"
ln="list"
6:
m="metformin" 24:1 24:1
do="850 mg" 24:2 24:3
mo="po" 24:4 24:4
f="bid" 24:5 24:5
du="nm"
r="nm"
ln="list"
7:
m="terazosin hcl" 25:1 25:2
do="1 mg" 25:3 25:4
mo="po" 25:5 25:5
f="qd" 25:6 25:6
du="nm"
r="nm"
ln="list"
8:
m="amlodipine" 26:1 26:1
do="10 mg" 26:2 26:3
mo="po" 26:4 26:4
f="qd" 26:5 26:5
du="nm"
r="nm"
ln="list"
9:
m="losartan" 27:1 27:1
do="50 mg" 27:2 27:3
mo="po" 27:4 27:4
f="qd" 27:5 27:5
du="nm"
r="nm"
ln="list"
10:
m="pantoprazole" 28:1 28:1
do="40 mg" 28:2 28:3
mo="po" 28:4 28:4
f="qd" 28:5 28:5
du="nm"
r="nm"
ln="list"
11:
m="acetylsalicylic acid" 30:0 30:1
do="325 mg" 30:2 30:3
mo="po" 30:4 30:4
f="daily" 30:5 30:5
du="nm"
r="nm"
ln="list"
12:
m="amlodipine" 32:0 32:0
do="10 mg" 32:1 32:2
mo="po" 32:3 32:3
f="daily" 32:4 32:4
du="nm"
r="nm"
ln="list"
13:
m="atenolol" 35:0 35:0
do="25 mg" 35:1 35:2
mo="po" 35:3 35:3
f="daily" 35:4 35:4
du="nm"
r="nm"
ln="list"
14:
m="lipitor ( atorvastatin )" 36:0 36:3
do="80 mg" 36:4 36:5
mo="po" 36:6 36:6
f="daily" 36:7 36:7
du="nm"
r="nm"
ln="list"
15:
m="colace ( docusate sodium )" 37:0 37:4
do="100 mg" 37:5 37:6
mo="po" 37:7 37:7
f="bid" 37:8 37:8
du="nm"
r="nm"
ln="list"
16:
m="losartan" 38:0 38:0
do="50 mg" 38:1 38:2
mo="po" 38:3 38:3
f="daily" 38:4 38:4
du="nm"
r="nm"
ln="list"
17:
m="kcl" 41:3 41:3
do="nm"
mo="iv" 41:4 41:4
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="losartan potassium" 42:3 42:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="potassium chloride" 43:0 43:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="kcl immediate release" 46:3 46:5
do="nm"
mo="po" 46:6 46:6
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="losartan potassium" 48:3 48:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="potassium chloride" 49:0 49:1
do="number of doses required ( approximate ): 3" 50:0 50:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="mg gluconate ( magnesium gluconate )" 51:0 51:5
do="400 mg" 51:6 51:7
mo="po" 51:8 51:8
f="daily" 51:9 51:9
du="nm"
r="nm"
ln="list"
24:
m="protonix ( pantoprazole )" 53:0 53:3
do="40 mg" 53:4 53:5
mo="po" 53:6 53:6
f="daily" 53:7 53:7
du="nm"
r="nm"
ln="list"
25:
m="terazosin hcl" 54:0 54:1
do="1 mg" 54:2 54:3
mo="po" 54:4 54:4
f="daily" 54:5 54:5
du="number of doses required ( approximate ): 2" 55:0 55:7
r="nm"
ln="list"
26:
m="asa" 97:3 97:3
do="325" 97:4 97:4
mo="nm"
f="nm"
du="x 1" 97:5 97:6
r="nm"
ln="narrative"
27:
m="ativan" 97:8 97:8
do="0.5 mg" 97:9 97:10
mo="nm"
f="nm"
du="x 1" 97:11 97:12
r="nm"
ln="narrative"
28:
m="mg chloride" 97:14 97:15
do="500 mg" 97:16 97:17
mo="nm"
f="nm"
du="x 1" 98:0 98:1
r="nm"
ln="narrative"
29:
m="atenolol" 101:0 101:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="amlodipine" 115:12 115:12
do="5 mg" 115:13 115:14
mo="nm"
f="daily" 116:0 116:0
du="nm"
r="nm"
ln="list"
31:
m="asa" 115:2 115:2
do="325 mg" 115:3 115:4
mo="nm"
f="daily" 115:5 115:5
du="nm"
r="nm"
ln="list"
32:
m="lipitor" 115:7 115:7
do="80 mg" 115:8 115:9
mo="nm"
f="daily" 115:10 115:10
du="nm"
r="nm"
ln="list"
33:
m="losartan" 116:7 116:7
do="50 mg" 116:8 116:9
mo="nm"
f="daily" 116:10 116:10
du="nm"
r="nm"
ln="list"
34:
m="protonix" 116:2 116:2
do="40 mg" 116:3 116:4
mo="nm"
f="daily" 116:5 116:5
du="nm"
r="nm"
ln="list"
35:
m="terazosin" 116:12 116:12
do="1 mg" 116:13 116:14
mo="nm"
f="daily" 117:0 117:0
du="nm"
r="nm"
ln="list"
36:
m="atenolol" 117:2 117:2
do="25 mg" 117:3 117:4
mo="nm"
f="daily" 117:5 117:5
du="nm"
r="nm"
ln="list"
37:
m="metformin" 117:7 117:7
do="850 mg" 117:8 117:9
mo="nm"
f="qam" 117:10 117:10
du="nm"
r="nm"
ln="list"
38:
m="above meds" 156:3 156:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="bb/ccb" 156:7 156:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="bb" 157:8 157:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="risk" 157:0 157:0
ln="narrative"
41:
m="metformin" 163:5 163:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="metformin" 164:2 164:2
do="nm"
mo="nm"
f="nm"
du="while in house" 164:7 164:9
r="nm"
ln="narrative"
43:
m="asa" 170:4 170:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="lovenox" 170:6 170:6
do="nm"
mo="sc" 170:7 170:7
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="ppi" 170:9 170:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
46:
m="statin" 170:2 170:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
