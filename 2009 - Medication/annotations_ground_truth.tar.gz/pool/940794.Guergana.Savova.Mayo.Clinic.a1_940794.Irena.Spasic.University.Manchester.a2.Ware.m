1:
m="acebutolol hcl" 19:0 19:1
do="400 mg" 19:2 19:3
mo="po" 19:4 19:4
f="daily" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="allopurinol" 22:0 22:0
do="100 mg" 22:1 22:2
mo="po" 22:3 22:3
f="daily" 22:4 22:4
du="nm"
r="nm"
ln="list"
3:
m="vitamin c ( ascorbic acid )" 23:0 23:5
do="500 mg" 23:6 23:7
mo="po" 23:8 23:8
f="bid" 23:9 23:9
du="nm"
r="nm"
ln="list"
4:
m="calcium carbonate ( 500 mg elemental ca++ )" 24:0 24:7
do="500 mg" 24:8 24:9
mo="po" 24:10 24:10
f="bid" 24:11 24:11
du="nm"
r="nm"
ln="list"
5:
m="ciprofloxacin" 25:0 25:0
do="250 mg" 25:1 25:2
mo="po" 25:3 25:3
f="q12h" 25:4 25:4
du="x 4 doses" 25:5 25:7
r="nm"
ln="list"
6:
m="iron products" 27:1 27:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="ciprofloxacin" 28:4 28:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="levofloxacin" 28:2 28:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="digoxin" 31:0 31:0
do="0.125 mg" 31:1 31:2
mo="po" 31:3 31:3
f="daily" 31:4 31:4
du="nm"
r="nm"
ln="list"
10:
m="colace ( docusate sodium )" 32:0 32:4
do="100 mg" 32:5 32:6
mo="po" 32:7 32:7
f="bid" 32:8 32:8
du="nm"
r="nm"
ln="list"
11:
m="lovenox ( enoxaparin )" 33:0 33:3
do="120 mg" 33:4 33:5
mo="sc" 33:6 33:6
f="bedtime" 33:7 33:7
du="nm"
r="nm"
ln="list"
12:
m="tarceva ( erlotinib )" 34:0 34:3
do="100 mg" 34:4 34:5
mo="po" 34:6 34:6
f="daily" 34:7 34:7
du="nm"
r="nm"
ln="list"
13:
m="folic acid" 39:0 39:1
do="1 mg" 39:2 39:3
mo="po" 39:4 39:4
f="daily" 39:5 39:5
du="nm"
r="nm"
ln="list"
14:
m="furosemide" 40:0 40:0
do="40 mg" 40:1 40:2
mo="po" 40:3 40:3
f="daily" 40:4 40:4
du="nm"
r="nm"
ln="list"
15:
m="dilaudid ( hydromorphone hcl )" 41:0 41:4
do="0.5 mg" 41:5 41:6
mo="po" 41:7 41:7
f="q4h prn" 41:8 41:9
du="nm"
r="pain" 41:10 41:10
ln="list"
16:
m="dilaudid" 44:3 44:3
do="nm"
mo="po" 44:4 44:4
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="tramadol hcl" 49:3 49:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="hydromorphone hcl" 50:0 50:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="lidoderm 5% patch ( lidocaine 5% patch )" 51:0 51:7
do="1 ea" 51:8 51:9
mo="tp" 51:10 51:10
f="daily" 51:11 51:11
du="nm"
r="nm"
ln="list"
20:
m="pravachol ( pravastatin )" 53:0 53:3
do="20 mg" 53:4 53:5
mo="po" 53:6 53:6
f="bedtime" 53:7 53:7
du="nm"
r="nm"
ln="list"
21:
m="vitamin b6 ( pyridoxine hcl )" 56:0 56:5
do="50 mg" 56:6 56:7
mo="po" 56:8 56:8
f="daily" 56:9 56:9
du="nm"
r="nm"
ln="list"
22:
m="ultram ( tramadol )" 57:0 57:3
do="50 mg" 57:4 57:5
mo="po" 57:6 57:6
f="q6h prn" 57:7 57:8
du="nm"
r="pain" 57:9 57:9
ln="list"
23:
m="dilaudid" 60:3 60:3
do="nm"
mo="po" 60:4 60:4
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="tramadol hcl" 61:3 61:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="hydromorphone hcl" 62:0 62:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="ultram" 65:3 65:3
do="nm"
mo="po" 65:4 65:4
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="morphine" 70:3 70:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="tramadol hcl" 70:5 70:6
do="nm"
mo="nm"
f="nm"
du="number of doses required (approximate): 15" 72:0 72:7
r="nm"
ln="list"
29:
m="morphine" 71:5 71:5
do="nm"
mo="nm"
f="nm"
du="number of doses required ( approximate ): 15" 72:0 72:7
r="nm"
ln="list"
30:
m="fondaparinux" 100:8 100:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="afib" 100:5 100:5
ln="narrative"
31:
m="fondapurinox" 104:0 104:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="asa" 109:8 109:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="ngl" 110:0 110:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="fondapurinox" 134:2 134:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="lovenox" 134:6 134:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="lidoderm" 138:10 138:10
do="nm"
mo="patch" 139:0 139:0
f="nm"
du="nm"
r="pain control" 138:7 138:8
ln="narrative"
37:
m="dilaudid" 139:6 139:6
do="low dose" 139:4 139:5
mo="nm"
f="as needed" 139:7 139:8
du="nm"
r="severe pain" 139:10 139:11
ln="narrative"
38:
m="ultram" 139:2 139:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="tarceva" 140:4 140:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="acebutolol" 143:4 143:4
do="400mg" 143:10 143:10
mo="nm"
f="daily" 143:11 143:11
du="nm"
r="nm"
ln="narrative"
41:
m="acebutolol" 143:4 143:4
do="400mg" 143:7 143:7
mo="nm"
f="bid" 143:8 143:8
du="nm"
r="nm"
ln="narrative"
42:
m="fondaparinux" 144:8 144:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="lovenox" 145:2 145:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="lasix" 147:0 147:0
do="40 mg" 147:4 147:5
mo="nm"
f="daily" 147:6 147:6
du="nm"
r="nm"
ln="narrative"
45:
m="lasix" 148:8 148:8
do="titrate" 148:7 148:7
mo="nm"
f="as needed" 148:9 148:10
du="nm"
r="nm"
ln="narrative"
46:
m="cipro" 149:8 149:8
do="250mg" 149:12 149:12
mo="nm"
f="bid" 149:13 149:13
du="nm"
r="klebsiella uti" 149:3 149:4
ln="narrative"
47:
m="lidoderm" 150:5 150:5
do="nm"
mo="patch" 150:6 150:6
f="nm"
du="nm"
r="pain" 150:1 150:1
ln="narrative"
48:
m="ultram" 150:8 150:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="dilaudid" 151:1 151:1
do="low dose" 150:14 151:0
mo="nm"
f="nm"
du="nm"
r="breakthrough pain" 151:5 151:6
ln="narrative"
50:
m="lovenox" 164:7 164:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="acebutolol" 167:5 167:5
do="decreased dose" 167:2 167:3
mo="nm"
f="nm"
du="nm"
r="adequate rate control" 166:9 167:0
ln="narrative"
52:
m="lasix" 168:2 168:2
do="40mg" 168:11 168:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
53:
m="lasix" 168:2 168:2
do="40mg" 168:4 168:4
mo="nm"
f="daily" 168:5 168:5
du="nm"
r="nm"
ln="list"
54:
m="lasix" 168:2 168:2
do="40mg" 168:4 168:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
55:
m="cipro" 170:4 170:4
do="250mg" 170:5 170:5
mo="nm"
f="bid" 170:6 170:6
du="x 3 days" 170:7 170:9
r="klebsiella uti" 171:3 171:4
ln="list"
