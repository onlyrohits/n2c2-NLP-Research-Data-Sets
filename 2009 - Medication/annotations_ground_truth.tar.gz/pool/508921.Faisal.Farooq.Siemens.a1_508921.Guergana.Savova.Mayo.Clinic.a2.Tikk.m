1:
m="tylenol ( acetaminophen )" 17:0 17:3
do="650 mg" 17:4 17:5
mo="po" 17:6 17:6
f="q4h prn" 17:7 17:8
du="nm"
r="headache" 17:9 17:9
ln="list"
2:
m="ventolin ( albuterol inhaler )" 18:0 18:4
do="1-2 puff" 18:5 18:6
mo="inh" 18:7 18:7
f="qid prn" 18:8 19:0
du="nm"
r="sob/wheeze" 19:1 19:1
ln="list"
3:
m="ecasa ( aspirin enteric coated )" 20:0 20:5
do="325 mg" 20:6 20:7
mo="po" 20:8 20:8
f="qd" 20:9 20:9
du="nm"
r="nm"
ln="list"
4:
m="atenolol" 21:0 21:0
do="25 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qd...with meals" 21:4 21:4,22:2 22:3
du="nm"
r="nm"
ln="list"
5:
m="ceftriaxone" 23:0 23:0
do="2 , 000 mg" 23:1 23:4
mo="iv" 23:5 23:5
f="qd" 23:6 23:6
du="number of doses required ( approximate ): 2" 24:0 24:7
r="nm"
ln="list"
6:
m="colace ( docusate sodium )" 25:0 25:4
do="100 mg" 25:5 25:6
mo="po " 25:7 25:7
f="bid " 25:8 25:8
du="nm"
r="nm"
ln="list"
7:
m="enalapril ( enalapril maleate )" 26:0 26:4
do="2.5 mg" 26:5 26:6
mo="po " 26:7 26:7
f="qd " 26:8 26:8
du="nm"
r="nm"
ln="list"
8:
m="percocet" 27:0 27:0
do="1-2 tab" 27:1 27:2
mo="po" 27:3 27:3
f="q4h prn" 27:4 27:5
du="nm"
r="pain" 27:6 27:6
ln="list"
9:
m="zocor ( simvastatin )" 28:0 28:3
do="5 mg" 28:4 28:5
mo="po " 28:6 28:6
f="qhs " 28:7 28:7
du="nm"
r="nm"
ln="list"
10:
m="isosorbide mononitrate" 31:0 31:1
do="30 mg" 31:2 31:3
mo="po" 31:4 31:4
f="qd" 31:5 31:5
du="nm"
r="nm"
ln="list"
11:
m="nexium ( esomeprazole )" 35:0 35:3
do="20 mg" 35:4 35:5
mo="po" 35:6 35:6
f="qd" 35:7 35:7
du="nm"
r="nm"
ln="list"
12:
m="abx" 52:1 52:1
do="nm"
mo="iv" 52:0 52:0
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="ceftriaxone" 55:5 55:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="aspiration" 54:8 54:8
ln="narrative"
14:
m="ceftriaxone" 56:6 56:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="pcn" 56:4 56:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="abx" 60:6 60:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="antibiotics" 61:6 61:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="ceftriaxone." 65:8 65:8
do="home dosing" 65:4 65:5
mo="iv" 64:8 64:8
f="qd" 65:7 65:7
du="nm"
r="nm"
ln="narrative"
19:
m="abx" 66:7 66:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="pcn/ctx" 67:6 67:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="abx" 68:3 68:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="ctx" 72:7 72:7
do="nm"
mo="nm"
f="qd" 72:6 72:6
du="nm"
r="nm"
ln="list"
23:
m="ceftriaxone" 76:2 76:2
do="2 gr" 76:5 76:6
mo="iv" 76:1 76:1
f="qd" 76:8 76:8
du="nm"
r="nm"
ln="narrative"
