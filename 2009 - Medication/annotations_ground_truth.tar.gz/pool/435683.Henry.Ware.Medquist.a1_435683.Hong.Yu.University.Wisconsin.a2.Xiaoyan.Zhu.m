1:
m="klonopin" 10:2 10:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="antibiotic" 25:1 25:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia." 26:0 26:0
ln="narrative"
3:
m="lisinopril" 26:6 26:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="methadone" 26:8 26:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonia" 25:12 26:0
ln="narrative"
5:
m="vancomycin" 36:9 36:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="gentamicin" 37:2 37:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="levaquin" 37:0 37:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="normal saline" 37:7 37:8
do="3 liters" 37:4 37:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="fluids" 38:2 38:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="levophed" 38:7 38:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood pressure support." 38:9 39:1
ln="narrative"
11:
m="levophed" 42:5 42:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="klonopin" 51:4 51:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="methadone" 51:0 51:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic right lower extremity pain" 50:2 50:6
ln="narrative"
14:
m="cefepime" 52:5 52:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="vancomycin" 53:2 53:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="lisinopril" 58:0 58:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="lisinopril" 58:8 58:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="methadone" 58:2 58:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="hydrochlorothiazide" 59:7 59:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="lisinopril" 59:5 59:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="oxygen" 68:12 68:12
do="8 liters" 68:9 68:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="heparin" 95:0 95:0
do="nm"
mo="drip" 95:1 95:1
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="oxygen" 100:2 100:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="oxygen" 104:0 104:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="dobutamine" 111:0 111:0
do="low dose" 110:10 110:11
mo="nm"
f="nm"
du="nm"
r="hypotension" 109:9 109:9
ln="narrative"
26:
m="lisinopril" 113:0 113:0
do="nm"
mo="nm"
f="nm"
du="while in-house." 113:1 113:2
r="nm"
ln="narrative"
27:
m="this medication" 116:3 116:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="bicarb" 123:4 123:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="mucomyst" 123:2 123:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="antibiotics" 132:6 132:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="gentamicin" 132:4 132:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="levofloxacin" 132:2 132:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="vancomycin" 132:0 132:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="antibiotics" 136:3 136:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="ditropan" 140:7 140:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="monistat" 143:5 143:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="a yeast infection" 143:7 143:9
ln="narrative"
37:
m="corticosteroids" 150:0 150:0
do="nm"
mo="inhaled" 149:10 149:10
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="unfractionated heparin" 151:5 151:6
do="nm"
mo="nm"
f="nm"
du="until 6/15/06" 152:0 152:1
r="her presumed pe" 151:8 151:10
ln="narrative"
39:
m="lovenox" 152:8 152:8
do="120 mg" 153:4 153:5
mo="subq." 153:6 153:6
f="nm"
du="nm"
r="her presumed pe" 151:8 151:10
ln="narrative"
40:
m="coumadin" 154:1 154:1
do="5" 154:12 154:12
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="coumadin" 154:1 154:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="lovenox" 156:6 156:6
do="nm"
mo="nm"
f="nm"
du="for two additional days." 156:7 156:10
r="nm"
ln="narrative"
43:
m="methadone." 158:6 158:6
do="10 mg" 159:8 159:9
mo="p.o." 159:10 159:10
f="b.i.d." 159:11 159:11
du="nm"
r="nm"
ln="narrative"
44:
m="methadone." 158:6 158:6
do="20 mg" 159:3 159:4
mo="p.o." 159:5 159:5
f="daily" 159:6 159:6
du="nm"
r="nm"
ln="narrative"
45:
m="methadone" 158:6 158:6
do="20 mg" 159:3 159:4
mo="p.o." 159:5 159:5
f="daily" 159:6 159:6
du="nm"
r="nm"
ln="narrative"
46:
m="ativan" 160:6 160:6
do="nm"
mo="nm"
f="nm"
du="while in-house" 160:7 160:8
r="anxiety." 161:2 161:2
ln="narrative"
47:
m="ativan" 160:6 160:6
do="nm"
mo="nm"
f="nm"
du="while in-house" 160:7 160:8
r="her agitation" 160:12 161:0
ln="narrative"
48:
m="haldol" 162:0 162:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
