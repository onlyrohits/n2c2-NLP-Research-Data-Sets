1:
m="lasix" 21:0 21:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="lasix" 45:1 45:1
do="120 mg" 45:2 45:3
mo="p.o." 45:4 45:4
f="b.i.d." 45:5 45:5
du="nm"
r="nm"
ln="list"
3:
m="atenolol" 46:1 46:1
do="50 mg" 46:2 46:3
mo="p.o." 46:4 46:4
f="q.d." 46:5 46:5
du="nm"
r="nm"
ln="list"
4:
m="iron sulfate" 47:1 47:2
do="300" 47:3 47:3
mo="nm"
f="b.i.d." 47:4 47:4
du="nm"
r="nm"
ln="list"
5:
m="folate" 48:1 48:1
do="1 mg" 48:2 48:3
mo="nm"
f="q.d." 48:4 48:4
du="nm"
r="nm"
ln="list"
6:
m="nph insulin" 49:1 49:2
do="20 units" 49:3 49:4
mo="nm"
f="q.d." 49:5 49:5
du="nm"
r="nm"
ln="list"
7:
m="oxycodone" 50:1 50:1
do="5 mg to 10 mg" 50:2 50:6
mo="nm"
f="q.4-6h. p.r.n." 50:7 50:8
du="nm"
r="pain" 50:9 50:9
ln="list"
8:
m="senna" 51:1 51:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="multivitamins" 52:1 52:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="zocor" 53:1 53:1
do="40 mg" 53:2 53:3
mo="p.o." 53:4 53:4
f="q.d." 53:5 53:5
du="nm"
r="nm"
ln="list"
11:
m="norvasc" 54:1 54:1
do="10 mg" 54:2 54:3
mo="p.o." 54:4 54:4
f="q.d." 54:5 54:5
du="nm"
r="nm"
ln="list"
12:
m="accupril" 55:1 55:1
do="80 mg" 55:2 55:3
mo="p.o." 55:4 55:4
f="q.d." 55:5 55:5
du="nm"
r="nm"
ln="list"
13:
m="miconazole 2%" 56:1 56:2
do="nm"
mo="topical" 56:3 56:3
f="b.i.d." 56:4 56:4
du="nm"
r="nm"
ln="list"
14:
m="celexa" 57:1 57:1
do="20 mg" 57:2 57:3
mo="p.o." 57:4 57:4
f="q.d." 57:5 57:5
du="nm"
r="nm"
ln="list"
15:
m="avandia" 58:1 58:1
do="8 mg" 58:2 58:3
mo="p.o." 58:4 58:4
f="q.d." 58:5 58:5
du="nm"
r="nm"
ln="list"
16:
m="nexium" 59:1 59:1
do="20 mg" 59:2 59:3
mo="p.o." 59:4 59:4
f="q.d." 59:5 59:5
du="nm"
r="nm"
ln="list"
17:
m="albuterol" 60:1 60:1
do="nm"
mo="nm"
f="p.r.n." 60:2 60:2
du="nm"
r="nm"
ln="list"
18:
m="aspirin" 92:0 92:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="statin." 92:4 92:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="beta-blocker ( lopressor )" 94:1 94:4
do="low-dose" 93:9 93:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="ace inhibitor" 95:1 95:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="captopril" 95:7 95:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="ace inhibitor" 96:1 96:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="a goal blood pressure" 97:1 97:4
ln="narrative"
24:
m="adenosine" 97:10 97:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="beta-blocker" 109:7 109:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="coumadin" 111:4 111:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 110:1 110:2
ln="narrative"
27:
m="coumadin" 111:4 111:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="depressed ejection fraction" 110:6 110:8
ln="narrative"
28:
m="lasix" 115:11 115:11
do="80 mg" 115:7 115:8
mo="iv" 115:10 115:10
f="t.i.d." 115:12 115:12
du="nm"
r="nm"
ln="narrative"
29:
m="folate" 140:1 140:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic folate" 139:0 139:1
ln="narrative"
30:
m="iron" 140:3 140:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="iron-deficiency anemia" 139:3 139:4
ln="narrative"
31:
m="nph" 141:6 141:6
do="20 units" 141:7 141:8
mo="nm"
f="nm"
du="nm"
r="her known diabetes." 141:10 142:1
ln="narrative"
32:
m="avandia" 143:2 143:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="ace inhibitor" 156:6 156:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="bactrim" 161:5 161:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="a uti" 160:8 160:9
ln="narrative"
35:
m="bactrim" 162:0 162:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="a uti" 160:8 160:9
ln="narrative"
36:
m="celebrex" 164:2 164:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="oxycodone" 168:10 168:10
do="nm"
mo="nm"
f="p.r.n." 168:11 168:11
du="nm"
r="her pain" 168:4 168:5
ln="narrative"
38:
m="antiinflammatory medications" 170:4 170:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="her arthritis." 171:3 171:4
ln="narrative"
39:
m="celebrex" 170:1 170:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="arthritis" 171:4 171:4
ln="narrative"
40:
m="celexa" 172:5 172:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="depression" 172:7 172:7
ln="narrative"
41:
m="aspirin" 178:1 178:1
do="81 mg" 178:2 178:3
mo="p.o." 178:4 178:4
f="q.d." 178:5 178:5
du="nm"
r="nm"
ln="list"
42:
m="colace" 179:1 179:1
do="100 mg" 179:2 179:3
mo="p.o." 179:4 179:4
f="b.i.d." 179:5 179:5
du="nm"
r="nm"
ln="list"
43:
m="iron sulfate" 180:1 180:2
do="325 mg" 180:3 180:4
mo="p.o." 180:5 180:5
f="q.d." 180:6 180:6
du="nm"
r="nm"
ln="list"
44:
m="prozac" 181:1 181:1
do="20 mg" 181:2 181:3
mo="p.o." 181:4 181:4
f="q.d." 181:5 181:5
du="nm"
r="nm"
ln="list"
45:
m="folate" 182:1 182:1
do="1 mg" 182:2 182:3
mo="p.o." 182:4 182:4
f="q.d." 182:5 182:5
du="nm"
r="nm"
ln="list"
46:
m="lasix" 183:1 183:1
do="160 mg" 183:2 183:3
mo="p.o." 183:4 183:4
f="q.d." 183:5 183:5
du="nm"
r="nm"
ln="list"
47:
m="nph human insulin" 186:1 186:3
do="20 units" 186:4 186:5
mo="subcu" 186:6 186:6
f="q.p.m." 186:7 186:7
du="nm"
r="nm"
ln="list"
48:
m="zestril" 187:1 187:1
do="30 mg" 187:2 187:3
mo="p.o." 187:4 187:4
f="q.d." 187:5 187:5
du="nm"
r="nm"
ln="list"
49:
m="oxycodone" 188:1 188:1
do="5 mg to 10 mg" 188:2 188:6
mo="p.o." 188:7 188:7
f="q.4-6h. p.r.n." 188:8 188:9
du="nm"
r="pain" 188:10 188:10
ln="list"
50:
m="senna tablets" 189:1 189:2
do="2 mg" 189:3 189:4
mo="p.o." 189:5 189:5
f="b.i.d." 189:6 189:6
du="nm"
r="nm"
ln="list"
51:
m="aldactone" 190:1 190:1
do="25 mg" 190:2 190:3
mo="p.o." 190:4 190:4
f="q.d." 190:5 190:5
du="nm"
r="nm"
ln="list"
52:
m="this medication" 190:7 190:8
do="nm"
mo="nm"
f="nm"
du="until creatinine descreases" 192:1 192:3
r="nm"
ln="narrative"
53:
m="multivitamins with minerals" 193:1 193:3
do="one tablet" 193:4 193:5
mo="p.o." 193:6 193:6
f="q.d." 193:7 193:7
du="nm"
r="nm"
ln="list"
54:
m="coumadin" 194:1 194:1
do="5 mg" 194:2 194:3
mo="p.o." 194:4 194:4
f="q.h.s." 194:5 194:5
du="nm"
r="nm"
ln="list"
55:
m="zocor" 195:1 195:1
do="40 mg" 195:2 195:3
mo="p.o." 195:4 195:4
f="q.h.s." 195:5 195:5
du="nm"
r="nm"
ln="list"
56:
m="toprol xl" 196:1 196:2
do="nm"
mo="p.o." 196:3 196:3
f="q.d." 196:4 196:4
du="nm"
r="nm"
ln="list"
57:
m="imdur" 197:1 197:1
do="30 mg" 197:2 197:3
mo="p.o." 197:4 197:4
f="q.d." 197:5 197:5
du="nm"
r="nm"
ln="list"
58:
m="bactrim" 198:1 198:1
do="one tablet" 198:2 198:3
mo="p.o." 198:4 198:4
f="b.i.d." 198:5 198:5
du="for 7 days" 198:6 198:8
r="nm"
ln="list"
59:
m="prednisolone acetate 0.125%" 200:1 200:3
do="one drop" 200:4 200:5
mo="ou" 200:6 200:6
f="q.i.d." 200:7 200:7
du="nm"
r="nm"
ln="list"
60:
m="nexium" 201:1 201:1
do="40 mg" 201:2 201:3
mo="p.o." 201:4 201:4
f="q.d." 201:5 201:5
du="nm"
r="nm"
ln="list"
61:
m="albuterol inhaler" 202:1 202:2
do="2 puffs" 202:3 202:4
mo="inhaler" 202:5 202:5
f="q.i.d. p.r.n." 202:6 202:7
du="nm"
r="wheezing" 202:8 202:8
ln="list"
62:
m="miconazole nitrate powder" 203:1 203:3
do="nm"
mo="topical" 203:4 203:4
f="b.i.d. p.r.n." 203:5 203:6
du="nm"
r="nm"
ln="list"
63:
m="coumadin" 204:6 204:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="known paroxysmal atrial fibrillation" 205:0 205:3
ln="narrative"
