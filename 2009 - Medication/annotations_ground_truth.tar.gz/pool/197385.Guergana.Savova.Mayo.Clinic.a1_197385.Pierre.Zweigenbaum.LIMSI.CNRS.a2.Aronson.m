1:
m="lovenox" 12:5 12:5
do="nm"
mo="nm"
f="7pm" 12:2 12:2
du="nm"
r="nm"
ln="list"
2:
m="ecasa" 17:0 17:0
do="325 mg" 17:1 17:2
mo="po" 17:3 17:3
f="qd" 17:4 17:4
du="nm"
r="nm"
ln="list"
3:
m="coumadin" 20:3 20:3
do="nm"
mo="po" 20:4 20:4
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="aspirin" 21:3 21:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="warfarin" 21:5 21:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="coumadin" 24:3 24:3
do="5 mg" 24:5 24:6
mo="po" 24:4 24:4
f="qpm" 24:7 24:7
du="nm"
r="nm"
ln="list"
7:
m="aspirin" 25:3 25:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="warfarin" 25:5 25:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="coumadin" 28:3 28:3
do="nm"
mo="po" 28:4 28:4
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="aspirin" 29:3 29:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="warfarin" 29:5 29:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="atenolol" 31:0 31:0
do="100 mg" 31:1 31:2
mo="po" 31:3 31:3
f="qd" 31:4 31:4
du="nm"
r="nm"
ln="list"
13:
m="lasix ( furosemide )" 32:0 32:3
do="40 mg" 32:4 32:5
mo="po" 32:6 32:6
f="qd" 32:7 32:7
du="nm"
r="nm"
ln="list"
14:
m="lisinopril" 33:0 33:0
do="5 mg" 33:1 33:2
mo="po" 33:3 33:3
f="qd" 33:4 33:4
du="nm"
r="nm"
ln="list"
15:
m="potassium chloride" 36:3 36:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="lisinopril" 37:0 37:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="nitroglycerin 1/150 ( 0.4 mg )" 38:0 38:5
do="1 tab" 38:6 38:7
mo="sl" 38:8 38:8
f="q5min x 3 prn" 38:9 39:0
du="nm"
r="chest pain" 39:1 39:2
ln="list"
18:
m="coumadin ( warfarin sodium )" 40:0 40:4
do="5 mg" 40:5 40:6
mo="po" 40:7 40:7
f="qpm" 40:8 40:8
du="nm"
r="nm"
ln="list"
19:
m="aspirin" 46:3 46:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="warfarin" 46:5 46:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="atorvastatin calcium" 47:3 47:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="warfarin" 48:0 48:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="lovenox ( enoxaparin )" 49:0 49:3
do="90 mg" 49:4 49:5
mo="sc" 49:6 49:6
f="bid" 49:7 49:7
du="nm"
r="nm"
ln="list"
24:
m="enoxaparin sodium" 52:4 52:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="heparin" 52:2 52:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="flovent ( fluticasone propionate )" 54:0 54:4
do="110 mcg" 54:5 54:6
mo="inh" 54:7 54:7
f="bid" 54:8 54:8
du="nm"
r="nm"
ln="list"
27:
m="lipitor ( atorvastatin )" 55:0 55:3
do="80 mg" 55:4 55:5
mo="po" 55:6 55:6
f="qd" 55:7 55:7
du="nm"
r="nm"
ln="list"
28:
m="coumadin" 58:3 58:3
do="nm"
mo="po" 58:4 58:4
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="atorvastatin calcium" 59:3 59:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="warfarin" 60:0 60:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="coumadin" 63:3 63:3
do="5 mg" 63:5 63:6
mo="po" 63:4 63:4
f="qpm" 63:7 63:7
du="nm"
r="nm"
ln="list"
32:
m="atorvastatin calcium" 64:3 64:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="warfarin" 65:0 65:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="coumadin" 68:3 68:3
do="nm"
mo="po" 68:4 68:4
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="atorvastatin calcium" 69:3 69:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="warfarin" 70:0 70:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="plavix ( clopidogrel )" 71:0 71:3
do="75 mg" 71:4 71:5
mo="po" 71:6 71:6
f="qd" 71:7 71:7
du="nm"
r="nm"
ln="list"
38:
m="magnesium oxide ( 241 mg elemental mg )" 73:0 73:7
do="800 mg" 73:8 73:9
mo="po" 73:10 73:10
f="bid" 73:11 73:11
du="nm"
r="nm"
ln="list"
39:
m="eptifibatide." 114:0 114:0
do="nm"
mo="nm"
f="post-procedure" 113:9 113:9
du="18 hours" 113:6 113:7
r="nm"
ln="narrative"
40:
m="combivent" 115:6 115:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="metoprolol" 115:2 115:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="norvasc" 115:4 115:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
43:
m="asa" 123:6 123:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
44:
m="atenolol" 123:13 123:13
do="100" 124:0 124:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="atorvastatin" 123:10 123:10
do="80" 123:11 123:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="clopidogrel" 123:8 123:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="captopril" 124:2 124:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="lisinopril" 124:5 124:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="o2" 125:7 125:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="lasix" 126:12 126:12
do="80" 127:0 127:0
mo="iv" 127:1 127:1
f="bid" 127:2 127:2
du="for 3 days" 127:7 127:9
r="nm"
ln="narrative"
51:
m="lasix" 127:15 127:15
do="40" 127:16 127:16
mo="po" 127:14 127:14
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="beta-blocker" 132:5 132:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="goal rate" 133:2 133:3
ln="narrative"
53:
m="atenolol" 133:11 133:11
do="100 mg" 133:12 133:13
mo="po" 134:0 134:0
f="qd" 134:1 134:1
du="nm"
r="nm"
ln="narrative"
54:
m="diltiazem" 133:0 133:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="goal rate" 133:2 133:3
ln="narrative"
55:
m="heparin" 135:9 135:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="coumadin" 136:2 136:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="lovenox" 136:5 136:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
58:
m="mg oxide" 141:4 141:5
do="800 mg" 141:14 141:15
mo="po" 141:16 141:16
f="bid;." 142:0 142:0
du="nm"
r="long qtc" 141:7 141:8
ln="narrative"
59:
m="plavix" 149:14 149:14
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
