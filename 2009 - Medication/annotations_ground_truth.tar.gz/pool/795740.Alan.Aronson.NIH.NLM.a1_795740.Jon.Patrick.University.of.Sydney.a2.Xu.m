1:
m="aspirin" 26:1 26:1
do="325 mg" 26:2 26:3
mo="nm"
f="once a day;" 26:4 26:6
du="nm"
r="nm"
ln="list"
2:
m="digoxin" 26:7 26:7
do="0.125 mg" 26:8 26:9
mo="nm"
f="once a day;" 26:10 27:0
du="nm"
r="nm"
ln="list"
3:
m="ultralente" 27:7 27:7
do="14 mg" 27:8 27:9
mo="nm"
f="q.a.m." 27:10 27:10
du="nm"
r="nm"
ln="list"
4:
m="ultralente" 27:7 27:7
do="4 mg" 27:12 27:13
mo="nm"
f="q.p.m.;" 28:0 28:0
du="nm"
r="nm"
ln="list"
5:
m="zestril" 27:1 27:1
do="2.5 mg" 27:2 27:3
mo="nm"
f="once a day;" 27:4 27:6
du="nm"
r="nm"
ln="list"
6:
m="imdur" 28:13 28:13
do="30 mg" 28:14 29:0
mo="nm"
f="once a day;" 29:1 29:3
du="nm"
r="nm"
ln="list"
7:
m="toprol" 28:7 28:7
do="25 mg" 28:8 28:9
mo="nm"
f="once a day" 28:10 28:12
du="nm"
r="nm"
ln="list"
8:
m="zocor" 28:1 28:1
do="10 mg" 28:2 28:3
mo="nm"
f="once a day;" 28:4 28:6
du="nm"
r="nm"
ln="list"
9:
m="dilaudid" 29:11 29:11
do="nm"
mo="nm"
f="p.r.n." 29:12 29:12
du="nm"
r="nm"
ln="list"
10:
m="torsemide" 29:4 29:4
do="100 mg" 29:5 29:6
mo="nm"
f="once a day;" 29:7 29:9
du="nm"
r="nm"
ln="list"
11:
m="antibiotics" 33:0 33:0
do="nm"
mo="iv" 32:8 32:8
f="nm"
du="nm"
r="left thigh bypass graft wound." 34:2 34:6
ln="narrative"
12:
m="heparin solution." 40:0 40:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="flagyl" 43:8 43:8
do="nm"
mo="p.o." 43:7 43:7
f="nm"
du="nm"
r="C. diff." 44:2 44:3
ln="narrative"
14:
m="levofloxacin" 43:4 43:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="vancomycin" 43:2 43:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="flagyl" 48:2 48:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nausea" 47:9 47:9
ln="narrative"
17:
m="torsemide" 50:6 50:6
do="100 mg" 51:0 51:1
mo="nm"
f="b.i.d." 51:2 51:2
du="nm"
r="nm"
ln="narrative"
18:
m="torsemide" 50:6 50:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="lasix" 51:12 51:12
do="nm"
mo="iv" 51:11 51:11
f="p.r.n." 52:2 52:2
du="nm"
r="nm"
ln="narrative"
20:
m="morphine" 54:10 54:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="pain medications." 55:10 56:0
do="nm"
mo="p.o." 55:9 55:9
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="zestril" 56:3 56:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="supplements" 60:0 60:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="wound healing." 60:8 60:9
ln="narrative"
24:
m="vitamin c" 60:2 60:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="wound healing." 60:8 60:9
ln="narrative"
25:
m="zinc" 60:6 60:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="wound healing." 60:8 60:9
ln="narrative"
26:
m="enteric-coated aspirin" 64:3 64:4
do="325 mg" 64:5 64:6
mo="nm"
f="once a day;" 64:7 65:1
du="nm"
r="nm"
ln="narrative"
27:
m="digoxin" 65:2 65:2
do="0.125" 65:3 65:3
mo="nm"
f="once a day;" 65:4 65:6
du="nm"
r="nm"
ln="narrative"
28:
m="ultralente" 65:7 65:7
do="16 units" 65:8 65:9
mo="nm"
f="q.a.m." 65:10 65:10
du="nm"
r="nm"
ln="narrative"
29:
m="ultralente" 65:7 65:7
do="4 units" 65:12 66:0
mo="nm"
f="q.p.m.;" 66:1 66:1
du="nm"
r="nm"
ln="narrative"
30:
m="toprol" 66:8 66:8
do="25 mg" 66:9 66:10
mo="nm"
f="once a day;" 66:11 66:13
du="nm"
r="nm"
ln="narrative"
31:
m="zocor" 66:2 66:2
do="10 mg" 66:3 66:4
mo="nm"
f="once a day;" 66:5 66:7
du="nm"
r="nm"
ln="narrative"
32:
m="imdur" 67:0 67:0
do="30 mg" 67:1 67:2
mo="nm"
f="once a day;" 67:3 67:5
du="nm"
r="nm"
ln="narrative"
33:
m="lisinopril" 67:12 67:12
do="2.5 mg" 68:0 68:1
mo="nm"
f="once a day;" 68:2 68:4
du="nm"
r="nm"
ln="narrative"
34:
m="torsemide" 67:6 67:6
do="100 mg" 67:7 67:8
mo="nm"
f="once a day;" 67:9 67:11
du="nm"
r="nm"
ln="narrative"
35:
m="colace;" 68:5 68:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="percocet." 68:7 68:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
