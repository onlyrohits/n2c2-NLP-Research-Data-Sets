1:
m="acetylsalicylic acid" 17:0 17:1
do="81 mg" 17:2 17:3
mo="po" 17:4 17:4
f="qd" 17:5 17:5
du="nm"
r="nm"
ln="list"
2:
m="amitriptyline hcl" 18:0 18:1
do="25 mg" 18:2 18:3
mo="po" 18:4 18:4
f="qhs" 18:5 18:5
du="nm"
r="nm"
ln="list"
3:
m="furosemide" 19:0 19:0
do="40 mg" 19:1 19:2
mo="po" 19:3 19:3
f="qd" 19:4 19:4
du="nm"
r="nm"
ln="list"
4:
m="furosemide" 22:3 22:3
do="nm"
mo="po" 22:4 22:4
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="glyburide" 25:0 25:0
do="10 mg" 25:1 25:2
mo="po" 25:3 25:3
f="bid" 25:4 25:4
du="nm"
r="nm"
ln="list"
6:
m="glyburide" 28:3 28:3
do="nm"
mo="po" 28:4 28:4
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="novolin innolet 70/30 ( insulin 70/30 ( human ) )" 31:0 31:9
do="100 units" 32:0 32:1
mo="sc" 32:2 32:2
f="bid" 32:3 32:3
du="number of doses required ( approximate ): 8" 33:0 33:7
r="nm"
ln="list"
8:
m="norvasc ( amlodipine )" 34:0 34:3
do="10 mg" 34:4 34:5
mo="po" 34:6 34:6
f="qd" 34:7 34:7
du="nm"
r="nm"
ln="list"
9:
m="lipitor ( atorvastatin )" 37:0 37:3
do="10 mg" 37:4 37:5
mo="po" 37:6 37:6
f="qd" 37:7 37:7
du="nm"
r="nm"
ln="list"
10:
m="clotrimazole 1% cream" 40:3 40:5
do="nm"
mo="tp" 40:6 40:6
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="atorvastatin calcium" 41:2 41:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="clotrimazole" 41:5 41:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="lipitor" 45:3 45:3
do="nm"
mo="po" 45:4 45:4
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="lipitor" 47:6 47:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="lopressor" 75:3 75:3
do="nm"
mo="iv" 75:2 75:2
f="nm"
du="nm"
r="bp elevated" 74:7 74:8
ln="narrative"
16:
m="nitro paste" 75:5 75:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="bp elevated" 74:7 74:8
ln="narrative"
17:
m="asa" 79:5 79:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="adenosine" 80:5 80:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="home meds" 85:3 85:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="dm" 85:1 85:1
ln="narrative"
20:
m="ssi" 85:5 85:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="dm" 85:1 85:1
ln="narrative"
21:
m="adenosine" 92:6 92:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
