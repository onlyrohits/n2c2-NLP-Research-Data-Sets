1:
m="nitroglycerin" 29:4 29:4
do="four" 29:2 29:2
mo="sublingual" 29:3 29:3
f="nm"
du="nm"
r="his pain" 28:8 28:9
ln="narrative"
2:
m="morphine" 31:6 31:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="nifedipine" 31:8 31:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="tng" 31:4 31:4
do="nm"
mo="iv" 31:3 31:3
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="morphine" 34:9 34:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="the patient's pain" 33:2 33:4
ln="narrative"
6:
m="heparin" 35:1 35:1
do="nm"
mo="iv" 35:0 35:0
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="lovastatin" 42:0 42:0
do="20 mg" 42:6 42:7
mo="nm"
f="q p.m." 42:8 42:9
du="nm"
r="nm"
ln="list"
8:
m="lovastatin" 42:0 42:0
do="40 mg" 42:1 42:2
mo="nm"
f="q q.m." 42:3 42:4
du="nm"
r="nm"
ln="list"
9:
m="enteric-coated aspirin" 43:0 43:1
do="one tablet" 43:2 43:3
mo="nm"
f="q day" 43:4 43:5
du="nm"
r="nm"
ln="list"
10:
m="heparin" 44:11 44:11
do="nm"
mo="iv" 44:10 44:10
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="morphine" 44:16 44:16
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="nifedipine" 44:13 44:13
do="nm"
mo="sl" 44:14 44:14
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="nitroglycerin" 44:8 44:8
do="nm"
mo="iv" 44:7 44:7
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="aspirin" 45:2 45:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="lovastatin" 45:4 45:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="oxygen" 59:11 59:11
do="4 liters" 59:8 59:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="heparin" 79:7 79:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="heparin" 93:5 93:5
do="nm"
mo="iv" 93:4 93:4
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="aspirin" 94:7 94:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="nitroglycerine" 94:0 94:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="lovastatin" 95:0 95:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="morphine sulfate" 95:7 95:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="the patient's pain" 95:1 95:3
ln="narrative"
23:
m="heparin" 102:3 102:3
do="nm"
mo="iv" 102:2 102:2
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="nitroglycerin" 102:0 102:0
do="nm"
mo="iv" 101:9 101:9
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="nitroglycerin" 113:2 113:2
do="one" 113:0 113:0
mo="sublingual" 113:1 113:1
f="nm"
du="nm"
r="st depression" 111:6 111:7
ln="narrative"
26:
m="cardiac medications" 129:8 129:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="biaxin" 155:8 155:8
do="500 mg" 155:9 156:0
mo="po" 156:1 156:1
f="bid" 156:2 156:2
du="nm"
r="temperature" 154:5 154:5
ln="narrative"
28:
m="tylenol" 155:4 155:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="temperature" 154:5 154:5
ln="narrative"
29:
m="biaxin" 156:11 156:11
do="nm"
mo="oral" 156:10 156:10
f="nm"
du="five day course" 156:6 156:8
r="fever" 157:3 157:3
ln="narrative"
30:
m="lasix" 165:2 165:2
do="nm"
mo="iv" 165:1 165:1
f="daily" 164:8 164:8
du="nm"
r="early congestive heart failure" 163:9 164:2
ln="narrative"
31:
m="lasix" 167:1 167:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="enteric-coated aspirin" 169:1 169:2
do="325 mg" 169:3 169:4
mo="po" 169:5 169:5
f="q day" 169:6 169:7
du="nm"
r="nm"
ln="list"
33:
m="cholestyramine" 170:1 170:1
do="one packet" 170:2 170:3
mo="po" 170:4 170:4
f="q hs" 170:5 170:6
du="nm"
r="nm"
ln="list"
34:
m="lovastatin" 171:1 171:1
do="20 mg" 171:2 171:3
mo="po" 171:4 171:4
f="q hs" 171:5 171:6
du="nm"
r="nm"
ln="list"
35:
m="lopressor" 172:1 172:1
do="50 mg" 172:2 172:3
mo="po" 172:4 172:4
f="tid" 172:5 172:5
du="nm"
r="nm"
ln="list"
36:
m="nitroglycerin 1/150 tablets" 173:2 173:4
do="nm"
mo="sublingual" 173:1 173:1
f="prn" 173:8 173:8
du="nm"
r="chest pain" 174:1 174:2
ln="list"
37:
m="nitroglycerin" 178:8 178:8
do="nm"
mo="sublingual" 178:7 178:7
f="nm"
du="nm"
r="chest pain" 177:11 178:0
ln="narrative"
