1:
m="cytovene" 29:6 29:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="ganciclovir" 29:1 29:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="cytomegalovirus infection" 27:1 27:2
ln="narrative"
3:
m="ganciclovir" 36:0 36:0
do="nm"
mo="nm"
f="nm"
du="five days" 37:1 37:2
r="cough" 34:0 34:0
ln="narrative"
4:
m="ganciclovir" 36:0 36:0
do="nm"
mo="nm"
f="nm"
du="five days" 37:1 37:2
r="dizziness" 34:6 34:6
ln="narrative"
5:
m="ganciclovir" 36:0 36:0
do="nm"
mo="nm"
f="nm"
du="five days" 37:1 37:2
r="dyspnea" 34:12 34:12
ln="narrative"
6:
m="ganciclovir" 36:0 36:0
do="nm"
mo="nm"
f="nm"
du="five days" 37:1 37:2
r="fatigue" 34:2 34:2
ln="narrative"
7:
m="ganciclovir" 36:0 36:0
do="nm"
mo="nm"
f="nm"
du="five days" 37:1 37:2
r="headache" 34:4 34:4
ln="narrative"
8:
m="ganciclovir" 36:0 36:0
do="nm"
mo="nm"
f="nm"
du="five days" 37:1 37:2
r="nm"
ln="narrative"
9:
m="ganciclovir" 36:0 36:0
do="nm"
mo="nm"
f="nm"
du="five days" 37:1 37:2
r="sweats" 34:8 34:8
ln="narrative"
10:
m="ganciclovir" 39:8 39:8
do="nm"
mo="nm"
f="nm"
du="until may , 1997" 40:6 40:9
r="nm"
ln="narrative"
11:
m="nph insulin" 58:7 58:8
do="14 units" 58:9 59:0
mo="nm"
f="q.a.m." 59:1 59:1
du="nm"
r="nm"
ln="list"
12:
m="synthroid" 58:2 58:2
do="150 mcg" 58:3 58:4
mo="nm"
f="q.d." 58:5 58:5
du="nm"
r="nm"
ln="list"
13:
m="regular insulin" 59:3 59:4
do="nm"
mo="nm"
f="p.r.n." 59:5 59:5
du="nm"
r="nm"
ln="list"
14:
m="nadolol" 60:0 60:0
do="80 mg" 60:1 60:2
mo="nm"
f="q.d." 60:3 60:3
du="nm"
r="nm"
ln="list"
15:
m="neoral" 60:10 60:10
do="100 mg" 60:11 60:12
mo="nm"
f="b.i.d." 60:13 60:13
du="nm"
r="nm"
ln="list"
16:
m="prednisone" 60:5 60:5
do="10 mg" 60:6 60:7
mo="nm"
f="q.d." 60:8 60:8
du="nm"
r="nm"
ln="list"
17:
m="axid" 61:5 61:5
do="150 mg" 61:6 61:7
mo="nm"
f="q.d." 61:8 61:8
du="nm"
r="nm"
ln="list"
18:
m="cellcept" 61:0 61:0
do="1 g" 61:1 61:2
mo="nm"
f="b.i.d." 61:3 61:3
du="nm"
r="nm"
ln="list"
19:
m="lasix" 61:10 61:10
do="80 mg" 61:11 61:12
mo="p.o." 61:13 61:13
f="p.r.n." 61:14 61:14
du="nm"
r="nm"
ln="list"
20:
m="coumadin" 62:0 62:0
do="4 mg" 62:1 62:2
mo="nm"
f="q.d." 62:3 62:3
du="nm"
r="nm"
ln="list"
21:
m="oxygen" 69:9 69:9
do="4 l" 69:7 69:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="antibiotics" 94:2 94:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="vancomycin" 94:7 94:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="flagyl" 95:2 95:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="gentamicin" 95:0 95:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="gentamycin" 95:7 95:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="ceftazidime" 96:3 96:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="antibiotics" 99:6 99:6
do="nm"
mo="intravenous" 99:5 99:5
f="nm"
du="until hospital day four." 100:1 100:4
r="nm"
ln="narrative"
29:
m="levaquin" 99:1 99:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="antibiotics" 102:3 102:3
do="nm"
mo="oral" 102:2 102:2
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="augmentin" 102:8 102:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="levaquin" 102:6 102:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="antibiotics." 106:2 106:2
do="nm"
mo="oral" 106:1 106:1
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="nadolol" 108:4 108:4
do="40 mg" 109:3 109:4
mo="nm"
f="q.d." 109:5 109:5
du="nm"
r="hypertension" 107:8 107:8
ln="narrative"
35:
m="nadolol" 108:4 108:4
do="80 mg" 109:7 109:8
mo="nm"
f="q.d." 109:9 109:9
du="nm"
r="hypertension" 107:8 107:8
ln="narrative"
36:
m="nadolol" 110:5 110:5
do="80 mg" 110:1 110:2
mo="nm"
f="q.d." 110:3 110:3
du="nm"
r="his blood pressures" 110:9 110:11
ln="narrative"
37:
m="antihypertensive medication" 112:7 112:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="nifedipine xl" 113:1 113:2
do="30 mg" 113:12 114:0
mo="nm"
f="nm"
du="for two days" 113:8 113:10
r="nm"
ln="narrative"
39:
m="this medication" 114:2 114:3
do="30 mg" 113:12 114:0
mo="nm"
f="nm"
du="for two days" 113:8 113:10
r="his blood pressures" 114:5 114:7
ln="narrative"
40:
m="oxygen" 133:5 133:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="antibiotics" 134:0 134:0
do="nm"
mo="intravenous" 133:8 133:8
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="anticoagulation" 144:8 144:8
do="4 mg" 145:6 145:7
mo="nm"
f="daily" 145:8 145:8
du="nm"
r="atrial fibrillation" 145:3 145:4
ln="narrative"
43:
m="cyclosporine" 152:0 152:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="cyclosporine" 155:1 155:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="vancomycin" 155:7 155:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="antibiotics" 157:7 157:7
do="nm"
mo="intravenous" 157:6 157:6
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="thyroid" 160:4 160:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="hyperthyroidism" 160:2 160:2
ln="narrative"
48:
m="synthroid" 166:3 166:3
do="125 mcg" 166:9 166:10
mo="nm"
f="daily" 167:0 167:0
du="nm"
r="nm"
ln="narrative"
49:
m="steroid" 169:0 169:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="cozaar" 171:7 171:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="cortizone" 172:11 172:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="augmentin" 175:2 175:2
do="250/125 mg" 175:3 175:4
mo="nm"
f="t.i.d." 175:5 175:5
du="nm"
r="nm"
ln="list"
53:
m="levaquin" 175:7 175:7
do="250 mg" 175:8 176:0
mo="nm"
f="q.d." 176:1 176:1
du="nm"
r="nm"
ln="list"
54:
m="cellcept" 176:3 176:3
do="500 mg" 176:4 176:5
mo="nm"
f="b.i.d." 176:6 176:6
du="nm"
r="nm"
ln="list"
55:
m="neoral" 176:8 176:8
do="100 mg" 176:9 177:0
mo="nm"
f="b.i.d." 177:1 177:1
du="nm"
r="nm"
ln="list"
56:
m="inp insulin" 177:13 178:0
do="14 units" 178:1 178:2
mo="subcu" 178:3 178:3
f="q.a.m." 178:4 178:4
du="nm"
r="nm"
ln="list"
57:
m="prednisone" 177:3 177:3
do="10 mg" 177:4 177:5
mo="nm"
f="q.d." 177:6 177:6
du="nm"
r="nm"
ln="list"
58:
m="synthroid" 177:8 177:8
do="125 mcg" 177:9 177:10
mo="nm"
f="q.d." 177:11 177:11
du="nm"
r="nm"
ln="list"
59:
m="axid" 178:11 178:11
do="150 mg" 179:0 179:1
mo="nm"
f="q.d." 179:2 179:2
du="nm"
r="nm"
ln="list"
60:
m="regular insulin" 178:6 178:7
do="nm"
mo="subcu" 178:8 178:8
f="p.r.n." 178:9 178:9
du="nm"
r="nm"
ln="list"
61:
m="coumadin" 179:15 179:15
do="4 mg" 180:0 180:1
mo="nm"
f="q.d." 180:2 180:2
du="nm"
r="nm"
ln="list"
62:
m="nadolol" 179:4 179:4
do="80 mg" 179:5 179:6
mo="nm"
f="q.d." 179:7 179:7
du="nm"
r="nm"
ln="list"
63:
m="nifedipine xl" 179:9 179:10
do="30 mg" 179:11 179:12
mo="nm"
f="q.d." 179:13 179:13
du="nm"
r="nm"
ln="list"
64:
m="iron sulfate" 180:4 180:5
do="300 mg" 180:6 180:7
mo="nm"
f="q.d." 180:8 180:8
du="nm"
r="nm"
ln="list"
