1:
m="lipitor ( atorvastatin )" 16:0 16:3
do="40 mg" 16:4 16:5
mo="po" 16:6 16:6
f="daily" 16:7 16:7
du="nm"
r="nm"
ln="list"
2:
m="azithromycin" 18:3 18:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="atorvastatin calcium" 19:0 19:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="azithromycin" 21:0 21:0
do="250 mg" 21:1 21:2
mo="po" 21:3 21:3
f="daily" 21:4 21:4
du="x 3 doses" 21:5 21:7
r="nm"
ln="list"
5:
m="azithromycin" 26:4 26:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="simvastatin" 26:2 26:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="azithromycin" 27:5 27:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="simvastatin" 27:3 27:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="ecasa" 29:0 29:0
do="325 mg" 29:1 29:2
mo="po" 29:3 29:3
f="daily" 29:4 29:4
du="nm"
r="nm"
ln="list"
10:
m="flonase nasal spray ( fluticasone nasal spray )" 30:0 30:7
do="2 spray" 31:0 31:1
mo="na" 31:2 31:2
f="daily" 31:3 31:3
du="number of doses required ( approximate ): 6" 32:0 32:7
r="nm"
ln="list"
11:
m="lantus ( insulin glargine )" 33:0 33:4
do="100 units" 33:5 33:6
mo="sc" 33:7 33:7
f="daily" 33:8 33:8
du="nm"
r="nm"
ln="list"
12:
m="humalog insulin ( insulin lispro )" 34:0 34:5
do="12 units" 34:6 34:7
mo="sc" 34:8 34:8
f="ac" 34:9 34:9
du="nm"
r="nm"
ln="list"
13:
m="combivent ( ipratropium and albuterol sulfate )" 35:0 35:6
do="2 puff" 36:0 36:1
mo="inh" 36:2 36:2
f="qid...prn" 36:3 36:3,36:9 36:9
du="nm"
r="wheezing" 36:10 36:10
ln="list"
14:
m="loratadine" 38:0 38:0
do="10 mg" 38:1 38:2
mo="po" 38:3 38:3
f="daily" 38:4 38:4
du="nm"
r="nm"
ln="list"
15:
m="this medication" 40:0 40:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="metformin" 44:0 44:0
do="1 , 000 mg" 44:1 44:4
mo="po" 44:5 44:5
f="bid" 44:6 44:6
du="nm"
r="nm"
ln="list"
17:
m="prilosec ( omeprazole )" 45:0 45:3
do="20 mg" 45:4 45:5
mo="po" 45:6 45:6
f="daily" 45:7 45:7
du="nm"
r="nm"
ln="list"
18:
m="prilosec" 48:0 48:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="diovan ( valsartan )" 49:0 49:3
do="160 mg" 49:4 49:5
mo="po" 49:6 49:6
f="daily" 49:7 49:7
du="nm"
r="nm"
ln="list"
20:
m="potassium chloride immed. rel." 52:3 52:6
do="nm"
mo="po" 52:7 52:7
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="potassium chloride" 54:5 55:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="valsartan" 54:3 54:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="asa" 92:3 92:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="diovan" 92:1 92:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="lantus" 92:11 92:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="lipitor" 92:7 92:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="lisinopril" 92:5 92:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="metformin" 92:9 92:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="humalog" 93:0 93:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="asa" 107:12 107:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="statin." 108:0 108:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="anti-htnsive regimen." 110:0 110:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="ppi." 115:4 115:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="gerd" 114:9 114:9
ln="narrative"
34:
m="z-pak." 115:13 115:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="flonase" 116:1 116:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="pnd." 116:5 116:5
ln="narrative"
36:
m="inhalers" 116:6 116:6
do="nm"
mo="nm"
f="prn" 117:1 117:1
du="nm"
r="wheezing" 117:0 117:0
ln="narrative"
37:
m="loratidine" 116:3 116:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="pnd." 116:5 116:5
ln="narrative"
38:
m="lovenox" 121:2 121:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="nexium" 122:0 122:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="nexium" 122:0 122:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="your medications" 129:7 129:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
