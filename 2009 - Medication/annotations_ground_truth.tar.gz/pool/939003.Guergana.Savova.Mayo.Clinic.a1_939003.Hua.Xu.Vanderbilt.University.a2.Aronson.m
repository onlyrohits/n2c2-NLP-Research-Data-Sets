1:
m="ecasa ( aspirin enteric coated )" 19:0 19:5
do="325 mg" 19:6 19:7
mo="po" 19:8 19:8
f="qd" 19:9 19:9
du="nm"
r="nm"
ln="list"
2:
m="atenolol" 20:0 20:0
do="50 mg" 20:1 20:2
mo="po" 20:3 20:3
f="qd" 20:4 20:4
du="nm"
r="nm"
ln="list"
3:
m="klonopin ( clonazepam )" 22:0 22:3
do="1 mg" 22:4 22:5
mo="po" 22:6 22:6
f="tid" 22:7 22:7
du="nm"
r="nm"
ln="list"
4:
m="azithromycin" 25:3 25:3
do="nm"
mo="po" 25:4 25:4
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="azithromycin" 26:5 26:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="clonazepam" 26:3 26:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="azithromycin" 29:3 29:3
do="nm"
mo="po" 29:4 29:4
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="azithromycin" 30:5 30:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="clonazepam" 30:3 30:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="colace ( docusate sodium )" 32:0 32:4
do="100 mg" 32:5 32:6
mo="po" 32:7 32:7
f="bid" 32:8 32:8
du="nm"
r="nm"
ln="list"
11:
m="prozac ( fluoxetine hcl )" 33:0 33:4
do="20 mg" 33:5 33:6
mo="po" 33:7 33:7
f="qd" 33:8 33:8
du="nm"
r="nm"
ln="list"
12:
m="zestril ( lisinopril )" 34:0 34:3
do="10 mg" 34:4 34:5
mo="po" 34:6 34:6
f="qd" 34:7 34:7
du="nm"
r="nm"
ln="list"
13:
m="niferex-150" 35:0 35:0
do="150 mg" 35:1 35:2
mo="po" 35:3 35:3
f="bid" 35:4 35:4
du="nm"
r="nm"
ln="list"
14:
m="percocet" 36:0 36:0
do="1 tab" 36:1 36:2
mo="po" 36:3 36:3
f="q6h ... prn" 36:4 36:4,37:0 37:0
du="x 7 days" 36:5 36:7
r="pain" 37:1 37:1
ln="list"
15:
m="azithromycin" 38:0 38:0
do="250 mg" 38:1 38:2
mo="po" 38:3 38:3
f="qd" 38:4 38:4
du="x 4 days" 38:5 38:7
r="nm"
ln="list"
16:
m="azithromycin" 42:5 42:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="clonazepam" 42:3 42:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="azithromycin" 43:5 43:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="clonazepam" 43:3 43:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="prilosec ( omeprazole )" 45:0 45:3
do="20 mg" 45:4 45:5
mo="po" 45:6 45:6
f="qd" 45:7 45:7
du="nm"
r="nm"
ln="list"
21:
m="albuterol inhaler" 46:0 46:1
do="2 puff" 46:2 46:3
mo="inh" 46:4 46:4
f="qid" 46:5 46:5
du="nm"
r="nm"
ln="list"
22:
m="atrovent inhaler ( ipratropium inhaler )" 47:0 47:5
do="2 puff" 47:6 47:7
mo="inh" 47:8 47:8
f="qid" 47:9 47:9
du="nm"
r="nm"
ln="list"
23:
m="prednisone" 48:0 48:0
do="10 mg" 54:1 54:2
mo="po" 48:2 48:2
f="qd" 54:3 54:3
du="x 2 day( s )" 54:4 54:8
r="nm"
ln="list"
24:
m="prednisone" 48:0 48:0
do="20 mg" 53:1 53:2
mo="po" 48:2 48:2
f="qd" 53:3 53:3
du="x 2 day( s )" 53:4 53:8
r="nm"
ln="list"
25:
m="prednisone" 48:0 48:0
do="30 mg" 52:1 52:2
mo="po" 48:2 48:2
f="qd" 52:3 52:3
du="x 2 day( s )" 52:4 52:8
r="nm"
ln="list"
26:
m="prednisone" 48:0 48:0
do="40 mg" 51:1 51:2
mo="po" 48:2 48:2
f="qd" 51:3 51:3
du="x 2 day( s )" 51:4 51:8
r="nm"
ln="list"
27:
m="prednisone" 48:0 48:0
do="50 mg" 50:1 50:2
mo="po" 48:2 48:2
f="qd" 50:3 50:3
du="x 2 day( s )" 50:4 50:8
r="nm"
ln="list"
28:
m="prednisone" 48:0 48:0
do="5 mg" 55:1 55:2
mo="po" 48:2 48:2
f="qd" 55:3 55:3
du="x 2 day( s )" 55:4 55:8
r="nm"
ln="list"
29:
m="prednisone" 48:0 48:0
do="60 mg" 49:1 49:2
mo="po" 48:2 48:2
f="qd" 49:3 49:3
du="x 2 day( s )" 49:4 49:8
r="nm"
ln="list"
30:
m="ativan" 76:2 76:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="anxiety." 75:7 75:7
ln="narrative"
31:
m="macrolide antibio tic" 76:11 77:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="tracheobronchitis" 77:5 77:5
ln="narrative"
