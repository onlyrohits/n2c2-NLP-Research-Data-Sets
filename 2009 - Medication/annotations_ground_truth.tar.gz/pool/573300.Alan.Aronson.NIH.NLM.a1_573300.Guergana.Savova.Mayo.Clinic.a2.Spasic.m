1:
m="drugs/beta-blocker." 25:0 25:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="afib/flutter" 24:5 24:5
ln="narrative"
2:
m="coumadin" 38:9 38:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="lasix" 38:11 38:11
do="20 mg" 38:12 38:13
mo="nm"
f="daily" 39:0 39:0
du="nm"
r="nm"
ln="list"
4:
m="toprol" 38:0 38:0
do="25 mg" 38:5 38:6
mo="nm"
f="q.p.m." 38:7 38:7
du="nm"
r="nm"
ln="list"
5:
m="toprol" 38:0 38:0
do="50 mg" 38:1 38:2
mo="nm"
f="q.a.m." 38:3 38:3
du="nm"
r="nm"
ln="list"
6:
m="atorvastatin" 39:2 39:2
do="20 mg" 39:3 39:4
mo="nm"
f="daily" 39:5 39:5
du="nm"
r="nm"
ln="list"
7:
m="neurontin" 39:7 39:7
do="100 mg" 39:8 39:9
mo="nm"
f="t.i.d." 39:10 39:10
du="nm"
r="nm"
ln="list"
8:
m="glipizide" 40:6 40:6
do="2.5 mg" 40:7 40:8
mo="nm"
f="b.i.d." 40:9 40:9
du="nm"
r="nm"
ln="list"
9:
m="metformin" 40:0 40:0
do="1000 mg" 40:1 40:2
mo="nm"
f="b.i.d." 40:3 40:3
du="nm"
r="nm"
ln="list"
10:
m="aspirin" 97:3 97:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="coumadin." 97:8 97:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="lopressor" 97:5 97:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="lopressor" 98:3 98:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="o2" 101:6 101:6
do="5 liters" 101:3 101:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="lasix" 102:4 102:4
do="20 mg" 102:5 102:6
mo="iv" 102:7 102:7
f="t.i.d." 102:8 102:8
du="nm"
r="pulmonary edema" 101:9 102:0
ln="narrative"
16:
m="osmolite" 104:1 104:1
do="20 ml" 104:5 104:6
mo="tube feeds" 104:2 104:3
f="an hour." 104:7 104:8
du="nm"
r="nm"
ln="narrative"
17:
m="aspirin" 109:2 109:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 109:4 109:5
ln="narrative"
18:
m="coumadin" 109:0 109:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation." 109:4 109:5
ln="narrative"
19:
m="antibiotics" 110:4 110:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="chest tubes" 110:6 110:7
ln="narrative"
20:
m="meds" 115:1 115:1
do="nm"
mo="iv" 115:2 115:2
f="nm"
du="until tube replaced and kub confirmed tip" 115:4 115:10
r="nm"
ln="narrative"
21:
m="o2" 121:2 121:2
do="3 liters" 120:11 121:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="lopressor" 126:0 126:0
do="75 mg" 126:1 126:2
mo="p.o." 126:3 126:3
f="q.i.d." 126:4 126:4
du="nm"
r="afib" 125:1 125:1
ln="narrative"
23:
m="lopressor" 128:10 128:10
do="nm"
mo="iv" 128:9 128:9
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="lopressor" 128:6 128:6
do="nm"
mo="oral" 128:5 128:5
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="o2" 131:2 131:2
do="1.5 liters" 130:8 131:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="beta-blocker" 134:2 134:2
do="titrate" 134:1 134:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="electrolytes." 134:0 134:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="lopressor." 139:10 139:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="afib" 139:8 139:8
ln="narrative"
29:
m="celexa." 146:5 146:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="postoperative confusion/possible suicidal ideation." 145:5 146:1
ln="narrative"
30:
m="cipro" 147:6 147:6
do="nm"
mo="nm"
f="nm"
du="x3 days." 148:0 148:1
r="probable enterogram-negative rods" 147:2 147:4
ln="narrative"
31:
m="celexa" 151:0 151:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="psych." 151:3 151:3
ln="narrative"
32:
m="coumadin" 156:7 156:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="afib" 156:9 156:9
ln="narrative"
33:
m="acetaminophen" 182:0 182:0
do="325-650 mg" 182:1 182:2
mo="nm"
f="q. 4h. p.r.n." 182:3 182:5
du="nm"
r="pain" 182:6 182:6
ln="list"
34:
m="acetaminophen" 182:0 182:0
do="325-650 mg" 182:1 182:2
mo="nm"
f="q. 4h. p.r.n." 182:3 182:5
du="nm"
r="temperature" 182:8 182:8
ln="list"
35:
m="duoneb" 183:4 183:4
do="nm"
mo="nm"
f="q. 6h. p.r.n." 183:5 183:7
du="nm"
r="wheezing" 183:8 183:8
ln="list"
36:
m="enteric-coated aspirin" 183:10 184:0
do="81 mg" 184:1 184:2
mo="nm"
f="daily" 184:3 184:3
du="nm"
r="nm"
ln="list"
37:
m="dulcolax" 184:5 184:5
do="10 mg" 184:6 184:7
mo="pr" 184:8 184:8
f="daily p.r.n." 184:9 184:10
du="nm"
r="constipation" 184:11 184:11
ln="list"
38:
m="celexa" 185:0 185:0
do="10 mg" 185:1 185:2
mo="nm"
f="daily" 185:3 185:3
du="nm"
r="nm"
ln="list"
39:
m="colace" 185:5 185:5
do="100 mg" 185:6 185:7
mo="nm"
f="t.i.d." 185:8 185:8
du="nm"
r="nm"
ln="list"
40:
m="nexium" 185:10 185:10
do="20 mg" 185:11 185:12
mo="nm"
f="daily" 185:13 185:13
du="nm"
r="nm"
ln="list"
41:
m="lasix" 186:0 186:0
do="20 mg" 186:1 186:2
mo="nm"
f="daily" 186:3 186:3
du="for 5 days" 186:4 186:6
r="nm"
ln="list"
42:
m="neurontin" 186:8 186:8
do="100 mg" 186:9 186:10
mo="nm"
f="t.i.d." 186:11 186:11
du="nm"
r="nm"
ln="list"
43:
m="robitussin" 186:13 186:13
do="10 ml" 187:0 187:1
mo="nm"
f="q. 6h. p.r.n." 187:2 187:4
du="nm"
r="cough" 187:5 187:5
ln="list"
44:
m="novolog insulin" 187:7 187:8
do="sliding scale" 187:10 187:11
mo="nm"
f="at bedtime" 188:2 188:3
du="nm"
r="nm"
ln="list"
45:
m="novolog insulin" 187:7 187:8
do="sliding scale" 187:10 187:11
mo="nm"
f="q.a.c." 188:0 188:0
du="nm"
r="nm"
ln="list"
46:
m="novolog insulin" 188:5 188:6
do="14 units" 188:7 188:8
mo="subq" 188:9 188:9
f="with lunch and supper" 188:10 189:1
du="nm"
r="nm"
ln="list"
47:
m="lantus insulin" 189:11 190:0
do="42 units" 190:1 190:2
mo="subq" 190:3 190:3
f="at 10 p.m." 190:4 190:6
du="nm"
r="nm"
ln="list"
48:
m="novolog insulin" 189:3 189:4
do="22 units" 189:5 189:6
mo="subq" 189:7 189:7
f="with breakfast" 189:8 189:9
du="nm"
r="nm"
ln="list"
49:
m="atrovent nebulizers" 190:8 190:9
do="nm"
mo="nm"
f="q.i.d." 190:10 190:10
du="nm"
r="nm"
ln="list"
50:
m="k-dur" 191:0 191:0
do="10 meq" 191:1 191:2
mo="nm"
f="daily" 191:3 191:3
du="for five days" 191:4 191:6
r="nm"
ln="list"
51:
m="toprol-xl" 191:8 191:8
do="200 mg" 191:9 191:10
mo="nm"
f="b.i.d." 191:11 191:11
du="nm"
r="nm"
ln="list"
52:
m="miconazole nitrate powder" 192:0 192:2
do="nm"
mo="topical" 192:3 192:3
f="b.i.d." 192:4 192:4
du="nm"
r="nm"
ln="list"
53:
m="niferex" 192:6 192:6
do="150 mg" 192:7 192:8
mo="nm"
f="b.i.d." 192:9 192:9
du="nm"
r="nm"
ln="list"
54:
m="multivitamin therapeutic" 193:6 193:7
do="one tab" 193:8 193:9
mo="nm"
f="daily" 194:0 194:0
du="nm"
r="nm"
ln="list"
55:
m="simvastatin" 193:0 193:0
do="40 mg" 193:1 193:2
mo="nm"
f="at bedtime" 193:3 193:4
du="nm"
r="nm"
ln="list"
56:
m="coumadin" 194:2 194:2
do="variable dosage" 194:4 194:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
57:
m="boudreaux's butt paste" 195:3 195:5
do="nm"
mo="topical apply to effected areas" 195:6 195:10
f="nm"
du="nm"
r="nm"
ln="list"
