1:
m="keflex" 74:4 74:4
do="500 mg" 74:5 74:6
mo="nm"
f="q8h" 74:7 74:7
du="for nine doses" 74:8 75:0
r="nm"
ln="narrative"
2:
m="percocet" 75:2 75:2
do="1-2" 75:3 75:3
mo="p.o." 75:4 75:4
f="q6h p.r.n." 75:5 75:6
du="nm"
r="pain" 75:7 75:7
ln="narrative"
