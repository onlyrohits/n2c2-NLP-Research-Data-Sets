1:
m="ecasa ( aspirin enteric coated )" 17:0 17:5
do="325 mg" 17:6 17:7
mo="po " 17:8 17:8
f="qd " 17:9 17:9
du="nm"
r="nm"
ln="list"
2:
m="aspirin" 20:5 20:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="warfarin" 20:3 20:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="vitamin b12 ( cyanocobalamin )" 22:0 22:4
do="1 , 000 mcg" 22:5 22:8
mo="po" 22:9 22:9
f="qd" 22:10 22:10
du="number of doses required ( approximate ): 5" 23:0 23:7
r="nm"
ln="list"
5:
m="digoxin" 24:0 24:0
do="0.25 mg" 24:1 24:2
mo="po" 24:3 24:3
f="qd" 24:4 24:4
du="nm"
r="nm"
ln="list"
6:
m="colace ( docusate sodium )" 25:0 25:4
do="100 mg" 25:5 25:6
mo="po" 25:7 25:7
f="bid" 25:8 25:8
du="nm"
r="nm"
ln="list"
7:
m="lasix ( furosemide )" 26:0 26:3
do="60 mg" 26:4 26:5
mo="po" 26:6 26:6
f="bid" 26:7 26:7
du="nm"
r="nm"
ln="list"
8:
m="oxycodone" 28:0 28:0
do="5 mg" 28:1 28:2
mo="po" 28:3 28:3
f="q6h prn" 28:4 28:5
du="nm"
r="pain" 28:6 28:6
ln="list"
9:
m="coumadin ( warfarin sodium )" 29:0 29:4
do="5 mg" 29:5 29:6
mo="po" 29:7 29:7
f="qpm" 29:8 29:8
du="nm"
r="nm"
ln="list"
10:
m="ecasa" 34:3 34:3
do="nm"
mo="po" 34:4 34:4
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="aspirin" 35:5 35:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="warfarin" 35:3 35:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="lipitor" 38:3 38:3
do="nm"
mo="po" 38:4 38:4
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="atorvastatin calcium" 39:5 40:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="warfarin" 39:3 39:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="metoprolol ( sust. rel. )" 41:0 41:4
do="300 mg" 41:5 41:6
mo="po" 41:7 41:7
f="qd" 41:8 41:8
du="nm"
r="nm"
ln="list"
17:
m="diltiazem" 46:3 46:3
do="nm"
mo="po" 46:4 46:4
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="metoprolol tartrate" 47:3 47:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="diltiazem hcl" 48:0 48:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="home med" 48:5 48:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="tiazac" 51:3 51:3
do="nm"
mo="po" 51:4 51:4
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="metoprolol tartrate" 52:3 52:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="diltiazem hcl" 53:0 53:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="home med" 53:5 53:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="diltiazem sustained release" 56:3 56:5
do="nm"
mo="po" 56:6 56:6
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="metoprolol tartrate" 58:3 58:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="diltiazem hcl" 59:0 59:1
do="nm"
mo="nm"
f="nm"
du="number of doses required ( approximate ): 5" 60:0 60:7
r="nm"
ln="list"
28:
m="accupril ( quinapril )" 61:0 61:3
do="20 mg" 61:4 61:5
mo="po" 61:6 61:6
f="qd" 61:7 61:7
du="number of doses required ( approximate ): 4" 63:0 63:7
r="nm"
ln="list"
29:
m="tiazac ( diltiazem extended release )" 64:0 64:5
do="240 mg" 64:6 64:7
mo="po" 64:8 64:8
f="qam" 64:9 64:9
du="nm"
r="nm"
ln="list"
30:
m="metoprolol tartrate" 69:3 69:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="diltiazem hcl" 70:0 70:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="lipitor ( atorvastatin )" 71:0 71:3
do="80 mg" 71:4 71:5
mo="po" 71:6 71:6
f="qd" 71:7 71:7
du="nm"
r="nm"
ln="list"
33:
m="niacin" 74:3 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="vit. b-3" 74:5 74:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="atorvastatin calcium" 75:0 75:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="atorvastatin calcium" 76:5 77:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="warfarin" 76:3 76:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="niaspan ( nicotinic acid sustained release )" 78:0 78:6
do="1 gm" 78:7 78:8
mo="po" 78:9 78:9
f="qhs" 78:10 78:10
du="nm"
r="nm"
ln="list"
39:
m="lipitor" 81:3 81:3
do="nm"
mo="po" 81:4 81:4
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="niacin" 82:3 82:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="vit. b-3" 82:5 82:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="atorvastatin calcium" 83:0 83:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
43:
m="lantus ( insulin glargine )" 84:0 84:4
do="66 units" 84:5 84:6
mo="sc" 84:7 84:7
f="qpm" 84:8 84:8
du="nm"
r="nm"
ln="list"
44:
m="insulin lispro mix 75/25" 85:0 85:3
do="74 units" 85:4 85:5
mo="sc" 85:6 85:6
f="qam" 85:7 85:7
du="nm"
r="nm"
ln="list"
45:
m="insulin lispro mix 75/25" 86:0 86:3
do="54 units" 86:4 86:5
mo="sc" 86:6 86:6
f="qpm" 86:7 86:7
du="nm"
r="nm"
ln="list"
46:
m="glucometer" 87:0 87:0
do="1 ea" 87:1 87:2
mo="sc" 87:3 87:3
f="qpm" 86:7 86:7
du="x1" 87:4 87:4
r="nm"
ln="list"
47:
m="maalox-tablets quick dissolve/chewable" 88:0 88:2
do="1-2 tab" 88:3 88:4
mo="po" 88:5 88:5
f="q6h prn" 88:6 89:0
du="nm"
r="upset stomach" 89:1 89:2
ln="list"
48:
m="diltiazem" 119:6 119:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="rate controlled" 119:0 119:1
ln="narrative"
49:
m="metoprolol" 119:4 119:4
do="nm"
mo="iv" 119:3 119:3
f="nm"
du="nm"
r="rate controlled" 119:0 119:1
ln="narrative"
50:
m="asa" 126:0 126:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="ischemia." 125:6 125:6
ln="narrative"
51:
m="home meds" 126:6 126:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="rate control" 126:3 126:4
ln="narrative"
52:
m="lipitor" 127:4 127:4
do="40--&gt;80" 127:5 127:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="lipitor/niacin" 127:1 127:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="lasix" 130:1 130:1
do="40po" 130:7 130:7
mo="40po" 130:7 130:7
f="tid" 130:8 130:8
du="nm"
r="trace edema" 129:5 129:6
ln="narrative"
55:
m="lasix" 130:1 130:1
do="60" 130:3 130:3
mo="nm"
f="bid" 130:4 130:4
du="nm"
r="trace edema;" 129:5 129:6
ln="narrative"
56:
m="insulin." 132:4 132:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
