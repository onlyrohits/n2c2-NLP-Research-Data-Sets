1:
m="ecasa ( aspirin enteric coated )" 19:0 19:5
do="325 mg" 19:6 19:7
mo="po" 19:8 19:8
f="qd" 19:9 19:9
du="nm"
r="nm"
ln="list"
2:
m="captopril" 20:0 20:0
do="12.5 mg" 20:1 20:2
mo="po" 20:3 20:3
f="tid" 20:4 20:4
du="nm"
r="nm"
ln="list"
3:
m="potassium chloride" 26:3 26:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="captopril" 27:0 27:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="lasix ( furosemide )" 28:0 28:3
do="40 mg" 28:4 28:5
mo="po" 28:6 28:6
f="tid" 28:7 28:7
du="nm"
r="nm"
ln="list"
6:
m="levoxyl ( levothyroxine sodium )" 29:0 29:4
do="100 mcg" 29:5 29:6
mo="po" 29:7 29:7
f="qd" 29:8 29:8
du="nm"
r="nm"
ln="list"
7:
m="nitroglycerin" 30:0 30:0
do="1/150 ( 0.4 mg ) 1 tab" 30:1 30:7
mo="sl" 30:8 30:8
f="q5 min x 3 prn" 30:9 31:0
du="nm"
r="chest pain" 31:1 31:2
ln="list"
8:
m="zocor ( simvastatin )" 33:0 33:3
do="20 mg" 33:4 33:5
mo="po" 33:6 33:6
f="qhs" 33:7 33:7
du="nm"
r="nm"
ln="list"
9:
m="multivitamin" 38:3 38:3
do="nm"
mo="po" 38:5 38:5
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="niacin" 40:5 40:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="simvastatin" 40:3 40:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="vit. b-3" 41:0 41:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="plavix ( clopidogrel )" 42:0 42:3
do="75 mg" 42:4 42:5
mo="po" 42:6 42:6
f="qd" 42:7 42:7
du="nm"
r="nm"
ln="list"
14:
m="atenolol" 43:0 43:0
do="25 mg" 43:1 43:2
mo="po" 43:3 43:3
f="qd" 43:4 43:4
du="nm"
r="nm"
ln="list"
15:
m="nitropatch ( nitroglycerin patch )" 44:0 44:4
do="0.2 mg/hr" 44:5 44:6
mo="tp" 44:7 44:7
f="qhs" 44:8 44:8
du="nm"
r="nm"
ln="list"
16:
m="glyburide" 45:0 45:0
do="5 mg" 45:1 45:2
mo="po" 45:3 45:3
f="bid" 45:4 45:4
du="nm"
r="nm"
ln="list"
17:
m="isordil ( isosorbide dinitrate )" 46:0 46:4
do="10 mg" 46:5 46:6
mo="po" 46:7 46:7
f="bid" 46:8 46:8
du="nm"
r="nm"
ln="list"
18:
m="ntg" 71:10 71:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="sob" 70:2 70:2
ln="narrative"
19:
m="lasix" 72:1 72:1
do="120" 72:2 72:2
mo="nm"
f="nm"
du="nm"
r="sob" 70:2 70:2
ln="narrative"
20:
m="asa" 73:6 73:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="lopressor" 73:8 73:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="heparin." 74:0 74:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="ace-i" 83:15 83:15
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="asa" 83:7 83:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="heparin" 83:5 83:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="metoprolol" 83:11 83:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="nitrates" 83:13 83:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="plavix" 83:9 83:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="lasix." 84:2 84:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="statin" 84:0 84:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="lasix" 86:5 86:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="nebs" 86:8 86:8
do="nm"
mo="nm"
f="prn" 86:7 86:7
du="nm"
r="wheezing." 86:10 86:10
ln="narrative"
33:
m="synthroid." 89:1 89:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="glyburide." 90:1 90:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
