1:
m="levaquin" 37:8 37:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="an upper respiratory tract infection" 37:10 38:3
ln="narrative"
2:
m="flagyl" 38:10 38:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="a possible c. difficile infection." 39:1 39:5
ln="narrative"
3:
m="lasix" 44:1 44:1
do="60 mg" 43:13 43:14
mo="iv" 44:0 44:0
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="dilaudid" 46:9 46:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="10/10 abdominal pain" 46:2 46:4
ln="narrative"
5:
m="lasix" 69:11 69:11
do="80 mg" 69:8 69:9
mo="p.o." 69:10 69:10
f="q.o.d" 70:0 70:0
du="nm"
r="nm"
ln="list"
6:
m="lasix" 69:1 69:1
do="40 mg" 69:2 69:3
mo="p.o." 69:4 69:4
f="q.o.d." 69:5 69:5
du="nm"
r="nm"
ln="list"
7:
m="digoxin" 71:1 71:1
do="0.125 mg" 71:2 71:3
mo="nm"
f="q.o.d." 71:4 71:4
du="nm"
r="nm"
ln="list"
8:
m="digoxin" 71:1 71:1
do="0.25" 71:7 71:7
mo="nm"
f="q.o.d." 71:8 71:8
du="nm"
r="nm"
ln="list"
9:
m="lisinopril" 72:1 72:1
do="20 mg" 72:2 72:3
mo="p.o." 72:4 72:4
f="q.d." 72:5 72:5
du="nm"
r="nm"
ln="list"
10:
m="coumadin" 73:1 73:1
do="4 mg" 73:9 73:10
mo="nm"
f="q.o.d." 73:11 73:11
du="nm"
r="nm"
ln="list"
11:
m="coumadin" 73:1 73:1
do="6 mg" 73:2 73:3
mo="p.o." 73:4 73:4
f="q.o.d." 73:5 73:5
du="nm"
r="nm"
ln="list"
12:
m="omeprazole" 74:1 74:1
do="20 mg" 74:2 74:3
mo="nm"
f="b.i.d." 74:4 74:4
du="nm"
r="nm"
ln="list"
13:
m="metformin" 75:1 75:1
do="500 mg" 75:2 75:3
mo="nm"
f="daily" 75:4 75:4
du="nm"
r="nm"
ln="list"
14:
m="insulin 70/30" 76:1 76:2
do="35 units" 76:7 76:8
mo="nm"
f="q.p.m." 76:9 76:9
du="nm"
r="nm"
ln="list"
15:
m="insulin 70/30" 76:1 76:2
do="65 units" 76:3 76:4
mo="nm"
f="q.a.m." 76:5 76:5
du="nm"
r="nm"
ln="list"
16:
m="calcium" 77:1 77:1
do="600 mg" 77:2 77:3
mo="p.o." 77:4 77:4
f="b.i.d." 77:5 77:5
du="nm"
r="nm"
ln="list"
17:
m="magnesium" 78:1 78:1
do="400 mg" 78:2 78:3
mo="p.o." 78:4 78:4
f="b.i.d." 78:5 78:5
du="nm"
r="nm"
ln="list"
18:
m="multivitamin" 79:1 79:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="iron tablets" 80:1 80:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="actonel" 81:1 81:1
do="nm"
mo="nm"
f="every wednesday." 81:2 81:3
du="nm"
r="nm"
ln="list"
21:
m="lasix" 149:5 149:5
do="nm"
mo="iv" 149:4 149:4
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="lasix" 150:10 150:10
do="80 mg" 150:7 150:8
mo="iv" 150:9 150:9
f="b.i.d." 151:2 151:2
du="nm"
r="her diuresis" 150:2 150:3
ln="narrative"
23:
m="lasix" 154:11 154:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="lasix" 154:4 154:4
do="120 mg" 154:0 154:1
mo="p.o." 154:3 154:3
f="q.o.d." 154:5 154:5
du="nm"
r="nm"
ln="narrative"
25:
m="beta-blocker" 157:8 157:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="digoxin" 158:4 158:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="diltiazem" 161:2 161:2
do="30 mg" 161:3 161:4
mo="nm"
f="q.i.d." 161:5 161:5
du="nm"
r="nm"
ln="narrative"
28:
m="ppi" 190:3 190:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="gerd prophylaxis." 190:5 190:6
ln="narrative"
29:
m="nexium" 191:5 191:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="gerd-like symptoms" 191:8 192:0
ln="narrative"
30:
m="nexium" 192:8 192:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="nexium" 194:3 194:3
do="40 mg" 194:4 194:5
mo="p.o." 194:6 194:6
f="q.d." 194:7 194:7
du="while in-house." 194:8 194:9
r="nm"
ln="narrative"
32:
m="omeprazole" 195:2 195:2
do="20 mg" 195:3 195:4
mo="p.o." 195:5 195:5
f="b.i.d." 195:6 195:6
du="nm"
r="nm"
ln="narrative"
33:
m="colace" 197:2 197:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="senokot" 197:5 197:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="packed red blood cells." 204:9 205:1
do="two units" 204:6 204:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="heparin drip" 207:8 207:9
do="950 units" 207:11 208:0
mo="nm"
f="per hour" 208:1 208:2
du="nm"
r="anticoagulation" 207:1 207:1
ln="narrative"
37:
m="lovenox" 210:4 210:4
do="60 mg" 210:5 210:6
mo="nm"
f="b.i.d." 210:7 210:7
du="nm"
r="nm"
ln="narrative"
38:
m="lovenox" 211:7 211:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="nph" 224:9 224:9
do="60 units" 224:10 224:11
mo="nm"
f="in the morning" 225:0 225:2
du="nm"
r="her blood glucose." 223:10 224:0
ln="narrative"
40:
m="nph" 225:4 225:4
do="30 units" 225:5 225:6
mo="nm"
f="in the evening" 225:7 225:9
du="nm"
r="nm"
ln="narrative"
41:
m="novolog" 226:7 226:7
do="15 units" 226:9 226:10
mo="nm"
f="in the morning with breakfast" 226:11 227:2
du="nm"
r="nm"
ln="narrative"
42:
m="novolog" 228:4 228:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="levaquin" 241:1 241:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="her uti." 241:7 241:8
ln="narrative"
44:
m="antibiotics" 253:6 253:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="antibiotics" 259:5 259:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="ceftriaxone" 260:4 260:4
do="1 g" 260:5 260:6
mo="iv" 260:7 260:7
f="b.i.d." 260:8 260:8
du="two weeks" 260:1 260:2
r="nm"
ln="narrative"
47:
m="antibiotic" 265:4 265:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="codeine" 266:9 266:9
do="nm"
mo="nm"
f="as needed" 266:10 267:0
du="nm"
r="her pain." 267:2 267:3
ln="narrative"
49:
m="darvon" 266:6 266:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="diltiazem" 285:1 285:1
do="30 mg" 285:2 285:3
mo="p.o." 285:4 285:4
f="q.6h." 285:5 285:5
du="nm"
r="nm"
ln="list"
51:
m="colace" 286:1 286:1
do="100 mg" 286:2 286:3
mo="p.o." 286:4 286:4
f="b.i.d." 286:5 286:5
du="nm"
r="nm"
ln="list"
52:
m="lasix" 287:1 287:1
do="120 mg" 287:2 287:3
mo="p.o." 287:4 287:4
f="q. other day." 287:5 287:7
du="nm"
r="nm"
ln="list"
53:
m="nph" 288:1 288:1
do="60 units" 288:2 288:3
mo="nm"
f="in the morning" 288:4 288:6
du="nm"
r="nm"
ln="list"
54:
m="nph" 289:1 289:1
do="30 units" 289:2 289:3
mo="nm"
f="in the evening." 289:4 289:6
du="nm"
r="nm"
ln="list"
55:
m="lisinopril" 290:1 290:1
do="40 mg" 290:2 290:3
mo="p.o." 290:4 290:4
f="q. day" 290:5 290:6
du="nm"
r="nm"
ln="list"
56:
m="senokot" 291:1 291:1
do="three tablets" 291:2 291:3
mo="p.o." 291:4 291:4
f="b.i.d." 291:5 291:5
du="nm"
r="nm"
ln="list"
57:
m="multivitamin" 292:1 292:1
do="one tablet" 292:2 292:3
mo="p.o." 292:4 292:4
f="q.d." 292:5 292:5
du="nm"
r="nm"
ln="list"
58:
m="lovenox" 293:1 293:1
do="60 mg" 293:2 293:3
mo="subcutaneously" 293:4 293:4
f="b.i.d." 293:5 293:5
du="nm"
r="nm"
ln="list"
59:
m="caltrate plus vitamin d" 294:1 294:4
do="600 mg one tablet" 294:5 294:8
mo="p.o." 294:9 294:9
f="b.i.d." 294:10 294:10
du="nm"
r="nm"
ln="list"
60:
m="novolog" 295:1 295:1
do="sliding scale" 295:2 295:3
mo="nm"
f="h.s." 295:6 295:6
du="nm"
r="nm"
ln="list"
61:
m="novolog" 295:1 295:1
do="sliding scale" 295:2 295:3
mo="nm"
f="q.a.c." 295:4 295:4
du="nm"
r="nm"
ln="list"
62:
m="novolog" 296:1 296:1
do="15 units" 296:2 296:3
mo="subcutaneously" 296:4 296:4
f="with breakfast and dinner" 296:5 296:8
du="nm"
r="nm"
ln="list"
63:
m="maalox tablets" 298:1 298:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
64:
m="codeine" 299:1 299:1
do="15 mg to 30 mg" 299:2 299:6
mo="p.o." 299:7 299:7
f="q.4h. p.r.n." 299:8 299:9
du="nm"
r="pain." 299:10 299:10
ln="list"
65:
m="magnesium oxide" 300:1 300:2
do="400 mg" 300:3 300:4
mo="p.o." 300:5 300:5
f="b.i.d." 300:6 300:6
du="nm"
r="nm"
ln="list"
66:
m="omeprazole" 301:1 301:1
do="20 mg" 301:2 301:3
mo="p.o." 301:4 301:4
f="b.i.d." 301:5 301:5
du="nm"
r="nm"
ln="list"
67:
m="niferex" 302:1 302:1
do="150 mg" 302:2 302:3
mo="p.o." 302:4 302:4
f="b.i.d." 302:5 302:5
du="nm"
r="nm"
ln="list"
68:
m="antibiotic" 312:0 312:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
