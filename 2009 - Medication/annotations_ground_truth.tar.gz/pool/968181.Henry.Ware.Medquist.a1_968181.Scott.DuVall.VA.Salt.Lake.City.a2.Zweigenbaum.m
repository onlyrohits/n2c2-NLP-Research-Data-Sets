1:
m="penicillin." 12:5 12:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="strep pharyngitis" 11:3 11:4
ln="narrative"
2:
m="heparin" 20:8 20:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="a pulmonary emboli" 19:7 19:9
ln="narrative"
3:
m="advils" 30:6 30:6
do="two" 30:5 30:5
mo="nm"
f="nm"
du="nm"
r="the discomfort" 29:3 29:4
ln="narrative"
4:
m="heparin" 34:3 34:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="penicillin." 40:0 40:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="strep pharyngitis." 39:2 39:3
ln="narrative"
6:
m="motrin" 44:2 44:2
do="nm"
mo="nm"
f="prn." 44:3 44:3
du="nm"
r="nm"
ln="narrative"
7:
m="coumadin" 94:0 94:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="heparin" 99:1 99:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="naprosyn" 114:4 114:4
do="500 mg" 114:6 114:7
mo="p.o." 114:8 114:8
f="b.i.d." 114:9 114:9
du="nm"
r="nm"
ln="narrative"
10:
m="naprosyn" 124:1 124:1
do="500 mg" 124:2 124:3
mo="p.o." 124:4 124:4
f="b.i.d. with meals." 124:5 124:7
du="nm"
r="nm"
ln="narrative"
