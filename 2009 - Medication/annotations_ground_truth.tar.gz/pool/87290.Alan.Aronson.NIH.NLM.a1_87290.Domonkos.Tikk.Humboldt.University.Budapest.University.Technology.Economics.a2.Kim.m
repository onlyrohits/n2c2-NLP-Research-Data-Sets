1:
m="acetylsalicylic acid" 19:0 19:1
do="325 mg" 19:2 19:3
mo="po" 19:4 19:4
f="daily" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="lipitor ( atorvastatin )" 20:0 20:3
do="80 mg" 20:4 20:5
mo="po" 20:6 20:6
f="daily" 20:7 20:7
du="nm"
r="nm"
ln="list"
3:
m="clindamycin hcl" 21:0 21:1
do="300 mg" 21:2 21:3
mo="po" 21:4 21:4
f="qid" 21:5 21:5
du="x 12 doses" 21:6 21:8
r="nm"
ln="list"
4:
m="antibiotics" 22:3 22:3
do="nm"
mo="iv" 22:2 22:2
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="plavix ( clopidogrel )" 23:0 23:3
do="75 mg" 23:4 23:5
mo="po" 23:6 23:6
f="daily" 23:7 23:7
du="nm"
r="nm"
ln="list"
6:
m="colace ( docusate sodium )" 24:0 24:4
do="100 mg" 24:5 24:6
mo="po" 24:7 24:7
f="bid" 24:8 24:8
du="nm"
r="nm"
ln="list"
7:
m="nexium ( esomeprazole )" 25:0 25:3
do="40 mg" 25:4 25:5
mo="po" 25:6 25:6
f="daily" 25:7 25:7
du="nm"
r="nm"
ln="list"
8:
m="glipizide" 26:0 26:0
do="2.5 mg" 26:1 26:2
mo="po" 26:3 26:3
f="daily" 26:4 26:4
du="nm"
r="nm"
ln="list"
9:
m="lisinopril" 27:0 27:0
do="5 mg" 27:1 27:2
mo="po" 27:3 27:3
f="bid" 27:4 27:4
du="nm"
r="nm"
ln="list"
10:
m="potassium chloride" 29:3 29:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="lisinopril" 30:0 30:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="potassium chloride" 31:3 31:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="lisinopril" 32:0 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="potassium chloride" 35:3 35:4
do="nm"
mo="iv" 35:5 35:5
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="lisinopril" 36:3 36:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="potassium chloride" 36:5 37:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="lisinopril" 38:3 38:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="potassium chloride" 38:5 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="reglan ( metoclopramide hcl )" 40:0 40:4
do="10 mg" 40:5 40:6
mo="po" 40:7 40:7
f="tid" 40:8 40:8
du="nm"
r="nm"
ln="list"
20:
m="toprol xl ( metoprolol succinate extended release )" 41:0 41:7
do="50 mg" 42:0 42:1
mo="po" 42:2 42:2
f="daily" 42:3 42:3
du="nm"
r="nm"
ln="list"
21:
m="senna tablets ( sennosides )" 44:0 44:4
do="2 tab" 44:5 44:6
mo="po" 44:7 44:7
f="bid" 44:8 44:8
du="nm"
r="nm"
ln="list"
22:
m="amiodarone" 70:13 70:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="lopressor." 70:0 70:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="asa" 76:2 76:2
do="325qd" 76:3 76:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="colace" 76:11 76:11
do="100bid" 76:12 76:12
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="lipitor" 76:5 76:5
do="80qd" 76:6 76:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="nexium" 76:14 76:14
do="40qd" 77:0 77:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="plavix" 76:8 76:8
do="75qd" 76:9 76:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="glipizide" 77:2 77:2
do="2.5qd" 77:3 77:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="lisinopril" 77:5 77:5
do="5" 77:6 77:6
mo="nm"
f="bid" 77:7 77:7
du="nm"
r="nm"
ln="list"
31:
m="mom" 77:12 77:12
do="nm"
mo="nm"
f="qhs" 77:13 77:13
du="nm"
r="nm"
ln="list"
32:
m="reglan" 77:9 77:9
do="10tid" 77:10 77:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="bb" 92:11 92:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="toprol xl" 93:5 93:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="clindamycin" 94:0 94:0
do="nm"
mo="nm"
f="qid" 94:1 94:1
du="3 day course" 94:4 94:6
r="nm"
ln="narrative"
36:
m="aspirin" 97:3 97:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="coumadin" 97:6 97:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="anticoagulation" 98:0 98:0
ln="narrative"
38:
m="plavix" 97:8 97:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="anticoagulation" 98:0 98:0
ln="narrative"
39:
m="asa" 99:13 99:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="plavix" 100:0 100:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="coumadin." 101:2 101:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="nexium" 102:12 102:12
do="nm"
mo="iv" 102:11 102:11
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="nph" 105:10 105:10
do="nm"
mo="nm"
f="nm"
du="while in-house" 105:3 105:4
r="nm"
ln="narrative"
44:
m="riss" 105:12 105:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="home meds" 106:0 106:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="dulcolax" 109:0 109:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="constipation" 108:7 108:7
ln="narrative"
47:
m="stool softeners" 109:11 110:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="stool softeners" 109:2 109:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="constipation" 108:7 108:7
ln="narrative"
49:
m="antibiotic clindamycin" 115:6 115:7
do="nm"
mo="nm"
f="nm"
du="until you run out of pills." 115:8 116:1
r="nm"
ln="narrative"
50:
m="antibiotics" 115:6 115:6
do="nm"
mo="nm"
f="nm"
du="until you run out of pills." 115:8 116:1
r="nm"
ln="narrative"
51:
m="clindamycin" 115:7 115:7
do="nm"
mo="nm"
f="nm"
du="until you run out of pills." 115:8 116:1
r="nm"
ln="narrative"
52:
m="home meds." 120:8 120:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="stool softeners" 120:2 120:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="constipation." 120:5 120:5
ln="narrative"
