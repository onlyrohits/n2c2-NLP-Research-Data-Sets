1:
m="atenolol" 16:0 16:0
do="100 mg" 16:1 16:2
mo="po" 16:3 16:3
f="qd" 16:4 16:4
du="nm"
r="nm"
ln="list"
2:
m="lasix ( furosemide )" 17:0 17:3
do="40 mg" 17:4 17:5
mo="po" 17:6 17:6
f="qd" 17:7 17:7
du="nm"
r="nm"
ln="list"
3:
m="reglan ( metoclopramide hcl )" 18:0 18:4
do="10 mg" 18:5 18:6
mo="po" 18:7 18:7
f="tid" 18:8 18:8
du="nm"
r="nm"
ln="list"
4:
m="coumadin ( warfarin sodium )" 21:0 21:4
do="3.75 mg" 21:5 21:6
mo="po" 21:7 21:7
f="qpm" 21:8 21:8
du="nm"
r="nm"
ln="list"
5:
m="simvastatin" 27:3 27:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="warfarin" 27:5 27:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="simvastatin" 29:0 29:0
do="20 mg" 29:1 29:2
mo="po" 29:3 29:3
f="qhs" 29:4 29:4
du="nm"
r="nm"
ln="narrative"
8:
m="coumadin" 34:3 34:3
do="nm"
mo="po " 34:4 34:4
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="simvastatin" 35:3 35:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="warfarin" 35:5 35:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="simvastatin" 38:5 38:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="warfarin" 38:3 38:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="insulin 70/30 ( human )" 40:0 40:4
do="0 units" 40:8 40:9
mo="sc" 40:11 40:11
f="qpm" 40:10 40:10
du="nm"
r="nm"
ln="list"
14:
m="insulin 70/30 ( human )" 40:0 40:4
do="0 units" 41:3 41:4
mo="nm"
f="qpm" 41:5 41:5
du="nm"
r="nm"
ln="list"
15:
m="insulin 70/30 ( human )" 40:0 40:4
do="10 units" 40:5 40:6
mo="nm"
f="qam;" 40:7 40:7
du="nm"
r="nm"
ln="list"
16:
m="insulin 70/30 ( human )" 40:0 40:4
do="10 units" 41:0 41:1
mo="nm"
f="qam" 41:2 41:2
du="nm"
r="nm"
ln="list"
17:
m="cozaar ( losartan )" 42:0 42:3
do="100 mg" 42:4 42:5
mo="po" 42:6 42:6
f="qd" 42:7 42:7
du="number of doses required ( approximate ): 10" 43:0 43:7
r="nm"
ln="list"
18:
m="protonix ( pantoprazole )" 44:0 44:3
do="40 mg" 44:4 44:5
mo="po" 44:6 44:6
f="qd" 44:7 44:7
du="nm"
r="nm"
ln="list"
19:
m="asa" 92:3 92:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="beta blocker" 92:0 92:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="cozaar" 95:9 95:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="atenolol." 96:8 96:8
do="nm"
mo="nm"
f="once a day" 96:5 96:7
du="nm"
r="nm"
ln="narrative"
23:
m="beta blocker" 96:0 96:1
do="nm"
mo="nm"
f="once a day" 96:5 96:7
du="nm"
r="nm"
ln="narrative"
24:
m="insulin" 102:4 102:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="insulin 70/30" 103:1 103:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="lantus" 103:10 103:10
do="40" 103:11 103:11
mo="nm"
f="q d" 103:12 104:0
du="nm"
r="nm"
ln="narrative"
27:
m="insulin" 106:2 106:2
do="down titration" 105:10 106:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="insulin" 108:0 108:0
do="8 units" 107:3 107:4
mo="nm"
f="pm" 107:12 107:12
du="nm"
r="nm"
ln="narrative"
29:
m="insulin" 111:3 111:3
do="titrating" 111:0 111:0
mo="nm"
f="as needed" 111:5 111:6
du="nm"
r="nm"
ln="narrative"
30:
m="reglan" 113:8 113:8
do="10" 114:4 114:4
mo="nm"
f="nm"
du="nm"
r="diabetic gastroparesis" 113:5 113:6
ln="narrative"
31:
m="coumadin" 116:2 116:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="coumadin" 117:1 117:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="nexium" 117:3 117:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="insulin" 120:10 120:10
do="10 units" 120:6 120:7
mo="nm"
f="morning." 120:12 120:12
du="nm"
r="nm"
ln="narrative"
35:
m="insulin" 120:4 120:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="insulin" 121:8 121:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood sugars" 122:4 122:5
ln="narrative"
37:
m="lisinopril." 123:6 123:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="metoprolol" 123:4 123:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="atenolol" 124:6 124:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="cozaar" 124:4 124:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="reglan" 124:8 124:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
