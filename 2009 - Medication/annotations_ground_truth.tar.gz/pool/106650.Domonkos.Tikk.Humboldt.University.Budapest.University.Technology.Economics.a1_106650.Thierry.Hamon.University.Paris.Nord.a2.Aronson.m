1:
m="contrast dye" 12:0 12:1
do="nm"
mo="intravenous" 11:9 11:9
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="nitroglycerin" 23:0 23:0
do="nm"
mo="sublingual" 22:10 22:10
f="nm"
du="in the past week x two." 23:6 23:11
r="the pain" 21:9 21:10
ln="narrative"
3:
m="aspirin" 49:4 49:4
do="nm"
mo="nm"
f="q.d." 49:5 49:5
du="nm"
r="nm"
ln="list"
4:
m="enalapril" 50:1 50:1
do="20 mg" 50:2 50:3
mo="nm"
f="b.i.d." 50:4 50:4
du="nm"
r="nm"
ln="list"
5:
m="cardizem" 51:1 51:1
do="300 mg" 51:2 51:3
mo="nm"
f="q.d." 51:4 51:4
du="nm"
r="nm"
ln="list"
6:
m="insulin mixed 70/30" 52:1 52:3
do="30" 52:11 52:11
mo="nm"
f="in the evening." 52:12 53:0
du="nm"
r="nm"
ln="list"
7:
m="insulin mixed 70/30" 52:1 52:3
do="60 units" 52:5 52:6
mo="nm"
f="in the morning" 52:7 52:9
du="nm"
r="nm"
ln="list"
8:
m="atenolol" 54:1 54:1
do="50 mg" 54:2 54:3
mo="nm"
f="q.d." 54:4 54:4
du="nm"
r="nm"
ln="list"
9:
m="aspirin" 103:3 103:3
do="325 mg" 103:4 103:5
mo="nm"
f="q.d." 103:6 103:6
du="nm"
r="nm"
ln="list"
10:
m="enalapril" 104:1 104:1
do="20 mg" 104:2 104:3
mo="nm"
f="b.i.d." 104:4 104:4
du="nm"
r="nm"
ln="list"
11:
m="cardizem" 105:1 105:1
do="300 mg" 105:2 105:3
mo="nm"
f="q.d." 105:4 105:4
du="nm"
r="nm"
ln="list"
12:
m="atenolol" 106:1 106:1
do="50 mg" 106:2 106:3
mo="nm"
f="b.i.d." 106:4 106:4
du="nm"
r="nm"
ln="list"
13:
m="simvastatin" 107:7 107:7
do="10 mg" 107:8 107:9
mo="nm"
f="q.h.s." 107:10 107:10
du="nm"
r="nm"
ln="list"
