1:
m="acetylsalicylic acid" 19:0 19:1
do="81 mg" 19:2 19:3
mo="po" 19:4 19:4
f="qd" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 22:3 22:3
do="nm"
mo="po" 22:4 22:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 23:3 23:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 23:5 23:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="aspirin" 26:5 26:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="warfarin" 26:3 26:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="phoslo ( calcium acetate )" 29:0 29:4
do="667 mg" 29:5 29:6
mo="po" 29:7 29:7
f="tid" 29:8 29:8
du="nm"
r="nm"
ln="list"
8:
m="folate ( folic acid )" 30:0 30:4
do="1 mg" 30:5 30:6
mo="po" 30:7 30:7
f="qd" 30:8 30:8
du="nm"
r="nm"
ln="list"
9:
m="diovan ( valsartan )" 31:0 31:3
do="160 mg" 31:4 31:5
mo="po" 31:6 31:6
f="qd" 31:7 31:7
du="number of doses required (approximate): 4" 32:0 32:7
r="nm"
ln="list"
10:
m="carvedilol" 33:0 33:0
do="6.25 mg" 33:1 33:2
mo="po" 33:3 33:3
f="bid" 33:4 33:4
du="nm"
r="nm"
ln="list"
11:
m="nephrocaps ( nephro-vit rx )" 37:0 37:4
do="1 tab" 37:5 37:6
mo="po" 37:7 37:7
f="qd" 37:8 37:8
du="nm"
r="nm"
ln="list"
12:
m="niacin" 40:5 40:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="simvastatin" 40:3 40:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="vit. b-3" 41:0 41:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="lipitor ( atorvastatin )" 42:0 42:3
do="20 mg" 42:4 42:5
mo="po" 42:6 42:6
f="qd" 42:7 42:7
du="nm"
r="nm"
ln="list"
16:
m="niacin" 44:3 44:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="vit. b-3" 44:5 44:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="atorvastatin calcium" 45:0 45:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="lasix ( furosemide )" 46:0 46:3
do="80 mg" 46:4 46:5
mo="po" 46:6 46:6
f="bid" 46:7 46:7
du="nm"
r="nm"
ln="list"
20:
m="coumadin" 68:9 68:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="levoflox" 75:1 75:1
do="nm"
mo="nm"
f="nm"
du="14d" 75:0 75:0
r="multifocal pna" 74:11 74:12
ln="narrative"
22:
m="heparin" 77:12 77:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="lenis l peroneal dvt." 77:7 77:10
ln="narrative"
23:
m="coumadin" 78:4 78:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="dvt." 78:8 78:8
ln="narrative"
24:
m="asa" 92:5 92:5
do="325" 92:6 92:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="duonebs" 92:3 92:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="lasix" 92:8 92:8
do="80mg" 92:9 92:9
mo="po" 93:0 93:0
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="lasix" 107:5 107:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="lasix" 109:10 109:10
do="80" 109:11 109:11
mo="nm"
f="bid" 109:12 109:12
du="nm"
r="nm"
ln="narrative"
29:
m="lasix" 110:4 110:4
do="nm"
mo="nm"
f="nm"
du="2d" 110:6 110:6
r="nm"
ln="narrative"
30:
m="coreg" 112:13 112:13
do="nm"
mo="nm"
f="bid" 112:12 112:12
du="nm"
r="bp" 112:16 112:16
ln="narrative"
31:
m="coreg" 112:2 112:2
do="nm"
mo="nm"
f="bid" 112:8 112:8
du="nm"
r="htn" 110:10 110:10
ln="narrative"
32:
m="coreg" 112:2 112:2
do="nm"
mo="nm"
f="qod" 112:5 112:5
du="nm"
r="htn" 110:10 110:10
ln="narrative"
33:
m="asa" 116:6 116:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="lipitor." 116:10 116:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="nephrocaps" 118:9 118:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="phoslo" 118:7 118:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="coumadin" 119:6 119:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="recent dvt" 119:9 119:10
ln="narrative"
38:
m="coreg" 122:8 122:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="coumadin" 125:3 125:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="lasix" 127:8 127:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
