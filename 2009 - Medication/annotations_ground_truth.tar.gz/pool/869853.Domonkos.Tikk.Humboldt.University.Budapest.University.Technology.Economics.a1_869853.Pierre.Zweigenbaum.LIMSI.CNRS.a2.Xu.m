1:
m="nitroglycerin" 20:6 20:6
do="nm"
mo="sublingual" 20:5 20:5
f="nm"
du="nm"
r="substernal chest pain" 20:0 20:2
ln="narrative"
2:
m="nitroglycerin" 22:6 22:6
do="two" 22:4 22:4
mo="sublingual" 22:5 22:5
f="nm"
du="nm"
r="pain" 23:3 23:3
ln="narrative"
3:
m="simvastatin" 29:4 29:4
do="10 mg" 29:5 29:6
mo="nm"
f="q.h.s." 29:7 29:7
du="nm"
r="nm"
ln="list"
4:
m="enalapril" 30:3 30:3
do="5 mg" 31:0 31:1
mo="nm"
f="b.i.d." 31:2 31:2
du="nm"
r="nm"
ln="list"
5:
m="nitroglycerin" 30:1 30:1
do="nm"
mo="sublingual" 30:0 30:0
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="aspirin" 31:4 31:4
do="325 mg" 31:5 31:6
mo="nm"
f="q.d." 31:7 31:7
du="nm"
r="nm"
ln="list"
7:
m="atenolol" 31:9 31:9
do="50 mg" 31:10 31:11
mo="nm"
f="b.i.d." 31:12 31:12
du="nm"
r="nm"
ln="list"
8:
m="medications" 56:3 56:3
do="nm"
mo="intravenous" 56:2 56:2
f="nm"
du="until hospital day three" 57:1 57:4
r="heart rate...blood pressure" 55:4 55:5,55:7 55:8
ln="narrative"
9:
m="reopro" 65:9 65:9
do="nm"
mo="infusion." 66:0 66:0
f="nm"
du="nm"
r="artery lesion" 65:5 65:6
ln="narrative"
10:
m="aspirin" 70:4 70:4
do="325 mg" 70:5 70:6
mo="p.o." 70:7 70:7
f="q.d." 70:8 70:8
du="nm"
r="nm"
ln="list"
11:
m="simvastatin" 71:0 71:0
do="10 mg" 71:1 71:2
mo="p.o." 71:3 71:3
f="q.h.s." 71:4 71:4
du="nm"
r="nm"
ln="list"
12:
m="ticlid" 71:6 71:6
do="250 mg" 71:7 72:0
mo="p.o." 72:1 72:1
f="b.i.d." 72:2 72:2
du="for 11 days" 72:3 72:5
r="nm"
ln="list"
13:
m="atenolol" 72:7 72:7
do="25 mg" 72:8 72:9
mo="p.o." 72:10 72:10
f="b.i.d." 72:11 72:11
du="nm"
r="nm"
ln="list"
14:
m="enalapril" 72:13 72:13
do="20 mg" 73:0 73:1
mo="p.o." 73:2 73:2
f="q.d." 73:3 73:3
du="nm"
r="nm"
ln="list"
