1:
m="pressors" 37:11 37:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="lopressor" 40:5 40:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="lopressor" 41:8 41:8
do="titrated up" 41:5 41:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="norvasc" 42:1 42:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="beta-blockers." 44:6 44:6
do="titrated up" 44:2 44:3
mo="nm"
f="nm"
du="nm"
r="slightly tachycardic" 43:6 43:7
ln="narrative"
6:
m="levofloxacin" 47:1 47:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="questionable pneumonia." 47:3 47:4
ln="narrative"
7:
m="levofloxacin." 52:8 52:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="a positive blood culture" 51:1 51:4
ln="narrative"
8:
m="vancomycin." 55:2 55:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="left leg cellulitis" 53:5 53:7
ln="narrative"
9:
m="antibiotics." 56:5 56:5
do="nm"
mo="iv" 56:4 56:4
f="nm"
du="nm"
r="nm"
ln="narrative"
