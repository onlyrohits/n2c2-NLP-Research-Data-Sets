1:
m="aspirin" 39:5 39:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
2:
m="atenolol." 39:9 39:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="lisinopril" 39:7 39:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="aspirin" 86:5 86:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="ischemia" 85:2 85:2
ln="narrative"
5:
m="aspirin" 86:5 86:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="myocardial infarction." 85:7 85:8
ln="narrative"
6:
m="aspirin" 86:5 86:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="st elevation" 85:4 85:5
ln="narrative"
7:
m="heparin" 86:7 86:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="ischemia" 85:2 85:2
ln="narrative"
8:
m="heparin" 86:7 86:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="myocardial infarction." 85:7 85:8
ln="narrative"
9:
m="heparin" 86:7 86:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="st elevation" 85:4 85:5
ln="narrative"
10:
m="lopressor" 86:9 86:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="ischemia" 85:2 85:2
ln="narrative"
11:
m="lopressor" 86:9 86:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="myocardial infarction." 85:7 85:8
ln="narrative"
12:
m="lopressor" 86:9 86:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="st elevation" 85:4 85:5
ln="narrative"
13:
m="captopril" 87:0 87:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="ischemia" 85:2 85:2
ln="narrative"
14:
m="captopril" 87:0 87:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="myocardial infarction." 85:7 85:8
ln="narrative"
15:
m="captopril" 87:0 87:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="st elevation" 85:4 85:5
ln="narrative"
16:
m="cozaar" 87:2 87:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="ischemia" 85:2 85:2
ln="narrative"
17:
m="cozaar" 87:2 87:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="myocardial infarction." 85:7 85:8
ln="narrative"
18:
m="cozaar" 87:2 87:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="st elevation" 85:4 85:5
ln="narrative"
19:
m="heparin" 89:7 89:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="atrovent" 92:9 92:9
do="nm"
mo="nebs" 92:10 92:10
f="nm"
du="nm"
r="some wheezing" 91:6 91:7
ln="narrative"
21:
m="fluids" 99:10 99:10
do="nm"
mo="iv" 99:9 99:9
f="nm"
du="nm"
r="most likely dehydrated" 98:5 98:7
ln="narrative"
22:
m="fluids" 99:1 99:1
do="nm"
mo="nm"
f="nm"
du="until she had good urine output." 99:2 99:7
r="most likely dehydrated" 98:5 98:7
ln="narrative"
