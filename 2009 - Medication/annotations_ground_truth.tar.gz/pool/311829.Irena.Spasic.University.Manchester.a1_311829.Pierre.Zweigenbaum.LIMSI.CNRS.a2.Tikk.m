1:
m="nsaid" 23:9 23:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="degenerative joint disease." 24:2 24:4
ln="narrative"
2:
m="nsaids" 25:0 25:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="lasix" 57:9 57:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="ace inhibitor" 71:3 71:4
do="nm"
mo="nm"
f="nm"
du="throughout hospital course" 71:7 72:0
r="nm"
ln="narrative"
5:
m="diuretics" 71:1 71:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="these medications" 73:4 73:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="nexium" 84:8 84:8
do="40 mg" 84:9 85:0
mo="nm"
f="daily" 85:1 85:1
du="nm"
r="nm"
ln="narrative"
8:
m="statin" 91:7 91:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="iron" 93:9 93:9
do="nm"
mo="iv" 93:8 93:8
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="coumadin" 95:10 95:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="dvt prophylaxis/paroxysmal a-fib" 96:1 96:3
ln="narrative"
11:
m="epogen" 95:8 95:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="coumadin" 97:5 97:5
do="nm"
mo="nm"
f="nm"
du="until inr 1.5" 98:2 98:4
r="nm"
ln="narrative"
13:
m="heparin" 99:1 99:1
do="nm"
mo="subcutaneous" 99:0 99:0
f="nm"
du="nm"
r="dvt prophylaxis" 99:3 99:4
ln="narrative"
14:
m="heparin" 100:5 100:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="heparin" 101:0 101:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="heparin" 102:11 102:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="coumadin" 104:0 104:0
do="12.5 mg" 104:4 104:5
mo="nm"
f="a day" 104:6 104:7
du="nm"
r="nm"
ln="narrative"
18:
m="levofloxacin" 111:4 111:4
do="renally dosed" 111:5 111:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="cipro" 112:4 112:4
do="nm"
mo="p.o." 112:3 112:3
f="nm"
du="nm"
r="uti" 112:10 112:10
ln="narrative"
20:
m="levo/cefpodox/azithro" 118:0 118:0
do="nm"
mo="p.o." 117:6 117:6
f="nm"
du="x10 days" 118:1 118:2
r="nosocomial pneumonia" 117:3 117:4
ln="narrative"
21:
m="claritin" 121:6 121:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="flonase" 122:1 122:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="zoloft" 123:2 123:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="depression" 123:5 123:5
ln="narrative"
24:
m="albuterol nebs" 128:7 128:8
do="nm"
mo="nm"
f="p.r.n." 129:0 129:0
du="nm"
r="wheezing" 129:2 129:2
ln="narrative"
25:
m="flovent" 128:3 128:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="asthma" 128:5 128:5
ln="narrative"
26:
m="tamoxifen" 136:0 136:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="bowel regimen" 137:3 137:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="albuterol nebulizer" 143:8 143:9
do="2.5 mg" 143:10 144:0
mo="inhaled" 144:1 144:1
f="q.6h. p.r.n." 144:2 144:3
du="nm"
r="shortness of breath" 144:5 144:7
ln="list"
29:
m="albuterol nebulizer" 143:8 143:9
do="2.5 mg" 143:10 144:0
mo="inhaled" 144:1 144:1
f="q.6h. p.r.n." 144:2 144:3
du="nm"
r="wheezing" 144:9 144:9
ln="list"
30:
m="tylenol" 143:1 143:1
do="650 mg" 143:2 143:3
mo="p.o." 143:4 143:4
f="q.4h. p.r.n." 143:5 143:6
du="nm"
r="nm"
ln="list"
31:
m="catapres" 145:12 145:12
do="0.1 mg" 145:13 146:0
mo="nm"
f="per day q. weekly" 146:1 146:4
du="nm"
r="nm"
ln="list"
32:
m="ecasa" 145:0 145:0
do="81 mg" 145:1 145:2
mo="p.o." 145:3 145:3
f="daily" 145:4 145:4
du="nm"
r="nm"
ln="list"
33:
m="phoslo" 145:6 145:6
do="667 mg" 145:7 145:8
mo="p.o." 145:9 145:9
f="t.i.d." 145:10 145:10
du="nm"
r="nm"
ln="list"
34:
m="colace" 146:6 146:6
do="100 mg" 146:7 146:8
mo="p.o." 146:9 146:9
f="b.i.d." 146:10 146:10
du="nm"
r="nm"
ln="list"
35:
m="metoprolol tartarate" 146:12 147:0
do="25 mg" 147:1 147:2
mo="p.o." 147:3 147:3
f="b.i.d." 147:4 147:4
du="nm"
r="nm"
ln="list"
36:
m="senna tablets" 147:6 147:7
do="two tabs" 147:8 147:9
mo="p.o." 147:10 147:10
f="b.i.d. p.r.n." 147:11 148:0
du="nm"
r="constipation" 148:2 148:2
ln="list"
37:
m="ocean spray" 148:4 148:5
do="two sprays" 148:6 148:7
mo="inhaled" 148:8 148:8
f="q.i.d. p.r.n." 148:9 149:0
du="nm"
r="dry nose" 149:2 149:3
ln="list"
38:
m="coumadin" 149:5 149:5
do="12.5 mg" 149:6 149:7
mo="p.o." 149:8 149:8
f="q.p.m." 149:9 149:9
du="nm"
r="nm"
ln="list"
39:
m="zoloft" 149:11 149:11
do="50 mg" 149:12 149:13
mo="p.o." 150:0 150:0
f="q.a.m." 150:1 150:1
du="nm"
r="nm"
ln="list"
40:
m="azithromycin" 150:3 150:3
do="250 mg" 150:4 150:5
mo="p.o." 150:6 150:6
f="daily" 150:7 150:7
du="x10 days" 150:8 150:9
r="nm"
ln="list"
41:
m="simvastatin" 150:11 150:11
do="20 mg" 151:0 151:1
mo="p.o." 151:2 151:2
f="at bedtime" 151:3 151:4
du="nm"
r="nm"
ln="list"
42:
m="doxazosin" 151:6 151:6
do="2 mg" 151:7 151:8
mo="p.o." 151:9 151:9
f="b.i.d." 151:10 151:10
du="nm"
r="nm"
ln="list"
43:
m="norvasc" 151:12 151:12
do="5 mg" 151:13 151:14
mo="p.o." 152:0 152:0
f="daily" 152:1 152:1
du="nm"
r="nm"
ln="list"
44:
m="claritin" 152:3 152:3
do="10 mg" 152:4 152:5
mo="p.o." 152:6 152:6
f="daily" 152:7 152:7
du="nm"
r="nm"
ln="list"
45:
m="flovent" 152:9 152:9
do="110 mcg" 152:10 152:11
mo="inhaled" 152:12 152:12
f="b.i.d." 153:0 153:0
du="nm"
r="nm"
ln="list"
46:
m="cefpodoxime proxetil" 153:2 153:3
do="200 mg" 153:4 153:5
mo="p.o." 153:6 153:6
f="b.i.d." 153:7 153:7
du="x10 days" 153:8 153:9
r="nm"
ln="list"
47:
m="flonase" 153:11 153:11
do="one spray" 154:0 154:1
mo="nm"
f="daily" 154:2 154:2
du="nm"
r="nm"
ln="list"
48:
m="levofloxacin" 154:4 154:4
do="250 mg" 154:5 154:6
mo="p.o." 154:7 154:7
f="q.24" 154:8 154:8
du="x10 doses" 154:9 154:10
r="nm"
ln="list"
49:
m="nexium" 155:0 155:0
do="40 mg" 155:1 155:2
mo="p.o." 155:3 155:3
f="b.i.d." 155:4 155:4
du="nm"
r="nm"
ln="list"
