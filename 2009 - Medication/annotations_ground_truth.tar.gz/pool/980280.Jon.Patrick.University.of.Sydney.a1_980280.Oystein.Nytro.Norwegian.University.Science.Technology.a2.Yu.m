1:
m="glyburide" 37:10 37:10
do="5 mg" 37:11 37:12
mo="nm"
f="q day." 38:0 38:1
du="nm"
r="nm"
ln="list"
2:
m="lasix" 37:4 37:4
do="60 mg" 37:5 37:6
mo="nm"
f="q day." 37:7 37:8
du="nm"
r="nm"
ln="list"
3:
m="labetalol" 38:3 38:3
do="200 mg" 38:4 38:5
mo="nm"
f="b.i.d." 38:6 38:6
du="nm"
r="nm"
ln="list"
4:
m="timoptic" 39:1 39:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="glaucoma" 39:6 39:6
ln="list"
5:
m="xylatan drops" 39:3 39:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="glaucoma." 39:6 39:6
ln="list"
6:
m="triple antibiotics" 81:9 82:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="ampicillin" 82:2 82:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="clindamycin." 82:7 82:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="gentamicin" 82:4 82:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="ampicillin" 113:7 113:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="empiric antimicrobial coverage" 114:5 114:7
ln="narrative"
11:
m="clindamycin" 114:3 114:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="empiric antimicrobial coverage." 114:5 114:7
ln="narrative"
12:
m="gentamicin" 114:0 114:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="empiric antimicrobial coverage" 114:5 114:7
ln="narrative"
13:
m="gentamicin" 118:8 118:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="levofloxacin." 119:1 119:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="antibiotics" 120:12 120:12
do="nm"
mo="nm"
f="nm"
du="six days" 120:9 120:10
r="the patient's fever" 119:2 119:4
ln="narrative"
16:
m="antibiotics" 123:8 123:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="ampicillin" 127:1 127:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="clindamycin" 127:4 127:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="levofloxacin." 127:3 127:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="flagyl." 128:0 128:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="lasix" 137:0 137:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="demerol" 140:2 140:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="abdominal pain" 139:6 139:7
ln="narrative"
23:
m="vistaril." 140:4 140:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="abdominal pain" 139:6 139:7
ln="narrative"
24:
m="glyburide" 143:8 143:8
do="5 mg" 143:9 143:10
mo="p.o." 144:0 144:0
f="q day." 144:1 144:2
du="nm"
r="nm"
ln="list"
25:
m="lasix" 143:3 143:3
do="60 mg" 143:4 143:5
mo="p.o." 143:6 143:6
f="q.i.d." 143:7 143:7
du="nm"
r="nm"
ln="list"
26:
m="labetalol" 144:3 144:3
do="200 mg" 144:4 144:5
mo="p.o." 144:6 144:6
f="b.i.d." 145:0 145:0
du="nm"
r="nm"
ln="list"
27:
m="flagyl" 145:1 145:1
do="500 mg" 145:2 145:3
mo="p.o." 145:4 145:4
f="q 8 hours." 145:5 145:7
du="nm"
r="nm"
ln="list"
28:
m="levofloxacin" 145:8 145:8
do="500 mg" 145:9 145:10
mo="p.o." 145:11 145:11
f="q 24 hours." 145:12 146:1
du="nm"
r="nm"
ln="list"
29:
m="timoptic 0.5%" 146:8 146:9
do="1 drop" 146:10 146:11
mo="os" 146:12 146:12
f="q day." 146:13 146:14
du="nm"
r="nm"
ln="list"
30:
m="xalatan" 146:2 146:2
do="1 drop" 146:3 146:4
mo="ou" 146:5 146:5
f="q p.m." 146:6 146:7
du="nm"
r="nm"
ln="list"
