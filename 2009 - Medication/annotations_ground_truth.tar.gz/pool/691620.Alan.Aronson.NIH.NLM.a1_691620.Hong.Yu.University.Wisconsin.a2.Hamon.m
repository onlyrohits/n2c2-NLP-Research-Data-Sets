1:
m="amitriptyline hcl" 17:0 17:1
do="50 mg" 17:2 17:3
mo="po" 17:4 17:4
f="bedtime" 17:5 17:5
du="nm"
r="nm"
ln="list"
2:
m="enteric coated aspirin ( aspirin enteric coated )" 18:0 18:7
do="81 mg" 19:0 19:1
mo="po" 19:2 19:2
f="daily" 19:3 19:3
du="nm"
r="nm"
ln="list"
3:
m="atenolol" 20:0 20:0
do="25 mg" 20:11 20:12
mo="nm"
f="qpm" 20:13 20:13
du="nm"
r="nm"
ln="list"
4:
m="atenolol" 20:0 20:0
do="25 mg" 20:4 20:5
mo="po" 20:7 20:7
f="qpm" 20:6 20:6
du="nm"
r="nm"
ln="list"
5:
m="atenolol" 20:0 20:0
do="50 mg" 20:1 20:2
mo="nm"
f="qam" 20:3 20:3
du="nm"
r="nm"
ln="list"
6:
m="atenolol" 20:0 20:0
do="50 mg" 20:8 20:9
mo="nm"
f="qam" 20:10 20:10
du="nm"
r="nm"
ln="list"
7:
m="caltrate 600 + d ( calcium carbonate 1 , 500 mg ( ... )" 21:0 21:13
do="2 tab" 22:0 22:1
mo="po" 22:2 22:2
f="daily" 22:3 22:3
du="nm"
r="nm"
ln="list"
8:
m="fluoxetine hcl" 23:0 23:1
do="20 mg" 23:2 23:3
mo="po" 23:4 23:4
f="daily" 23:5 23:5
du="nm"
r="nm"
ln="list"
9:
m="lisinopril" 24:0 24:0
do="20 mg" 24:1 24:2
mo="po" 24:3 24:3
f="daily" 24:4 24:4
du="nm"
r="nm"
ln="list"
10:
m="kcl immediate release" 27:3 27:5
do="nm"
mo="po" 27:6 27:6
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="lisinopril" 29:3 29:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="potassium chloride" 29:5 30:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="lisinopril" 31:3 31:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="potassium chloride" 31:5 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="metformin" 33:0 33:0
do="1 , 000 mg" 33:1 33:4
mo="po" 33:5 33:5
f="bid" 33:6 33:6
du="nm"
r="nm"
ln="list"
16:
m="avadia" 34:0 34:0
do="8 unit" 34:1 34:2
mo="nm"
f="daily" 34:3 34:3
du="nm"
r="nm"
ln="list"
17:
m="glyburide" 35:0 35:0
do="10 mg" 35:1 35:2
mo="po" 35:3 35:3
f="bid" 35:4 35:4
du="nm"
r="nm"
ln="list"
18:
m="ntg" 61:4 61:4
do="nm"
mo="sl" 61:3 61:3
f="nm"
du="nm"
r="intermittent left arm pain" 58:10 59:0
ln="narrative"
19:
m="asa" 65:3 65:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="heparin" 65:5 65:5
do="nm"
mo="gtt" 65:6 65:6
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="atenolol" 74:2 74:2
do="50am/25pm" 74:3 74:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="avadia" 74:5 74:5
do="8" 74:6 74:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="fluoxetine" 74:8 74:8
do="20" 74:9 74:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="metformin" 74:11 74:11
do="1gm" 74:12 74:12
mo="nm"
f="bid" 75:0 75:0
du="nm"
r="nm"
ln="list"
25:
m="amitriptyline" 75:11 75:11
do="50qhs" 76:0 76:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="caco3" 75:8 75:8
do="1200qd" 75:9 75:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="glyburide" 75:2 75:2
do="10bid" 75:3 75:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="lisinopril" 75:5 75:5
do="20" 75:6 75:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="asa" 91:11 91:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="bb" 91:13 91:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="acei" 93:18 93:18
do="nm"
mo="nm"
f="nm"
du="nm"
r="htn" 93:13 93:13
ln="narrative"
32:
m="bb" 93:16 93:16
do="nm"
mo="nm"
f="nm"
du="nm"
r="htn" 93:13 93:13
ln="narrative"
33:
m="home meds" 95:5 95:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="riss" 95:1 95:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="your medications" 97:3 97:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
