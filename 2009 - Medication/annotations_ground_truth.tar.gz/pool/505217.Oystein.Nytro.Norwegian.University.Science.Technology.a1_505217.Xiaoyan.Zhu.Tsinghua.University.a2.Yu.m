1:
m="cipro" 18:4 18:4
do="nm"
mo="nm"
f="nm"
du="a course" 18:1 18:2
r="nm"
ln="narrative"
2:
m="oxacillin" 35:3 35:3
do="nm"
mo="nm"
f="nm"
du="a dose" 35:0 35:1
r="nm"
ln="narrative"
3:
m="antibiotics" 36:2 36:2
do="nm"
mo="iv" 36:1 36:1
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="glyburide" 42:6 42:6
do="10 mg" 42:7 42:8
mo="p.o." 42:9 42:9
f="q. day." 42:10 43:0
du="nm"
r="nm"
ln="list"
5:
m="tylenol #3" 42:3 42:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="antibiotics" 79:0 79:0
do="nm"
mo="iv" 78:8 78:8
f="nm"
du="nm"
r="right toe cellulitis" 78:4 78:6
ln="narrative"
7:
m="clindamycin." 79:4 79:4
do="nm"
mo="iv" 78:8 78:8
f="nm"
du="nm"
r="right toe cellulitis" 78:4 78:6
ln="narrative"
8:
m="gentamicin" 79:2 79:2
do="nm"
mo="iv" 78:8 78:8
f="nm"
du="nm"
r="right toe cellulitis" 78:4 78:6
ln="narrative"
9:
m="atenolol" 80:2 80:2
do="75 mg" 80:8 80:9
mo="p.o." 80:10 80:10
f="q. day." 80:11 80:12
du="nm"
r="nm"
ln="narrative"
10:
m="atenolol" 80:2 80:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="isordil" 81:10 81:10
do="10 mg" 82:0 82:1
mo="p.o." 82:2 82:2
f="t.i.d." 82:3 82:3
du="nm"
r="nm"
ln="narrative"
12:
m="nitropaste" 81:8 81:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="glyburide" 82:6 82:6
do="20 mg" 83:0 83:1
mo="p.o." 83:2 83:2
f="q. day." 83:3 83:4
du="nm"
r="nm"
ln="narrative"
14:
m="glyburide" 82:6 82:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="atenolol" 88:4 88:4
do="75 mg" 88:6 88:7
mo="po" 88:8 88:8
f="q day" 88:9 88:10
du="nm"
r="nm"
ln="list"
16:
m="aspirin" 89:0 89:0
do="325 mg" 89:2 89:3
mo="po" 89:4 89:4
f="q day" 89:5 89:6
du="nm"
r="nm"
ln="list"
17:
m="glyburide" 89:8 89:8
do="20 mg" 89:10 89:11
mo="po" 89:12 89:12
f="q day" 89:13 89:14
du="nm"
r="nm"
ln="list"
18:
m="tylenol #3" 89:16 89:17
do="two tablets" 90:0 90:1
mo="po" 90:2 90:2
f="x one p.r.n." 90:3 90:5
du="nm"
r="nm"
ln="list"
19:
m="nitroglycerin" 90:10 90:10
do="nm"
mo="sublingual" 90:9 90:9
f="p.r.n." 91:0 91:0
du="nm"
r="nm"
ln="list"
