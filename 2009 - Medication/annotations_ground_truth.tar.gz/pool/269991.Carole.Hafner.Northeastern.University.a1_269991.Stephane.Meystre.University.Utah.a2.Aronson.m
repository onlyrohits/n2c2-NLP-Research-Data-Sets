1:
m="nitroglycerins" 34:4 34:4
do="two" 34:2 34:2
mo="sublingual" 34:3 34:3
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="nitroglycerin sprays." 35:2 35:3
do="two" 35:0 35:0
mo="sublingual" 35:1 35:1
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="aspirin" 38:5 38:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="nitroglycerin" 38:9 38:9
do="nm"
mo="sublingual" 38:8 38:8
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="lopressor" 39:3 39:3
do="5 mg" 39:4 39:5
mo="intravenously" 39:8 39:8
f="nm"
du="x 1" 39:6 39:7
r="nm"
ln="narrative"
6:
m="nitro paste" 39:0 39:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="heparin." 40:0 40:0
do="nm"
mo="intravenous" 39:11 39:11
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="glyburide" 54:3 54:3
do="2.5 mg" 54:4 54:5
mo="p.o." 55:0 55:0
f="q.d." 55:1 55:1
du="nm"
r="nm"
ln="list"
9:
m="heparin" 91:4 91:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="nitroglycerin" 91:7 91:7
do="nm"
mo="intravenous" 91:6 91:6
f="nm"
du="for 72 hours after admission" 91:8 92:3
r="nm"
ln="narrative"
11:
m="lopressor" 92:8 92:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="enteric-coated aspirin" 93:0 93:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="glipizide" 113:8 113:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="atenolol" 114:0 114:0
do="50 mg" 114:2 114:3
mo="p.o." 114:4 114:4
f="q.d." 114:5 114:5
du="nm"
r="nm"
ln="narrative"
15:
m="enteric-coated aspirin" 114:8 114:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="heparin" 115:0 115:0
do="nm"
mo="nm"
f="nm"
du="overnight." 115:1 115:1
r="nm"
ln="narrative"
17:
m="atenolol" 124:2 124:2
do="50 mg" 124:3 124:4
mo="p.o." 124:5 124:5
f="q.d." 124:6 124:6
du="nm"
r="nm"
ln="list"
18:
m="nitroglycerins" 125:0 125:0
do="nm"
mo="sublingual" 124:8 124:8
f="p.r.n." 125:1 125:1
du="nm"
r="chest pain" 125:2 125:3
ln="list"
19:
m="glucotrol" 126:0 126:0
do="5 mg" 126:1 126:2
mo="p.o." 126:3 126:3
f="q.d." 126:4 126:4
du="nm"
r="nm"
ln="list"
