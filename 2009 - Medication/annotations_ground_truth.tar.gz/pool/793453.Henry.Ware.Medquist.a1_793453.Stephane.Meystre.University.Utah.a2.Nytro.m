1:
m="ecasa ( aspirin enteric coated )" 19:0 19:5
do="325 mg" 19:6 19:7
mo="po" 19:8 19:8
f="qd" 19:9 19:9
du="nm"
r="nm"
ln="list"
2:
m="colace ( docusate sodium )" 20:0 20:4
do="100 mg" 20:5 20:6
mo="po" 20:7 20:7
f="bid prn" 20:8 20:9
du="nm"
r="constipation" 20:10 20:10
ln="list"
3:
m="enalapril maleate" 21:0 21:1
do="5 mg" 21:2 21:3
mo="po" 21:4 21:4
f="qam" 21:5 21:5
du="nm"
r="nm"
ln="list"
4:
m="potassium chloride" 24:3 24:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="enalapril maleate" 25:0 25:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="kcl immediate release" 28:3 28:5
do="nm"
mo="po" 28:6 28:6
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="enalapril maleate" 29:3 29:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="potassium chloride" 30:0 30:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="enalapril maleate" 31:0 31:1
do="10 mg" 31:2 31:3
mo="po" 31:4 31:4
f="qpm" 31:5 31:5
du="nm"
r="nm"
ln="list"
10:
m="potassium chloride" 34:3 34:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="enalapril maleate" 35:0 35:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="ativan ( lorazepam )" 36:0 36:3
do="1 mg" 36:4 36:5
mo="po" 36:6 36:6
f="tid...prn" 36:7 36:7,37:0 37:0
du="nm"
r="anxiety" 37:1 37:1
ln="list"
13:
m="nitroglycerin 1/150 ( 0.4 mg )" 38:0 38:5
do="1 tab" 38:6 38:7
mo="sl" 38:8 38:8
f="q5min x 3 prn" 38:9 39:0
du="nm"
r="chest pain" 39:1 39:2
ln="list"
14:
m="zoloft ( sertraline )" 40:0 40:3
do="100 mg" 40:4 40:5
mo="po" 40:6 40:6
f="qd" 40:7 40:7
du="nm"
r="nm"
ln="list"
15:
m="zocor ( simvastatin )" 41:0 41:3
do="20 mg" 41:4 41:5
mo="po" 41:6 41:6
f="qhs" 41:7 41:7
du="nm"
r="nm"
ln="list"
16:
m="plavix ( clopidogrel )" 44:0 44:3
do="75 mg" 44:4 44:5
mo="po" 44:6 44:6
f="qd" 44:7 44:7
du="nm"
r="nm"
ln="list"
17:
m="vioxx ( rofecoxib )" 45:0 45:3
do="25 mg" 45:4 45:5
mo="po" 45:6 45:6
f="qd" 45:7 45:7
du="nm"
r="nm"
ln="list"
18:
m="zantac ( ranitidine hcl )" 47:0 47:4
do="150 mg" 47:5 47:6
mo="po" 47:7 47:7
f="bid prn" 47:8 47:9
du="nm"
r="dyspepsia" 47:10 47:10
ln="list"
19:
m="atenolol" 48:0 48:0
do="25 mg" 48:1 48:2
mo="po" 48:3 48:3
f="qd" 48:4 48:4
du="nm"
r="nm"
ln="list"
20:
m="hep" 72:7 72:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="tng" 72:9 72:9
do="nm"
mo="gtt" 73:0 73:0
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="ace" 73:4 73:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="b blocker" 73:6 73:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="demerol" 73:9 73:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="plavix" 73:2 73:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="ace" 82:11 82:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="asa" 82:1 82:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="b blocker" 82:8 82:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="hep" 82:5 82:5
do="nm"
mo="iv" 82:6 82:6
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="plavix" 82:3 82:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="lasix" 83:7 83:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="mild fluid overload" 83:1 83:3
ln="narrative"
32:
m="zocor" 83:0 83:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="ntg" 88:7 88:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="ativan" 89:6 89:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain-free" 90:0 90:0
ln="narrative"
35:
m="demerol" 89:3 89:3
do="nm"
mo="nm"
f="prn" 89:2 89:2
du="nm"
r="nm"
ln="narrative"
36:
m="hep" 90:1 90:1
do="nm"
mo="gtt" 90:2 90:2
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="hep" 95:0 95:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="ativan" 98:2 98:2
do="nm"
mo="nm"
f="prn" 98:3 98:3
du="nm"
r="anxiety." 98:4 98:4
ln="narrative"
39:
m="ativan" 98:6 98:6
do="1 mg" 99:2 99:3
mo="nm"
f="tid" 99:4 99:4
du="nm"
r="anxiety" 99:8 99:8
ln="narrative"
40:
m="ativan" 98:6 98:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="zoloft" 98:5 98:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
