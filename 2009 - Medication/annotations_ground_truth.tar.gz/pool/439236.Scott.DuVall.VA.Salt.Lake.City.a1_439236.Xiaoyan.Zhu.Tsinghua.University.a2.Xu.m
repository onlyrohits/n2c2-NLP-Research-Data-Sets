1:
m="asa ( acetylsalicylic acid )" 16:0 16:4
do="81 mg" 16:5 16:6
mo="po" 16:7 16:7
f="qd" 16:8 16:8
du="nm"
r="nm"
ln="list"
2:
m="gemfibrozil" 17:0 17:0
do="600 mg" 17:1 17:2
mo="po" 17:3 17:3
f="bid" 17:4 17:4
du="nm"
r="nm"
ln="list"
3:
m="zocor" 20:3 20:3
do="nm"
mo="po" 20:4 20:4
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="gemfibrozil" 21:2 21:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="simvastatin" 21:4 21:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="glyburide" 23:0 23:0
do="10 mg" 23:1 23:2
mo="po" 23:3 23:3
f="bid" 23:4 23:4
du="nm"
r="nm"
ln="list"
7:
m="maalox plus extra strength" 24:0 24:3
do="15 ml" 24:4 24:5
mo="po" 24:6 24:6
f="q6h prn" 24:7 24:8
du="nm"
r="indigestion" 24:9 24:9
ln="list"
8:
m="zocor ( simvastatin )" 25:0 25:3
do="20 mg" 25:4 25:5
mo="po" 25:6 25:6
f="qhs" 25:7 25:7
du="nm"
r="nm"
ln="list"
9:
m="gemfibrozil" 30:2 30:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="simvastatin" 30:4 30:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="avandia ( rosiglitazone )" 32:0 32:3
do="4 mg" 32:4 32:5
mo="po" 32:6 32:6
f="bid" 32:7 32:7
du="nm"
r="nm"
ln="list"
12:
m="ocuflox ( ofloxacin 0.3% oph solution )" 33:0 33:6
do="1 drop" 33:7 33:8
mo="os" 33:9 33:9
f="qid" 33:10 33:10
du="number of doses required ( approximate ): 4" 34:0 34:7
r="nm"
ln="list"
13:
m="atenolol" 35:0 35:0
do="50 mg" 35:1 35:2
mo="po" 35:3 35:3
f="qd" 35:4 35:4
du="nm"
r="nm"
ln="list"
14:
m="prilosec ( omeprazole )" 37:0 37:3
do="20 mg" 37:4 37:5
mo="po" 37:6 37:6
f="qd" 37:7 37:7
du="nm"
r="nm"
ln="list"
15:
m="glucophage ( metformin )" 38:0 38:3
do="1 , 000 mg" 38:4 38:7
mo="po" 38:8 38:8
f="bid" 38:9 38:9
du="nm"
r="nm"
ln="list"
16:
m="altace ( ramipril )" 39:0 39:3
do="2.5 mg" 39:4 39:5
mo="po" 39:6 39:6
f="qd" 39:7 39:7
du="nm"
r="nm"
ln="list"
17:
m="potassium chloride" 41:3 41:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="ramipril" 42:0 42:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="lovenox ( enoxaparin )" 43:0 43:3
do="40 mg" 43:4 43:5
mo="sc" 43:6 43:6
f="q12h" 43:7 43:7
du="x 14 days" 43:8 43:10
r="nm"
ln="list"
20:
m="lovenox ( enoxaparin )" 45:0 45:3
do="40 mg" 45:4 45:5
mo="sc" 45:6 45:6
f="qd" 45:7 45:7
du="x 90 days" 45:8 45:10
r="nm"
ln="list"
21:
m="coumadin" 66:1 66:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="lovenox" 79:6 79:6
do="40mg" 80:0 80:0
mo="sc" 80:1 80:1
f="nm"
du="x 3 mo" 80:2 80:4
r="anticoagulation" 78:0 78:0
ln="narrative"
23:
m="lovenox" 79:6 79:6
do="50mg" 79:8 79:8
mo="sc" 79:9 79:9
f="bid" 79:10 79:10
du="x 2 wk" 79:11 79:13
r="anticoagulation" 78:0 78:0
ln="narrative"
24:
m="lovenox" 81:0 81:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="lovenox" 81:2 81:2
do="40mg" 81:3 81:3
mo="sc" 81:4 81:4
f="bid." 81:5 81:5
du="nm"
r="nm"
ln="narrative"
26:
m="lovenox." 83:0 83:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="dobutamine-mibi" 84:4 84:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="his regular medications" 85:5 85:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="lovenox" 86:4 86:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="prilosec" 86:0 86:0
do="20" 86:1 86:1
mo="nm"
f="bid" 86:2 86:2
du="nm"
r="nm"
ln="narrative"
31:
m="lovenox" 92:2 92:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="lovenox" 95:3 95:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="home meds." 99:2 99:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="lovenox" 100:5 100:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="meds." 100:7 100:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="lovenox" 101:1 101:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="lovenox." 102:8 102:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
