1:
m="lantus ( insulin glargine )" 17:0 17:4
do="10 units" 17:5 17:6
mo="sc" 17:7 17:7
f="qd" 17:8 17:8
du="nm"
r="nm"
ln="list"
2:
m="ranitidine hcl syrup" 19:0 19:2
do="150 mg" 19:3 19:4
mo="po" 19:5 19:5
f="bid" 19:6 19:6
du="nm"
r="nm"
ln="list"
3:
m="roxicet elixir ( oxycodone+apap liquid )" 20:0 20:5
do="5-10 milliliters" 21:0 21:1
mo="po" 21:2 21:2
f="q4h prn" 21:3 21:4
du="nm"
r="pain" 21:5 21:5
ln="list"
4:
m="colace ( docusate sodium )" 22:0 22:4
do="100 mg" 22:5 22:6
mo="po" 22:7 22:7
f="tid" 22:8 22:8
du="nm"
r="nm"
ln="list"
5:
m="phenergan ( promethazine hcl )" 24:0 24:4
do="25 mg" 24:5 24:6
mo="pr" 24:7 24:7
f="q6h prn" 24:8 24:9
du="nm"
r="nausea" 24:10 24:10
ln="list"
6:
m="augmentin susp. 250mg/62.5 mg ( 5ml ) ( amoxicil... )" 25:0 25:9
do="10 milliliters" 26:0 26:1
mo="po" 26:2 26:2
f="tid" 26:3 26:3
du="for five days" 26:5 26:7
r="nm"
ln="list"
7:
m="pca analgesia" 51:11 51:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 51:6 51:6
ln="narrative"
8:
m="elixir analgesia" 52:7 52:8
do="nm"
mo="po" 52:6 52:6
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="roxicet" 59:13 59:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="qugmentin suspension" 60:9 60:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="ranitidine elixir" 60:1 60:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="previous home medications." 61:1 61:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="lantus" 63:4 63:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="her diabetes" 62:4 62:5
ln="narrative"
14:
m="narcotic ( pain ) medications." 70:5 70:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
