1:
m="amiodarone" 15:5 15:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="her BP" 15:10 15:11
ln="narrative"
2:
m="dopamine" 15:7 15:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="her BP" 15:10 15:11
ln="narrative"
3:
m="prednisone" 24:5 24:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="amitriptyline" 39:8 39:8
do="25 mg" 40:0 40:1
mo="p.o." 40:2 40:2
f="bedtime" 40:3 40:3
du="nm"
r="nm"
ln="list"
5:
m="enteric-coated aspirin" 40:5 40:6
do="325 mg" 40:7 40:8
mo="p.o." 40:9 40:9
f="daily" 40:10 40:10
du="nm"
r="nm"
ln="list"
6:
m="enalapril" 41:0 41:0
do="20 mg" 41:1 41:2
mo="p.o." 41:3 41:3
f="b.i.d." 41:4 41:4
du="nm"
r="nm"
ln="list"
7:
m="lasix" 41:6 41:6
do="200 mg" 41:7 41:8
mo="p.o." 41:9 41:9
f="b.i.d." 41:10 41:10
du="nm"
r="nm"
ln="list"
8:
m="losartan" 41:12 41:12
do="50 mg" 42:0 42:1
mo="p.o." 42:2 42:2
f="daily" 42:3 42:3
du="nm"
r="nm"
ln="list"
9:
m="advair diskus 250/50" 42:11 43:0
do="one puff" 43:1 43:2
mo="inhaler" 43:3 43:3
f="b.i.d." 43:4 43:4
du="nm"
r="nm"
ln="list"
10:
m="toprol-xl" 42:5 42:5
do="200 mg" 42:6 42:7
mo="p.o." 42:8 42:8
f="b.i.d." 42:9 42:9
du="nm"
r="nm"
ln="list"
11:
m="insulin nph" 43:6 43:7
do="25 units" 44:1 44:2
mo="subcu" 44:4 44:4
f="q.p.m." 44:3 44:3
du="nm"
r="nm"
ln="list"
12:
m="insulin nph" 43:6 43:7
do="50 units" 43:8 43:9
mo="subcu" 43:11 43:11
f="q.a.m." 43:10 43:10
du="nm"
r="nm"
ln="list"
13:
m="insulin lispro" 44:6 44:7
do="18 units" 44:8 44:9
mo="subcu" 44:10 44:10
f="dinner time" 45:0 45:1
du="nm"
r="nm"
ln="list"
14:
m="protonix" 45:3 45:3
do="40 mg" 45:4 45:5
mo="p.o." 45:6 45:6
f="daily" 45:7 45:7
du="nm"
r="nm"
ln="list"
15:
m="sevelamer" 45:9 45:9
do="1200 mg" 45:10 45:11
mo="p.o." 45:12 45:12
f="t.i.d." 46:0 46:0
du="nm"
r="nm"
ln="list"
16:
m="tramadol" 46:2 46:2
do="25 mg" 46:3 46:4
mo="p.o." 46:5 46:5
f="q.6 h. p.r.n." 46:6 46:8
du="nm"
r="pain" 46:9 46:9
ln="list"
17:
m="vancomycin" 88:5 88:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="likely staph aureus growth" 87:4 87:7
ln="narrative"
18:
m="beta-blocker" 101:8 101:8
do="home dose" 101:5 101:6
mo="nm"
f="nm"
du="nm"
r="mild concentric left ventricular hypertrophy" 99:5 99:9
ln="narrative"
19:
m="vancomycin" 109:5 109:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="coag-negative staph positive blood cultures" 107:3 107:7
ln="narrative"
20:
m="long ... acting ... insulin" 115:9 115:9,116:0 116:0,116:2 116:2
do="nm"
mo="subcutaneous" 116:1 116:1
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="nph" 116:8 116:8
do="home dose" 116:5 116:6
mo="nm"
f="bid" 116:9 116:9
du="nm"
r="nm"
ln="narrative"
22:
m="short-acting ... insulin" 116:0 116:0,116:2 116:2
do="nm"
mo="subcutaneous" 116:1 116:1
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="heparin" 119:5 119:5
do="nm"
mo="subcutaneously" 119:6 119:6
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="nexium" 120:0 120:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
