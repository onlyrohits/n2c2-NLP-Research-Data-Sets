1:
m="feso4 ( ferrous sulfate )" 19:0 19:4
do="300 mg" 19:5 19:6
mo="po" 19:7 19:7
f="bid" 19:8 19:8
du="nm"
r="nm"
ln="list"
2:
m="folate ( folic acid )" 22:0 22:4
do="1 mg" 22:5 22:6
mo="po" 22:7 22:7
f="qd" 22:8 22:8
du="nm"
r="nm"
ln="list"
3:
m="synthroid ( levothyroxine sodium )" 23:0 23:4
do="100 mcg" 23:5 23:6
mo="po" 23:7 23:7
f="qd" 23:8 23:8
du="nm"
r="nm"
ln="list"
4:
m="prednisone" 24:0 24:0
do="5 mg" 24:1 24:2
mo="po" 24:3 24:3
f="qam" 24:4 24:4
du="nm"
r="nm"
ln="list"
5:
m="zocor ( simvastatin )" 25:0 25:3
do="20 mg" 25:4 25:5
mo="po" 25:6 25:6
f="qhs" 25:7 25:7
du="nm"
r="nm"
ln="list"
6:
m="neoral" 30:3 30:3
do="nm"
mo="po" 30:4 30:4
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="cyclosporine" 31:5 31:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="simvastatin" 31:3 31:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="neoral ( cyclosporine micro ( neoral ) )" 33:0 33:7
do="100 mg" 33:8 33:9
mo="po" 33:10 33:10
f="bid" 33:11 33:11
du="nm"
r="nm"
ln="list"
10:
m="losartan" 39:3 39:3
do="nm"
mo="po" 39:4 39:4
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="cyclosporine" 40:3 40:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="losartan potassium" 40:5 41:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="cyclosporine" 44:5 44:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="simvastatin" 44:3 44:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="losartan" 46:0 46:0
do="50 mg" 46:1 46:2
mo="po" 46:3 46:3
f="qd" 46:4 46:4
du="nm"
r="nm"
ln="list"
16:
m="cyclosporine" 49:3 49:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="losartan potassium" 49:5 50:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="atenolol" 52:0 52:0
do="25 mg" 52:1 52:2
mo="po" 52:3 52:3
f="qd" 52:4 52:4
du="nm"
r="nm"
ln="list"
19:
m="prilosec ( omeprazole )" 53:0 53:3
do="20 mg" 53:4 53:5
mo="po" 53:6 53:6
f="qd" 53:7 53:7
du="nm"
r="nm"
ln="list"
20:
m="amiodarone" 54:0 54:0
do="200" 56:0 56:0
mo="po" 54:3 54:3
f="qd." 56:1 56:1
du="nm"
r="nm"
ln="list"
21:
m="amiodarone" 54:0 54:0
do="400" 55:8 55:8
mo="nm"
f="qd" 55:9 55:9
du="1 week" 55:11 55:12
r="nm"
ln="list"
22:
m="amiodarone" 54:0 54:0
do="400" 55:8 55:8
mo="po" 54:3 54:3
f="qd" 55:9 55:9
du="x 1 week" 55:10 55:12
r="nm"
ln="list"
23:
m="amiodarone" 54:0 54:0
do="400 mg" 54:1 54:2
mo="po" 54:3 54:3
f="bid" 54:4 54:4
du="x 6 days" 55:3 55:5
r="nm"
ln="list"
24:
m="amiodarone hcl" 57:5 58:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="levofloxacin" 57:3 57:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="ecasa ( aspirin enteric coated )" 59:0 59:5
do="325 mg" 59:6 59:7
mo="po" 59:8 59:8
f="qd" 59:9 59:9
du="nm"
r="nm"
ln="list"
27:
m="flagyl ( metronidazole )" 61:0 61:3
do="500 mg" 61:4 61:5
mo="po" 61:6 61:6
f="tid" 61:7 61:7
du="x 2 days" 61:8 61:10
r="nm"
ln="list"
28:
m="levofloxacin" 63:0 63:0
do="500 mg" 63:1 63:2
mo="po" 63:3 63:3
f="qd" 63:4 63:4
du="x 2 days" 63:5 63:7
r="nm"
ln="list"
29:
m="iron products" 65:1 65:2
do="nm"
mo="nm"
f="a minimum of 2 hours before or after a levofloxacin or ciprofloxacin dose dose if on tube feeds , please cycle ( hold 1 hr before to 2 hr after ) take 2 hours before or 2 hours after dairy products." 65:3 68:11
du="nm"
r="nm"
ln="list"
30:
m="ciprofloxacin" 66:4 66:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="levofloxacin" 66:2 66:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="amiodarone hcl" 70:3 70:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="levofloxacin" 71:0 71:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="levo/flagyl" 115:4 115:4
do="nm"
mo="nm"
f="nm"
du="x 5days" 115:7 115:8
r="nm"
ln="narrative"
35:
m="prbcs." 120:9 120:9
do="2u" 120:8 120:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="lopressor" 124:8 124:8
do="5mg" 124:9 124:9
mo="iv" 125:0 125:0
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="ivf." 125:10 125:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypotension" 125:3 125:3
ln="narrative"
38:
m="dilt" 126:4 126:4
do="nm"
mo="drip." 126:5 126:5
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="amio" 128:2 128:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="anticoagulation" 129:10 129:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="paf" 130:0 130:0
ln="narrative"
41:
m="ecasa" 130:11 130:11
do="nm"
mo="nm"
f="nm"
du="5d" 130:12 130:12
r="nm"
ln="narrative"
42:
m="ecasa" 130:11 130:11
do="nm"
mo="nm"
f="nm"
du="5d" 137:8 137:8
r="nm"
ln="narrative"
43:
m="prbc." 135:2 135:2
do="2u" 135:1 135:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="abx." 137:9 137:9
do="nm"
mo="nm"
f="nm"
du="5d" 137:8 137:8
r="nm"
ln="narrative"
