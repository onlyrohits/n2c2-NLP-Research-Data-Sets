1:
m="acetylsalicylic acid" 16:0 16:1
do="81 mg" 16:2 16:3
mo="po" 16:4 16:4
f="qd" 16:5 16:5
du="nm"
r="nm"
ln="list"
2:
m="elavil ( amitriptyline hcl )" 17:0 17:4
do="10 mg" 17:5 17:6
mo="po" 17:7 17:7
f="qhs" 17:8 17:8
du="nm"
r="nm"
ln="list"
3:
m="atenolol" 18:0 18:0
do="25 mg" 18:1 18:2
mo="po" 18:3 18:3
f="qd" 18:4 18:4
du="nm"
r="nm"
ln="list"
4:
m="colace ( docusate sodium )" 19:0 19:4
do="100 mg" 19:5 19:6
mo="po" 19:7 19:7
f="bid" 19:8 19:8
du="nm"
r="nm"
ln="list"
5:
m="furosemide" 20:0 20:0
do="20 mg" 20:1 20:2
mo="po" 20:3 20:3
f="qd" 20:4 20:4
du="nm"
r="nm"
ln="list"
6:
m="guaifenesin" 21:0 21:0
do="10 milliliters" 21:1 21:2
mo="po" 21:3 21:3
f="tid...prn" 21:4 21:4,22:0 22:0
du="nm"
r="nm"
ln="list"
7:
m="oxycodone" 23:0 23:0
do="5 mg" 23:1 23:2
mo="po" 23:3 23:3
f="tid...prn" 23:4 23:4 23:10 23:10
du="nm"
r="pain" 23:11 23:11
ln="list"
8:
m="morphine" 25:0 25:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="quinine sulfate" 26:0 26:1
do="325 mg" 26:2 26:3
mo="po" 26:4 26:4
f="hs" 26:5 26:5
du="nm"
r="nm"
ln="list"
10:
m="senna tablets ( sennosides )" 28:0 28:4
do="2 tab" 28:5 28:6
mo="po" 28:7 28:7
f="bid" 28:8 28:8
du="nm"
r="nm"
ln="list"
11:
m="mvi therapeutic ( therapeutic multivitamins )" 29:0 29:5
do="1 tab" 29:6 29:7
mo="po" 29:8 29:8
f="qd" 29:9 29:9
du="nm"
r="nm"
ln="list"
12:
m="niacin" 32:5 32:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="simvastatin" 32:3 32:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="vit. b-3" 33:0 33:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="zocor ( simvastatin )" 34:0 34:3
do="20 mg" 34:4 34:5
mo="po" 34:6 34:6
f="qhs" 34:7 34:7
du="nm"
r="nm"
ln="list"
16:
m="niacin" 40:5 40:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="simvastatin" 40:3 40:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="vit. b-3" 41:0 41:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="morphine controlled release" 42:0 42:2
do="15 mg" 42:3 42:4
mo="po" 42:5 42:5
f="q12h" 42:6 42:6
du="nm"
r="nm"
ln="list"
20:
m="felodipine" 43:0 43:0
do="5 mg" 43:1 43:2
mo="po" 43:3 43:3
f="qd" 43:4 43:4
du="number of doses required ( approximate ): 5" 45:0 45:7
r="nm"
ln="list"
21:
m="flonase ( fluticasone nasal spray )" 46:0 46:5
do="1 spray" 46:6 46:7
mo="inh" 46:8 46:8
f="qd" 46:9 46:9
du="number of doses required ( approximate ): 5" 47:0 47:7
r="nm"
ln="narrative"
22:
m="advair diskus 500/50 ( fluticasone propionate/... )" 48:0 48:6
do="1 puff" 49:0 49:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="caltrate + d (calcium carbonate 1, 500 mg (600 ...)" 50:0 50:13
do="1 tab" 51:0 51:1
mo="po" 51:2 51:2
f="bid" 51:3 51:3
du="nm"
r="nm"
ln="list"
24:
m="novolog mix 70/30 ( insulin aspart 70/30 )" 52:0 52:7
do="22 units" 53:3 53:4
mo="sc" 53:6 53:6
f="qpm" 53:5 53:5
du="nm"
r="nm"
ln="list"
25:
m="novolog mix 70/30 ( insulin aspart 70/30 )" 52:0 52:7
do="35 units" 53:0 53:1
mo="nm"
f="qam;" 53:2 53:2
du="nm"
r="nm"
ln="list"
26:
m="novolog mix 70/30 ( insulin aspart 70/30 )" 52:0 52:7
do="35 units" 53:7 53:8
mo="sc" 53:6 53:6
f="qam" 53:9 53:9
du="nm"
r="nm"
ln="list"
27:
m="prednisone" 54:0 54:0
do="10 mg" 59:1 59:2
mo="nm"
f="q 24 h" 59:3 59:5
du="x 3 dose( s )" 59:6 59:10
r="nm"
ln="list"
28:
m="prednisone" 54:0 54:0
do="20 mg" 58:1 58:2
mo="nm"
f="q 24 h" 58:3 58:5
du="x 3 dose( s )" 58:6 58:10
r="nm"
ln="list"
29:
m="prednisone" 54:0 54:0
do="30 mg" 57:1 57:2
mo="nm"
f="q 24 h" 57:3 57:5
du="x 3 dose( s )" 57:6 57:10
r="nm"
ln="list"
30:
m="prednisone" 54:0 54:0
do="40 mg" 56:1 56:2
mo="nm"
f="q 24 h" 56:3 56:5
du="x 3 dose( s )" 56:6 56:10
r="nm"
ln="list"
31:
m="prednisone" 54:0 54:0
do="50 mg" 55:1 55:2
mo="nm"
f="q 24 h" 55:3 55:5
du="x 3 dose( s )" 55:6 55:10
r="nm"
ln="list"
32:
m="prednisone" 54:0 54:0
do="5 mg" 60:1 60:2
mo="nm"
f="q 24 h" 60:3 60:5
du="x 3 dose( s )" 60:6 60:10
r="nm"
ln="list"
33:
m="prednisone" 54:0 54:0
do="60 mg" 54:4 54:5
mo="po" 54:2 54:2
f="q 24 h" 54:6 54:8
du="x 5 dose( s )" 54:9 54:13
r="nm"
ln="list"
34:
m="combivent ( ipratropium and albuterol sulfate )" 61:0 61:6
do="2 puff" 62:0 62:1
mo="inh" 62:2 62:2
f="qid" 62:3 62:3
du="nm"
r="nm"
ln="list"
35:
m="azithromycin" 85:6 85:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="levofloxacin" 91:3 91:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="o2" 91:1 91:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="atenolol" 93:2 93:2
do="25mg" 93:3 93:3
mo="po" 93:9 93:9
f="qd" 93:5 93:5
du="nm"
r="nm"
ln="list"
39:
m="felodipine" 93:12 93:12
do="5mg" 93:13 93:13
mo="po" 93:14 93:14
f="qd" 93:15 93:15
du="nm"
r="nm"
ln="list"
40:
m="hctz" 93:7 93:7
do="25mg" 93:8 93:8
mo="po" 93:9 93:9
f="qd" 93:10 93:10
du="nm"
r="nm"
ln="list"
41:
m="advair" 94:10 94:10
do="1 puff" 94:11 94:12
mo="nm"
f="bid" 94:13 94:13
du="nm"
r="nm"
ln="list"
42:
m="asa" 94:5 94:5
do="81mg" 94:6 94:6
mo="po" 94:7 94:7
f="qd" 94:8 94:8
du="nm"
r="nm"
ln="list"
43:
m="combivent" 94:15 94:15
do="2 puffs" 94:16 94:17
mo="nm"
f="qid" 95:0 95:0
du="nm"
r="nm"
ln="list"
44:
m="zocor" 94:0 94:0
do="20mg" 94:1 94:1
mo="po" 94:2 94:2
f="qhs" 94:3 94:3
du="nm"
r="nm"
ln="list"
45:
m="guqifenesin" 95:7 95:7
do="600mg" 95:8 95:8
mo="po" 95:9 95:9
f="q12h" 95:10 95:10
du="nm"
r="nm"
ln="list"
46:
m="loratidine" 95:2 95:2
do="10mg" 95:3 95:3
mo="po" 95:4 95:4
f="qd" 95:5 95:5
du="nm"
r="nm"
ln="list"
47:
m="morphine" 95:12 95:12
do="15mg" 95:13 95:13
mo="po" 95:14 95:14
f="q8-12h" 96:0 96:0
du="nm"
r="nm"
ln="list"
48:
m="colace" 96:14 96:14
do="100mg" 97:0 97:0
mo="po" 97:1 97:1
f="bid" 97:2 97:2
du="nm"
r="nm"
ln="list"
49:
m="percocet" 96:2 96:2
do="1-2 tab" 96:3 96:4
mo="po" 96:5 96:5
f="q6h" 96:6 96:6
du="nm"
r="nm"
ln="list"
50:
m="quinine sulfate" 96:8 96:9
do="325mg" 96:10 96:10
mo="po" 96:11 96:11
f="qhs" 96:12 96:12
du="nm"
r="nm"
ln="list"
51:
m="calcium+vim d" 97:10 97:11
do="125 units" 97:12 97:13
mo="po" 97:14 97:14
f="qd" 97:15 97:15
du="nm"
r="nm"
ln="narrative"
52:
m="elavil" 97:17 97:17
do="10 mg" 98:0 98:0
mo="po" 98:1 98:1
f="qhs" 98:2 98:2
du="nm"
r="nm"
ln="list"
53:
m="senna" 97:4 97:4
do="2 tab" 97:5 97:6
mo="po" 97:7 97:7
f="qd" 97:8 97:8
du="nm"
r="nm"
ln="list"
54:
m="duonebs" 117:12 117:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="COPD flare" 117:6 117:7
ln="narrative"
55:
m="o2" 117:10 117:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="COPD flare" 117:6 117:7
ln="narrative"
56:
m="steroids" 118:0 118:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="COPD flare" 117:6 117:7
ln="narrative"
57:
m="lasix" 123:4 123:4
do="nm"
mo="iv" 123:10 123:10
f="nm"
du="nm"
r="his heart failure" 122:9 123:0
ln="narrative"
58:
m="lasix" 123:4 123:4
do="nm"
mo="po" 123:7 123:7
f="nm"
du="nm"
r="his heart failure" 122:9 123:0
ln="narrative"
59:
m="novolog" 130:12 130:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="his diabetes" 130:3 130:4
ln="narrative"
60:
m="steroids" 131:0 131:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="elavil" 138:8 138:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="sleep" 138:10 138:10
ln="narrative"
62:
m="morphine" 138:2 138:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic pain" 137:3 137:4
ln="narrative"
63:
m="morphine" 138:2 138:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="insomnia" 137:6 137:6
ln="narrative"
64:
m="oxycodone" 138:4 138:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic pain" 137:3 137:4
ln="narrative"
65:
m="oxycodone" 138:4 138:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="insomnia" 137:6 137:6
ln="narrative"
66:
m="lovenox" 139:10 139:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="anticoagulation" 139:12 139:12
ln="narrative"
67:
m="oxygen" 140:6 140:6
do="nm"
mo="nm"
f="at night" 140:11 140:12
du="nm"
r="nm"
ln="narrative"
68:
m="combivent inhalers" 141:0 141:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="steroid" 141:4 141:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
70:
m="hydrochlorathiazide ( hctz )" 142:0 142:3
do="25mg." 142:4 142:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
71:
m="lasix" 142:10 142:10
do="20mg" 142:11 142:11
mo="nm"
f="once a day" 143:0 143:2
du="nm"
r="nm"
ln="narrative"
72:
m="lasix" 146:2 146:2
do="40mg" 146:3 146:3
mo="po" 146:4 146:4
f="qd" 146:5 146:5
du="nm"
r="nm"
ln="narrative"
73:
m="prednisone" 147:2 147:2
do="nm"
mo="nm"
f="nm"
du="20 days" 147:6 147:7
r="nm"
ln="narrative"
74:
m="htn medications" 148:6 148:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
75:
m="ace inhibitor" 149:6 149:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
76:
m="lasix" 149:3 149:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
