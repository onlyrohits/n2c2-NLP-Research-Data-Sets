1:
m="hydrochlorothiazide" 23:5 23:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
2:
m="methyldopa" 23:3 23:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="nortriptyline" 23:1 23:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="zantac" 23:7 23:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="advil" 24:2 24:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="alternagel" 24:4 24:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="estrogen" 24:0 24:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="lasix" 45:3 45:3
do="20 milligrams" 45:5 45:6
mo="intravenous" 45:2 45:2
f="nm"
du="two doses" 44:8 45:0
r="pulmonary edema" 44:3 44:4
ln="narrative"
9:
m="calcium channel blocker" 58:12 59:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="an elevated diastolic pressure" 56:7 56:10
ln="narrative"
10:
m="verapamil" 59:1 59:1
do="240 milligrams" 59:2 59:3
mo="p.o." 59:4 59:4
f="q.d." 59:5 59:5
du="nm"
r="nm"
ln="narrative"
11:
m="verapamil sr" 63:2 63:3
do="240 milligrams" 63:4 63:5
mo="p.o." 63:6 63:6
f="q.d." 63:7 63:7
du="nm"
r="nm"
ln="list"
12:
m="estrogen" 64:4 64:4
do="1.25 milligrams" 64:5 65:0
mo="nm"
f="q.d." 65:1 65:1
du="nm"
r="nm"
ln="list"
13:
m="zantac" 64:0 64:0
do="300 milligrams" 64:1 64:2
mo="nm"
f="q.d." 64:3 64:3
du="nm"
r="nm"
ln="list"
14:
m="advil" 65:2 65:2
do="800 milligrams" 65:3 65:4
mo="p.o." 65:5 65:5
f="b.i.d. p.r.n." 65:6 65:7
du="nm"
r="nm"
ln="list"
15:
m="hydrochlorothiazide" 66:0 66:0
do="25 milligrams" 66:1 66:2
mo="p.o." 66:3 66:3
f="q.d." 66:4 66:4
du="nm"
r="nm"
ln="list"
16:
m="methyldopa" 66:5 66:5
do="250 milligrams" 66:6 67:0
mo="nm"
f="q.d." 67:1 67:1
du="nm"
r="nm"
ln="list"
17:
m="nortriptyline" 67:2 67:2
do="125 milligrams" 67:3 67:4
mo="p.o." 67:5 67:5
f="q.h.s." 67:6 67:6
du="nm"
r="nm"
ln="list"
