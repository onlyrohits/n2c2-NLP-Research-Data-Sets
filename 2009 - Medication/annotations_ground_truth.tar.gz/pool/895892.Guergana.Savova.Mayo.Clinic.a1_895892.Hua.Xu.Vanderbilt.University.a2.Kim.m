1:
m="albuterol" 45:5 45:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
2:
m="atrovent" 45:3 45:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="elavil" 45:9 45:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="flovent" 45:7 45:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="metformin" 45:1 45:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="axid" 46:4 46:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="cardizem cd" 46:9 46:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="cisapride" 46:0 46:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="flexeril" 46:2 46:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="nph insulin" 46:6 46:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="lasix" 47:2 47:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="lisinopril" 47:0 47:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="magnesium oxide" 47:4 47:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="percocet" 47:7 47:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="premarin" 47:9 47:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="provera" 47:11 47:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="lipitor" 48:2 48:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="multi-vitamins" 48:6 48:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="prilosec" 48:0 48:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="tums" 48:4 48:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="fluconazole" 65:8 65:8
do="nm"
mo="nm"
f="nm"
du="a seven-day course" 66:8 66:10
r="a urinary tract infection" 64:9 65:0
ln="narrative"
22:
m="biaxin" 68:6 68:6
do="nm"
mo="nm"
f="nm"
du="a seven-day course" 69:6 69:8
r="peptic ulcer disease" 67:8 67:10
ln="narrative"
23:
m="bismuth" 68:8 68:8
do="nm"
mo="nm"
f="nm"
du="a seven-day course" 69:6 69:8
r="peptic ulcer disease" 67:8 67:10
ln="narrative"
24:
m="antibiotics" 73:5 73:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
