1:
m="ecotrin ( aspirin enteric coated )" 16:0 16:5
do="325 mg" 16:6 16:7
mo="po" 16:8 16:8
f="qd" 16:9 16:9
du="nm"
r="nm"
ln="list"
2:
m="atenolol" 17:0 17:0
do="50 mg" 17:1 17:2
mo="po" 17:3 17:3
f="qd" 17:4 17:4
du="nm"
r="nm"
ln="list"
3:
m="ferro-sequels" 18:0 18:0
do="1 tab" 18:1 18:2
mo="po" 18:3 18:3
f="qd" 18:4 18:4
du="nm"
r="nm"
ln="list"
4:
m="lisinopril" 19:0 19:0
do="30 mg" 19:1 19:2
mo="po" 19:3 19:3
f="qd" 19:4 19:4
du="nm"
r="nm"
ln="list"
5:
m="pravachol ( pravastatin )" 20:0 20:3
do="80 mg" 20:4 20:5
mo="po" 20:6 20:6
f="qhs" 20:7 20:7
du="nm"
r="nm"
ln="list"
6:
m="norvasc ( amlodipine )" 23:0 23:3
do="5 mg" 23:4 23:5
mo="po" 23:6 23:6
f="qd" 23:7 23:7
du="nm"
r="nm"
ln="list"
7:
m="imdur er ( isosorbide mononitrate ( sr ) )" 26:0 26:8
do="120 mg" 26:9 26:10
mo="po" 26:11 26:11
f="qd" 26:12 26:12
du="nm"
r="nm"
ln="list"
8:
m="pilocarpine 2%" 30:0 30:1
do="1 drop" 30:2 30:3
mo="ou" 30:4 30:4
f="bid" 30:5 30:5
du="nm"
r="nm"
ln="list"
9:
m="bactrim ds ( trimethoprim/sulfamethoxazole dou... )" 31:0 31:5
do="1 tab" 32:0 32:1
mo="po" 32:2 32:2
f="bid" 32:3 32:3
du="x 12 doses" 32:4 32:6
r="nm"
ln="list"
10:
m="clobetasol propionate 0.05% cream" 34:0 34:3
do="nm"
mo="tp" 34:4 34:4
f="bid" 34:5 34:5
du="number of doses required ( approximate ): 10" 36:0 36:7
r="nm"
ln="list"
11:
m="allegra ( fexofenadine hcl )" 37:0 37:4
do="60 mg" 37:5 37:6
mo="po" 37:7 37:7
f="qd" 37:8 37:8
du="nm"
r="nm"
ln="list"
12:
m="allegra" 41:3 41:3
do="nm"
mo="po" 41:4 41:4
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="alphagan ( brimonidine tartrate )" 44:0 44:4
do="1 drop" 44:5 44:6
mo="ou" 44:7 44:7
f="bid" 44:8 44:8
du="number of doses required ( approximate ): 10" 45:0 45:7
r="nm"
ln="list"
14:
m="plavix ( clopidogrel )" 46:0 46:3
do="75 mg" 46:4 46:5
mo="po" 46:6 46:6
f="qd" 46:7 46:7
du="nm"
r="nm"
ln="list"
15:
m="calcium carbonate" 47:0 47:1
do="1 , 500 mg" 47:2 47:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="vit d" 47:12 47:13
do="200 iu 1 tab" 47:14 48:1
mo="po" 48:2 48:2
f="qd" 48:3 48:3
du="nm"
r="nm"
ln="list"
17:
m="zetia ( ezetimibe )" 49:0 49:3
do="10 mg" 49:4 49:5
mo="po" 49:6 49:6
f="qd" 49:7 49:7
du="nm"
r="nm"
ln="list"
18:
m="metformin" 50:0 50:0
do="250 mg" 50:1 50:2
mo="po" 50:3 50:3
f="bid" 50:4 50:4
du="nm"
r="nm"
ln="list"
19:
m="aciphex ( rabeprazole )" 51:0 51:3
do="20 mg" 51:4 51:5
mo="po" 51:6 51:6
f="qd" 51:7 51:7
du="nm"
r="nm"
ln="list"
20:
m="maalox" 81:5 81:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="substernal epigastric pain" 80:7 80:9
ln="narrative"
21:
m="ntg" 81:8 81:8
do="3" 81:7 81:7
mo="nm"
f="nm"
du="nm"
r="pain" 81:10 81:10
ln="narrative"
22:
m="nitro" 84:3 84:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="vague symptoms" 83:12 83:13
ln="narrative"
23:
m="calcium 600+d" 100:6 100:7
do="nm"
mo="nm"
f="daily" 100:8 100:8
du="nm"
r="nm"
ln="list"
24:
m="isosorbide" 100:10 100:10
do="120mg" 101:0 101:0
mo="nm"
f="daily" 101:1 101:1
du="nm"
r="nm"
ln="list"
25:
m="lisinopril" 100:2 100:2
do="20mg" 100:3 100:3
mo="nm"
f="daily" 100:4 100:4
du="nm"
r="nm"
ln="list"
26:
m="allegra" 101:7 101:7
do="60mg" 101:8 101:8
mo="nm"
f="daily" 101:9 101:9
du="nm"
r="nm"
ln="list"
27:
m="asa" 101:11 101:11
do="325mg" 101:12 101:12
mo="nm"
f="daily" 101:13 101:13
du="nm"
r="nm"
ln="list"
28:
m="metformin" 101:3 101:3
do="250mg" 101:4 101:4
mo="nm"
f="bid" 101:5 101:5
du="nm"
r="nm"
ln="list"
29:
m="alphagam gtts" 102:0 102:1
do="nm"
mo="nm"
f="bid" 102:2 102:2
du="nm"
r="nm"
ln="list"
30:
m="clobetizol cream" 102:8 102:9
do="0.5mg" 102:10 102:10
mo="nm"
f="bid" 102:11 102:11
du="nm"
r="nm"
ln="narrative"
31:
m="pilocarpine 2%" 102:4 102:5
do="nm"
mo="nm"
f="bid" 102:6 102:6
du="nm"
r="nm"
ln="list"
32:
m="atenolol" 103:12 103:12
do="50mg" 103:13 103:13
mo="nm"
f="daily" 104:0 104:0
du="nm"
r="nm"
ln="list"
33:
m="norvasc" 103:8 103:8
do="5mg" 103:9 103:9
mo="nm"
f="daily" 103:10 103:10
du="nm"
r="nm"
ln="list"
34:
m="pravachol" 103:0 103:0
do="80mg" 103:1 103:1
mo="nm"
f="qhs" 103:2 103:2
du="nm"
r="nm"
ln="list"
35:
m="zetia" 103:4 103:4
do="10mg" 103:5 103:5
mo="nm"
f="qhs" 103:6 103:6
du="nm"
r="nm"
ln="list"
36:
m="acephex" 104:5 104:5
do="20mg" 104:6 104:6
mo="nm"
f="daily" 104:7 104:7
du="nm"
r="nm"
ln="narrative"
37:
m="ferrex" 104:2 104:2
do="nm"
mo="nm"
f="1/day" 104:3 104:3
du="nm"
r="nm"
ln="list"
38:
m="ntg" 104:13 104:13
do="nm"
mo="nm"
f="prn" 104:14 104:14
du="nm"
r="nm"
ln="list"
39:
m="plavix" 104:9 104:9
do="75mg" 104:10 104:10
mo="nm"
f="qhs" 104:11 104:11
du="nm"
r="nm"
ln="list"
40:
m="asa" 132:12 132:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="ace" 133:4 133:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="bb" 133:2 133:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="plavix" 133:0 133:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="statin" 133:6 133:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="zetia" 133:8 133:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="ace" 134:7 134:7
do="30mg" 134:14 134:14
mo="nm"
f="daily" 135:0 135:0
du="nm"
r="bp" 134:10 134:10
ln="narrative"
47:
m="bp meds" 136:7 136:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="ppi." 138:6 138:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="esophageal spasm" 138:2 138:3
ln="narrative"
49:
m="iron" 141:6 141:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="fed anemia" 141:2 141:3
ln="narrative"
50:
m="lantus" 142:2 142:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="novolog" 142:4 142:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="novolog" 142:8 142:8
do="sliding scale" 142:9 142:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="metformin" 143:3 143:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="bactrim" 144:4 144:4
do="nm"
mo="nm"
f="nm"
du="for 7 day course" 144:5 144:8
r="nm"
ln="narrative"
55:
m="steroid ointment" 145:2 145:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="eyedrops." 146:2 146:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="lovenox" 148:1 148:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
58:
m="ppi" 148:3 148:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="lisinopril" 153:1 153:1
do="30mg" 153:6 153:6
mo="nm"
f="daily." 153:7 153:7
du="nm"
r="nm"
ln="narrative"
60:
m="lisinopril" 153:1 153:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="bactrim" 154:1 154:1
do="nm"
mo="nm"
f="nm"
du="for 7 days" 154:2 154:4
r="a urinary tract infection" 154:6 154:9
ln="narrative"
62:
m="other medications" 154:11 155:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="ace" 158:5 158:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
