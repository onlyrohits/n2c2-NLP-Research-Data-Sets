1:
m="avapro" 32:7 32:7
do="150 mg" 32:8 32:9
mo="nm"
f="q.d." 32:10 32:10
du="nm"
r="nm"
ln="list"
2:
m="verapamil" 32:2 32:2
do="80 mg" 32:3 32:4
mo="nm"
f="b.i.d." 32:5 32:5
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 33:0 33:0
do="325 mg" 33:1 33:2
mo="nm"
f="q.d." 33:3 33:3
du="nm"
r="nm"
ln="list"
4:
m="heparin" 33:5 33:5
do="nm"
mo="iv" 33:4 33:4
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="hydrochlorothiazide" 33:7 33:7
do="50 mg" 33:8 33:9
mo="nm"
f="q.d." 33:10 33:10
du="nm"
r="nm"
ln="list"
6:
m="albuterol" 34:0 34:0
do="2 puffs" 34:1 34:2
mo="nm"
f="b.i.d." 34:3 34:3
du="nm"
r="nm"
ln="list"
7:
m="fluticasone" 34:5 34:5
do="2 puffs" 34:6 34:7
mo="nm"
f="q.i.d." 34:8 34:8
du="nm"
r="nm"
ln="list"
8:
m="atorvastatin" 35:0 35:0
do="10 mg" 35:1 35:2
mo="nm"
f="q.d." 35:3 35:3
du="nm"
r="nm"
ln="list"
9:
m="celexa" 35:5 35:5
do="20 mg" 35:6 35:7
mo="nm"
f="q.d." 35:8 35:8
du="nm"
r="nm"
ln="list"
10:
m="ibuprofen" 35:10 35:10
do="800 mg" 35:11 35:12
mo="nm"
f="b.i.d." 36:0 36:0
du="nm"
r="nm"
ln="list"
11:
m="nph insulin" 36:1 36:2
do="30 units" 36:3 36:4
mo="nm"
f="b.i.d." 36:5 36:5
du="nm"
r="nm"
ln="list"
12:
m="copd medications" 85:8 86:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="beta-blocker." 87:8 87:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="a systolic blood pressure" 86:9 87:2
ln="narrative"
14:
m="percocet" 88:7 88:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="break through pain" 88:9 89:1
ln="narrative"
15:
m="toradol" 88:2 88:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 88:5 88:5
ln="narrative"
16:
m="oxygen" 94:5 94:5
do="3 liters" 94:2 94:3
mo="nasal cannula" 94:8 94:9
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="oxygen" 99:7 99:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="antibiotic" 121:8 121:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="enteric-coated aspirin" 130:2 130:3
do="325 mg" 130:4 130:5
mo="nm"
f="q.d." 130:6 130:6
du="nm"
r="nm"
ln="list"
20:
m="lasix" 130:8 130:8
do="40 mg" 131:7 131:8
mo="nm"
f="b.i.d." 131:9 131:9
du="for 3 days" 131:10 131:12
r="nm"
ln="list"
21:
m="lasix" 130:8 130:8
do="60 mg" 131:0 131:1
mo="nm"
f="b.i.d." 131:2 131:2
du="for 3 days" 131:3 131:5
r="nm"
ln="list"
22:
m="ibuprofen" 131:14 131:14
do="600 mg" 132:0 132:1
mo="nm"
f="q.6h p.r.n." 132:2 132:3
du="nm"
r="pain" 132:4 132:4
ln="list"
23:
m="lopressor" 132:6 132:6
do="50 mg" 132:7 132:8
mo="nm"
f="t.i.d." 132:9 132:9
du="nm"
r="nm"
ln="list"
24:
m="niferex 150" 132:11 132:12
do="150 mg" 132:13 133:0
mo="nm"
f="b.i.d." 133:1 133:1
du="nm"
r="nm"
ln="list"
25:
m="k-dur" 133:8 133:8
do="20 meq" 134:0 134:1
mo="nm"
f="b.i.d." 134:2 134:2
du="nm"
r="nm"
ln="list"
26:
m="k-dur" 133:8 133:8
do="30 meq" 133:9 133:10
mo="nm"
f="b.i.d." 133:11 133:11
du="nm"
r="nm"
ln="list"
27:
m="simvastatin" 133:3 133:3
do="20 mg" 133:4 133:5
mo="nm"
f="q.h.s." 133:6 133:6
du="nm"
r="nm"
ln="list"
28:
m="fluticasone" 134:4 134:4
do="44 mcg" 134:5 134:6
mo="inhaled" 134:7 134:7
f="b.i.d." 134:8 134:8
du="nm"
r="nm"
ln="list"
29:
m="levofloxacin" 134:10 134:10
do="500 mg" 135:0 135:1
mo="nm"
f="q.d." 135:2 135:2
du="for 2 days" 135:3 135:5
r="uti" 135:10 135:10
ln="list"
30:
m="humalog" 135:12 135:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="humalog insulin" 136:5 136:6
do="12 units" 136:7 136:8
mo="subq" 136:9 136:9
f="with lunch and dinner" 136:10 137:2
du="nm"
r="nm"
ln="list"
32:
m="insulin" 136:0 136:0
do="sliding scale" 136:2 136:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="humalog insulin" 137:4 137:5
do="16 units" 137:6 137:7
mo="subcutaneous" 137:8 137:8
f="with breakfast" 137:9 138:0
du="nm"
r="nm"
ln="list"
34:
m="celexa" 138:2 138:2
do="20 mg" 138:3 138:4
mo="nm"
f="q.d." 138:5 138:5
du="nm"
r="nm"
ln="list"
35:
m="combivent" 138:7 138:7
do="2 puffs" 138:8 138:9
mo="inhaled" 138:10 138:10
f="q.i.d." 138:11 138:11
du="nm"
r="nm"
ln="list"
36:
m="lantus insulin" 139:6 139:7
do="62 units" 139:8 139:9
mo="subcutaneous" 139:10 139:10
f="q.h.s." 140:0 140:0
du="nm"
r="nm"
ln="list"
37:
m="nexium" 139:0 139:0
do="20 mg" 139:1 139:2
mo="nm"
f="q.d." 139:3 139:3
du="nm"
r="nm"
ln="list"
