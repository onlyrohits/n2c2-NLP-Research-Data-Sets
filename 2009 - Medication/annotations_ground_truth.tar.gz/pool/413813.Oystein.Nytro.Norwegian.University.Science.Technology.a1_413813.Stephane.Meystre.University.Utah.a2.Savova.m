1:
m="tylenol ( acetaminophen )" 16:0 16:3
do="650 mg" 16:4 16:5
mo="po" 16:6 16:6
f="q4h prn" 16:7 16:8
du="nm"
r="headache" 16:9 16:9
ln="list"
2:
m="persantine ( dipyridamole )" 17:0 17:3
do="50 mg" 17:4 17:5
mo="po" 17:6 17:6
f="bid" 17:7 17:7
du="nm"
r="nm"
ln="list"
3:
m="lasix ( furosemide )" 18:0 18:3
do="10 mg" 18:4 18:5
mo="po" 18:6 18:6
f="qd" 18:7 18:7
du="nm"
r="nm"
ln="list"
4:
m="ativan ( lorazepam )" 19:0 19:3
do="3.5 mg" 19:4 19:5
mo="po" 19:6 19:6
f="qhs" 19:7 19:7
du="nm"
r="nm"
ln="list"
5:
m="ativan ( lorazepam )" 21:0 21:3
do="2 mg" 21:4 21:5
mo="po" 21:6 21:6
f="qid prn" 21:7 21:8
du="nm"
r="anxiety" 21:9 21:9
ln="list"
6:
m="ntg 1/150 ( nitroglycerin 1/150 ( 0.4 mg ) )" 23:0 23:9
do="1 tab" 24:0 24:1
mo="sl" 24:2 24:2
f="q5min" 24:3 24:3
du="x 3 doses prn" 24:4 24:7
r="chest pain" 24:8 24:9
ln="list"
7:
m="nitroglycerin paste 2%" 25:0 25:2
do="1 inches" 25:3 25:4
mo="tp" 25:5 25:5
f="bid" 25:6 25:6
du="nm"
r="nm"
ln="list"
8:
m="inderal ( propranolol hcl )" 27:0 27:4
do="10 mg" 27:5 27:6
mo="po" 27:7 27:7
f="qid" 27:8 27:8
du="nm"
r="nm"
ln="list"
9:
m="sucralfate" 31:0 31:0
do="1 gm" 31:1 31:2
mo="po" 31:3 31:3
f="qid" 31:4 31:4
du="nm"
r="nm"
ln="list"
10:
m="paxil ( paroxetine )" 34:0 34:3
do="10 mg" 34:4 34:5
mo="po" 34:6 34:6
f="qd" 34:7 34:7
du="nm"
r="nm"
ln="list"
11:
m="norvasc ( amlodipine )" 35:0 35:3
do="2.5 mg" 35:4 35:5
mo="po" 35:6 35:6
f="qd" 35:7 35:7
du="nm"
r="nm"
ln="list"
12:
m="norvasc" 41:3 41:3
do="5 mg" 41:5 41:6
mo="po" 41:4 41:4
f="qd" 41:7 41:7
du="nm"
r="nm"
ln="list"
13:
m="imdur er ( isosorbide mononitrate ( sr ) )" 44:0 44:8
do="30 mg" 44:9 44:10
mo="po" 44:11 44:11
f="bid" 44:12 44:12
du="nm"
r="nm"
ln="list"
14:
m="cozaar ( losartan )" 49:0 49:3
do="50 mg" 49:4 49:5
mo="po" 49:6 49:6
f="qd" 49:7 49:7
du="number of doses required (approximate): 3" 51:0 51:7
r="nm"
ln="list"
15:
m="protonix ( pantoprazole )" 52:0 52:3
do="40 mg" 52:4 52:5
mo="po" 52:6 52:6
f="qd" 52:7 52:7
du="nm"
r="nm"
ln="list"
16:
m="glyburide" 53:0 53:0
do="2.5 mg" 53:1 53:2
mo="po" 53:3 53:3
f="qd" 53:4 53:4
du="nm"
r="nm"
ln="list"
17:
m="zetia ( ezetimibe )" 54:0 54:3
do="10 mg" 54:4 54:5
mo="po" 54:6 54:6
f="qd" 54:7 54:7
du="nm"
r="nm"
ln="list"
18:
m="percocet" 78:4 78:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="back pain" 78:6 78:7
ln="narrative"
19:
m="nitro" 80:6 80:6
do="nm"
mo="sl" 80:5 80:5
f="nm"
du="nm"
r="some chest pressure" 79:14 80:1
ln="narrative"
20:
m="lasix" 91:11 91:11
do="10 mg" 91:12 91:13
mo="po" 91:14 91:14
f="qd" 91:15 91:15
du="nm"
r="nm"
ln="list"
21:
m="meds:protonix" 91:0 91:0
do="40 mg" 91:1 91:2
mo="po" 91:3 91:3
f="qam" 91:4 91:4
du="nm"
r="nm"
ln="list"
22:
m="sucralfate" 91:6 91:6
do="1g" 91:7 91:7
mo="po" 91:8 91:8
f="qid" 91:9 91:9
du="nm"
r="nm"
ln="list"
23:
m="cozaar" 92:6 92:6
do="50 mg" 92:7 92:8
mo="po" 92:9 92:9
f="qd" 92:10 92:10
du="nm"
r="nm"
ln="list"
24:
m="glyburide" 92:12 92:12
do="2.5" 92:13 92:13
mo="po" 92:14 92:14
f="qd" 92:15 92:15
du="nm"
r="nm"
ln="list"
25:
m="lescol" 92:0 92:0
do="20 mg" 92:1 92:2
mo="po" 92:3 92:3
f="qd" 92:4 92:4
du="nm"
r="nm"
ln="list"
26:
m="paxil" 92:17 92:17
do="10 mg" 92:18 93:0
mo="po" 93:1 93:1
f="qd" 93:2 93:2
du="nm"
r="nm"
ln="list"
27:
m="ativan" 93:4 93:4
do="2 mg" 93:5 93:6
mo="po" 93:7 93:7
f="qid" 93:8 93:8
du="nm"
r="nm"
ln="list"
28:
m="inderal" 93:16 93:16
do="10 mg" 94:0 94:1
mo="po" 94:2 94:2
f="qid" 94:3 94:3
du="nm"
r="nm"
ln="list"
29:
m="norvasc" 93:10 93:10
do="5 mg" 93:11 93:12
mo="po" 93:13 93:13
f="qd" 93:14 93:14
du="nm"
r="nm"
ln="list"
30:
m="imdur sr" 94:10 94:11
do="30 mg" 94:12 94:13
mo="po" 94:14 94:14
f="bid" 95:0 95:0
du="nm"
r="nm"
ln="list"
31:
m="persantine" 94:5 94:5
do="50 mg" 94:6 94:7
mo="nm"
f="bid" 94:8 94:8
du="nm"
r="nm"
ln="list"
32:
m="dobutamine" 107:0 107:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="dobutamine" 109:3 109:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="b-blocker" 114:1 114:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="cad" 112:5 112:5
ln="narrative"
35:
m="persantine" 114:6 114:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="cad" 112:5 112:5
ln="narrative"
36:
m="statin" 114:3 114:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="cad" 112:5 112:5
ln="narrative"
37:
m="adenosine" 116:3 116:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="cozaar" 119:3 119:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="htn:" 119:1 119:1
ln="narrative"
39:
m="ideral" 119:5 119:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="htn:" 119:1 119:1
ln="narrative"
40:
m="imdur" 119:7 119:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="htn:" 119:1 119:1
ln="narrative"
41:
m="lasix" 119:9 119:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="htn:" 119:1 119:1
ln="narrative"
42:
m="o2" 121:6 121:6
do="sat&gt;93%" 121:8 121:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="ppi" 125:3 125:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="ssi regular" 127:0 127:1
do="nm"
mo="nm"
f="qac." 127:2 127:2
du="nm"
r="t2dm." 126:2 126:2
ln="narrative"
45:
m="lovenox" 133:3 133:3
do="nm"
mo="sc" 133:2 133:2
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="ppi" 133:5 133:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="home medications" 138:0 138:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
