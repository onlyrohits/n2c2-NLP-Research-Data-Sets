1:
m="low molecular weight dextran" 36:2 36:5
do="nm"
mo="nm"
f="nm"
du="for 48 hours" 36:6 36:8
r="his endarterectomy" 36:10 37:0
ln="narrative"
2:
m="enteric coated aspirin" 37:6 37:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="enteric coated aspirin" 37:6 37:8
do="one" 37:9 37:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="beta blockers." 40:8 40:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="tenormin" 44:4 44:4
do="75 mg" 44:6 44:7
mo="po" 45:0 45:0
f="q day" 45:1 45:2
du="nm"
r="nm"
ln="list"
6:
m="carafate" 45:11 45:11
do="1 gram" 45:13 45:14
mo="po" 45:15 45:15
f="q.i.d.;" 46:0 46:0
du="nm"
r="nm"
ln="list"
7:
m="enteric coated aspirin" 45:3 45:5
do="one" 45:7 45:7
mo="po" 45:8 45:8
f="q day;" 45:9 45:10
du="nm"
r="nm"
ln="list"
8:
m="colace." 46:11 46:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="iron sulfate" 46:1 46:2
do="325 mg" 46:4 46:5
mo="po" 46:6 46:6
f="q day" 46:7 46:8
du="nm"
r="nm"
ln="list"
10:
m="percocet" 46:9 46:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
