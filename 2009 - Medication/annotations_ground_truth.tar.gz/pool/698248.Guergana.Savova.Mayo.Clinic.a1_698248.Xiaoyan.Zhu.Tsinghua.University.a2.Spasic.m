1:
m="acetylsalicylic acid" 19:0 19:1
do="81 mg" 19:2 19:3
mo="po" 19:4 19:4
f="qd" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 22:3 22:3
do="nm"
mo="po" 22:4 22:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 23:3 23:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 23:5 23:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="atenolol" 25:0 25:0
do="50 mg" 25:1 25:2
mo="po" 25:3 25:3
f="qam" 25:4 25:4
du="nm"
r="nm"
ln="list"
6:
m="enalapril maleate" 26:0 26:1
do="10 mg" 26:2 26:3
mo="po" 26:4 26:4
f="qd" 26:5 26:5
du="nm"
r="nm"
ln="list"
7:
m="lasix ( furosemide )" 27:0 27:3
do="80 mg" 27:4 27:5
mo="po" 27:6 27:6
f="qd" 27:7 27:7
du="nm"
r="nm"
ln="list"
8:
m="nph insulin human ( insulin nph human )" 29:0 29:7
do="60 units" 29:8 29:9
mo="sc" 29:10 29:10
f="qam" 29:11 29:11
du="nm"
r="nm"
ln="list"
9:
m="nph insulin human ( insulin nph human )" 31:0 31:7
do="60 units" 31:8 31:9
mo="sc" 31:10 31:10
f="qpm" 31:11 31:11
du="nm"
r="nm"
ln="list"
10:
m="coumadin ( warfarin sodium )" 33:0 33:4
do="5 mg" 33:5 33:6
mo="po" 33:7 33:7
f="qpm" 33:8 33:8
du="nm"
r="nm"
ln="list"
11:
m="simvastatin" 40:3 40:3
do="nm"
mo="po" 40:4 40:4
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="simvastatin" 41:5 41:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="warfarin" 41:3 41:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="aspirin" 44:3 44:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="warfarin" 44:5 44:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="paxil ( paroxetine )" 46:0 46:3
do="50 mg" 46:4 46:5
mo="po" 46:6 46:6
f="qd" 46:7 46:7
du="nm"
r="nm"
ln="list"
17:
m="seroquel ( quetiapine )" 47:0 47:3
do="800 mg" 47:4 47:5
mo="po" 47:6 47:6
f="qpm" 47:7 47:7
du="number of doses required ( approximate ): 4" 48:0 48:7
r="nm"
ln="list"
18:
m="depakote er ( divalproex sodium er )" 49:0 49:6
do="1 , 000 mg" 49:7 49:10
mo="po" 49:11 49:11
f="qpm" 49:12 49:12
du="nm"
r="nm"
ln="list"
19:
m="lipitor ( atorvastatin )" 50:0 50:3
do="60 mg" 50:4 50:5
mo="po" 50:6 50:6
f="qd" 50:7 50:7
du="nm"
r="nm"
ln="list"
20:
m="atorvastatin calcium" 52:5 53:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="warfarin" 52:3 52:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="protonix ( pantoprazole )" 54:0 54:3
do="40 mg" 54:4 54:5
mo="po" 54:6 54:6
f="qd" 54:7 54:7
du="nm"
r="nm"
ln="list"
23:
m="insulin" 89:4 89:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="type 2 dm" 89:0 89:2
ln="narrative"
24:
m="lopressor" 106:7 106:7
do="25 mg" 106:4 106:5
mo="po" 106:6 106:6
f="nm"
du="x 2" 106:8 106:9
r="a flutter with hr in the 110s" 105:11 106:0
ln="narrative"
25:
m="asa" 129:12 129:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="metop" 129:14 129:14
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="ace p" 130:2 130:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="statin" 130:0 130:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="lasix" 131:4 131:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="bb" 133:4 133:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="afib" 133:0 133:0
ln="narrative"
31:
m="bb" 133:4 133:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="rate control" 133:1 133:2
ln="narrative"
32:
m="coumadin" 133:6 133:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="rate control" 133:1 133:2
ln="narrative"
33:
m="nph" 135:1 135:1
do="60" 135:4 135:4
mo="nm"
f="qam" 135:5 135:5
du="nm"
r="nm"
ln="narrative"
34:
m="nph" 135:1 135:1
do="60" 135:4 135:4
mo="nm"
f="qam and qpm" 135:5 135:7
du="nm"
r="nm"
ln="narrative"
35:
m="riss" 135:10 135:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="coumadin" 143:0 143:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="insulin" 151:2 151:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
