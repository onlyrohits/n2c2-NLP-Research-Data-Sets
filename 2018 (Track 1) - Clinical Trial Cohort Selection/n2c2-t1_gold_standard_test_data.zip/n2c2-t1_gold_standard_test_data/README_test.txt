
Please note that, as per the discussion in the Google Group
(https://groups.google.com/a/simmons.edu/forum/#!topic/n2c2-2018-challenge-organizers-group/BEXpfnwOR4A)
the annotations in the training and test set should be modified so that
CABG, PTCA, and PCI are used consistently as evidence of ischemia for the
ADVANCED-CAD category.  In particular,  the files 140, 156, 205, 266, and 277 should have the
annotation <ADVANCED-CAD met="met”>.
However, the files included here for evaluation of challenge submissions do not and will not include these corrections,
so they are consistent with the training data that was available before the submission
deadline.
