Memo about the annotation:
1. The note files are from the 2010 i2b2 NLP challenge corpus.
2. In the QuestionAnchorType column, C/ADT stands for consultation/admission, discharge, or transfer.
3. The column LineNumber has values starting from 1 instead of 0.
4. The columns AnswerBegin and AnswerEnd are character offsets (starting from 0) of the Answer string within SentenceText.
5. relations_whyqa_ann-v7-share.json is the small corpus in SQuAD 2.0 format.

